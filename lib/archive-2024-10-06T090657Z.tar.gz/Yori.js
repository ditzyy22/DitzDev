/*
Note : Jika anda ingin beli Yang no encrypt, anda bisa hubungi saya melalui whatsapp atau melainkan telegram
Contact Me :
+62895342022385 [ WhatsApp ]
ErerexIDOfc [ User Telergam ]
*/
require('./settings')
const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, downloadContentFromMessage, areJidsSameUser, getContentType } = require("@whiskeysockets/baileys")
const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const axios = require('axios')
const fsx = require('fs-extra')
const crypto = require('crypto')
const canvafy = require('canvafy')
const fetch = require('node-fetch')
const { sizeFormatter } = require('human-readable')
const ffmpeg = require('fluent-ffmpeg')
const moment = require('moment-timezone')
const { JSDOM } = require('jsdom')
const { color, bgcolor } = require('./lib/color')
const { ssweb } = require('./lib/ssweb')
const { googleImage } = require('@bochilteam/scraper')
const { quote } = require('./lib/quote')
const { uptotelegra } = require('./lib/upload')
const { Primbon } = require('scrape-primbon')
const { remini } = require('./lib/remini')
const { TelegraPh } = require('./lib/uploader')
const { yoricdn } = require('./lib/yoricdn.js') 
const uploadImage = require('./lib/uploadImage')
const primbon = new Primbon()
const hxz = require('hxz-api')
const jsobfus = require('javascript-obfuscator')
const cheerio = require('cheerio')
const path = require('path')
const ytdl = require("ytdl-core")
const speed = require('performance-now')
const { performance } = require('perf_hooks')
const { exec, spawn, execSync } = require("child_process")
const { mediafiredl } = require('@bochilteam/scraper')
let Button = require("./lib/button");
let btn = new Button();
const { smsg, tanggal, getTime, formatp, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins } = require('./lib/myfunc')
const { FajarNews, BBCNews, metroNews, CNNNews, iNews, KumparanNews, TribunNews, DailyNews, DetikNews, OkezoneNews, CNBCNews, KompasNews, SindoNews, TempoNews, IndozoneNews, AntaraNews, RepublikaNews, VivaNews, KontanNews, MerdekaNews, KomikuSearch, AniPlanetSearch, KomikFoxSearch, KomikStationSearch, MangakuSearch, KiryuuSearch, KissMangaSearch, KlikMangaSearch, PalingMurah, LayarKaca21, AminoApps, Mangatoon, WAModsSearch, Emojis, CoronaInfo, JalanTikusMeme, Cerpen, Quotes, Couples, Darkjokes } = require("dhn-api");
const { addResponList, delResponList, isAlreadyResponList, isAlreadyResponListGroup, sendResponList, updateResponList, getDataResponList } = require('./lib/respon-list');
const FormData = require('form-data')
const { 
getRegisteredRandomId, 
addRegisteredUser, 
createSerial, 
checkRegisteredUser 
} = require('./lib/register.js');
const {
  createQR,
  cekStatus,
  cancelTrx,
  cekPay,
  callBack,
} = require("./scrape/paydisini");
const { addRespons, checkRespons, deleteRespons } = require('./lib/respon');

const api = {
    xterm: {
        url: "https://ai.xterm.codes",
        key: "YoriChan"
    }
};

const formatNumber = (num) => {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
};

// Membaca Seluruh Database
global.db.data = JSON.parse(fs.readFileSync('./src/database.json'))
if (global.db.data) global.db.data = {
users: {},
chats: {},
game: {},
database: {},
settings: {},
setting: {},
others: {},
sticker: {},
...(global.db.data || {})
}
let kuismath = db.data.game.math = []
let tebakgambar = db.data.game.tebakgambar = []
let tebakkata = db.data.game.tebakkata = []
let caklontong = db.data.game.lontong = []
let caklontong_desk = db.data.game.lontong_desk = []
let tebakkalimat = db.data.game.kalimat = []
let tebaklirik = db.data.game.lirik = []
let tebaktebakan = db.data.game.tebakan = []
let db_respon_list = JSON.parse(fs.readFileSync('./database/list-message.json'));
let reminders = {};

const authorr = "62895342022385"
const yts = require('./scrape/yt-search')
//const { ytSearch } = require('./scrape/yt')
const thumbnail = fs.readFileSync('./data/image/menu.jpg')
const thumb = fs.readFileSync('./data/image/menu.jpg')
const kalimage = fs.readFileSync('./data/image/menu.jpg')
const pengguna = JSON.parse(fs.readFileSync('./database/user.json'))
const owner = JSON.parse(fs.readFileSync('./premium.json'))
const author = JSON.parse(fs.readFileSync('./author.json'))
const ntilink = JSON.parse(fs.readFileSync("./lib/antilink.json"))
const chatbot = JSON.parse(fs.readFileSync("./lib/chatbot.json"))
const antidel = JSON.parse(fs.readFileSync("./lib/antidel.json"))
const banned = JSON.parse(fs.readFileSync('./data/db/banned.json'))
const contacts = JSON.parse(fs.readFileSync("./database/contacts.json"))

// Get Database
const isContacts = contacts.includes(m.sender)

module.exports = Yori = async (Yori, m, chatUpdate, store, Jid, fromMe) => {
    const { isGroup } = m
    try {
        const body = (m.mtype === 'conversation')
            ? m.message.conversation
            : (m.mtype === 'imageMessage')
                ? m.message.imageMessage.caption
                : (m.mtype === 'videoMessage')
                    ? m.message.videoMessage.caption
                    : (m.mtype === 'extendedTextMessage')
                        ? m.message.extendedTextMessage.text
                        : (m.mtype === 'buttonsResponseMessage')
                            ? m.message.buttonsResponseMessage.selectedButtonId
                            : (m.mtype === 'listResponseMessage')
                                ? m.message.listResponseMessage.singleSelectReply.selectedRowId
                                : (m.mtype === 'templateButtonReplyMessage')
                                    ? m.message.templateButtonReplyMessage.selectedId
                                    : (m.mtype === 'interactiveResponseMessage')
                                        ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id
                                        : (m.mtype === 'templateButtonReplyMessage')
                                            ? m.msg.selectedId
                                            : (m.mtype === 'messageContextInfo')
                                                ? (m.message.buttonsResponseMessage?.selectedButtonId
                                                    || m.message.listResponseMessage?.singleSelectReply.selectedRowId
                                                    || m.text)
                                                : '';

        const bodyh =
            m.mtype === "conversation"
                ? m.message.conversation
                : m.mtype == "imageMessage"
                    ? m.message.imageMessage.caption
                    : m.mtype == "videoMessage"
                        ? m.message.videoMessage.caption
                        : m.mtype == "extendedTextMessage"
                            ? m.message.extendedTextMessage.text
                            : m.mtype == "stickerMessage" &&
/*
                            async function appenTextMessage(text, chatUpdate) {
                                let messages = await generateWAMessage(
                                    m.chat,
                                    { text: text, mentions: m.mentionedJid },
                                    {
                                        userJid: Yori.user.id,
                                        quoted: m.quoted && m.quoted.fakeObj,
                                    },
                                );
                                messages.key.fromMe = areJidsSameUser(m.sender, Yori.user.id);
                                messages.key.id = m.key.id;
                                messages.pushName = m.pushName;
                                if (m.isGroup) messages.participant = m.sender;
                                let msg = {
                                    ...chatUpdate,
                                    messages: [proto.WebMessageInfo.fromObject(messages)],
                                    type: "append",
                                };
                                Yori.ev.emit("messages.upsert", msg);
                            }

        var budy = (typeof m.text == 'string' ? m.text : '')
        var prefix = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : prefa ?? global.prefix


        const isCmd = body.startsWith(prefix)
        const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase();       
        //Kalau Mau Single Prefix Kamu Ganti Command Diatas Pakai Ini : const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
        */
    async function appendTextMessage(text, chatUpdate) {
    let messages = await generateWAMessage(
        m.chat,
        { text: text, mentions: m.mentionedJid },
        {
            userJid: Yori.user.id,
            quoted: m.quoted && m.quoted.fakeObj,
        }
    );
    messages.key.fromMe = areJidsSameUser(m.sender, Yori.user.id);
    messages.key.id = m.key.id;
    messages.pushName = m.pushName;
    if (m.isGroup) messages.participant = m.sender;
    let msg = {
        ...chatUpdate,
        messages: [proto.WebMessageInfo.fromObject(messages)],
        type: "append",
    };
    Yori.ev.emit("messages.upsert", msg);
}

// Mendapatkan teks pesan dan prefix
var budy = (typeof m.text == 'string' ? m.text : '');
var prefix = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : prefa ?? global.prefix;

// Bagian Mengecek apakah pesan adalah perintah
const isCmd = body.startsWith(prefix);
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase();

// Setting Command Yang mau lu add
let valid_commands = ["profile", "ping", "pin", "pinterest", "play", "youtubesearch", "deposit", "spotify", "level", "help", "menu", "status", "menulist", "allmenu", "ytmp3", "spdl", "ai", "openai", "gpt4", "yoriai", "cekkhodam", "cekmemek", "bot", "tiktok", "instagram", "twitter", "filmsearch", "film", "yousearch"];

// Fungsi get_close_matches untuk mencocokkan kata yang mirip
function get_close_matches(word, possibilities, n = 1, cutoff = 0.6) {
    const levenshtein = require('fast-levenshtein');
    return possibilities
        .map(possibility => ({
            word: possibility,
            distance: levenshtein.get(word, possibility),
        }))
        .sort((a, b) => a.distance - b.distance)
        .filter(item => item.distance / Math.max(item.word.length, word.length) <= (1 - cutoff))
        .slice(0, n)
        .map(item => item.word);
}
/*
function didyoumen(command, valid_commands) {
      let suggestions = get_close_matches(command, valid_commands, 1, 0.6);
      if (suggestions.length) {
            let suggestion_text = `🤔 Sepertinya Anda salah ketik. Mungkin yang Anda maksud adalah \n\n Command : ➠ *${suggestions[0]}*. \n\n Coba gunakan perintah tersebut untuk melanjutkan melihat fitur bot!`;

        // Kirim pesan dengan thumbnail reply
        Yori.sendMessage(m.chat, { 
            caption: suggestion_text,  // Teks saran yang dikirim
            image: { url: './data/image/profile.jpg' },                 mentions: [m.sender],
            quoted: m
        });
    }
}
*/

const baten = new Button();
function didyoumen(command, valid_commands) {
    let suggestions = get_close_matches(command, valid_commands, 1, 0.6);
    if (suggestions.length) {
        let suggestion_text = `🤔 Sepertinya Anda salah ketik. Mungkin yang Anda maksud adalah \n\n Command : ➠ *${suggestions[0]}*. \n\n Coba gunakan perintah tersebut untuk melanjutkan melihat fitur bot!`;
        let ads = baten.setBody(suggestion_text);
        ads += baten.setImage('./data/image/profile.jpg'); 
        ads += baten.addReply("Click Command Anda", `${suggestions[0]}`);  
        ads += baten.run(m.chat, Yori, m);  

        // Atau lu mau mengirim langsung tanpa Button
        // Yori.sendMessage(m.chat, { 
        //     caption: suggestion_text,
        //     image: { url: './data/image/profile.jpg' },
        //     mentions: [m.sender],
        //     quoted: m
        // });
    }
}



if (isCmd) {
    if (!valid_commands.includes(command)) {
        // Jalankan didyoumen jika perintah salah
        didyoumen(command, valid_commands);
    } else {
        // Eksekusi perintah jika valid
        console.log(`Executing command: ${command}`);
    }
}


        if (m.fromMe && m.isBaileys) return

        const args = body.trim().split(/ +/).slice(1)
        const full_args = body.replace(command, '').slice(1).trim()
        const spychat = body.replace().slice().trim()
        const pushname = m.pushName || "No Name"
        const text = q = args.join(" ")
        const { type, quotedMsg, mentioned, now, fromMe } = m
        const quoted = m.quoted ? m.quoted : m
        const mime = (quoted.msg || quoted).mimetype || ''
        const isMedia = /image|video|sticker|audio/.test(mime)
        const from = mek.key.remoteJid
        const botNumber = await Yori.decodeJid(Yori.user.id)
        const isCreator = [botNumber, ...author].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const isRegistered = checkRegisteredUser(m.sender)
        const isPrem = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
        const groupMetadata = m.isGroup ? await Yori.groupMetadata(m.chat) : "";
        const groupName = m.isGroup ? await groupMetadata.subject : "";
        const participants = m.isGroup ? await groupMetadata.participants : ''
        const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
        const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
        const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
        const AntiLink = m.isGroup ? ntilink.includes(from) : false
        const ChatBot = m.isGroup ? chatbot.includes(from) : false
        const autodelete = from && isCmd ? antidel.includes(from) : false
        const isBan = banned.includes(m.sender)
        const isUser = pengguna.includes(m.sender)
        const content = JSON.stringify(m.message)
        const numberQuery = text.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net"
        const mentionByTag = m.mtype == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.mentionedJid : []
        const Input = mentionByTag[0] ? mentionByTag[0] : q ? numberQuery : false
        const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
        const salam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
        const qtod = m.quoted ? "true" : "false"

        const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
        const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')
        const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
        const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')

        const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if (time2 < "23:59:00") {
            var ucapanWaktu = 'Selamat Malam 🌠'
        }
        if (time2 < "19:00:00") {
            var ucapanWaktu = 'Selamat Petang 🌆'
        }
        if (time2 < "18:00:00") {
            var ucapanWaktu = 'Selamat Sore 🌇'
        }
        if (time2 < "15:00:00") {
            var ucapanWaktu = 'Selamat Siang 🏞'
        }
        if (time2 < "10:00:00") {
            var ucapanWaktu = 'Selamat Pagi 🏞'
        }
        if (time2 < "05:00:00") {
            var ucapanWaktu = 'Selamat Subuh 🌅'
        }
        if (time2 < "03:00:00") {
            var ucapanWaktu = '🍃 Selamat Tengah Malam 🎑'
        }

        if (!Yori.public) {
            if (!m.key.fromMe && !isPrem) return
        }

        const cap = 'Yori Chan Multi Device'
        try {
            pplu = await Yori.profilePictureUrl(anu.id, 'image')
        } catch {
            pplu = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
        }
        
        const len = {
            key: {
                participant: `0@s.whatsapp.net`,
                ...(m.chat ? {
                    remoteJid: `status@broadcast`
                } : {})
            },
            message: {
                "contactMessage": {
                    'displayName': `${pushname}`,
                    'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;Yori,;;;\nFN: Yori V1.8\nitem1.TEL;waid=${m.sender.split("@")[0]}:+${m.sender.split("@")[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
                    'jpegThumbnail': pplu,
                    thumbnail: pplu,
                    sendEphemeral: true
                }
            }
        }

        const len2 = {
            key: {
                fromMe: false,
                participant: `0@s.whatsapp.net`,
                ...(m.chat ? {
                    remoteJid: "status@broadcast"
                } : {})
            },
            message: {
                "extendedTextMessage": {
                    "text": ucapanWaktu,
                    "title": ``,
                    "thumbnailUrl": pplu
                }
            }
        }

        const deniedreply = async (teks) => {
    if (!isRegistered) {
        // Mengirim pesan denied dengan tombol "Daftar"
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        contextInfo: {
                            mentionedJid: [m.sender],
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: '120363204138641225@newsletter',
                                newsletterName: botname
                            },
                            businessMessageForwardInfo: {
                                businessOwnerJid: Yori.decodeJid(Yori.user.id)
                            }
                        },
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: teks
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: ``
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: `Hello, @${m.sender.split("@")[0]}!! 👋`,
                            subtitle: "Yori Chan - MultiDevice",
                            hasMediaAttachment: true,
                            ...(await prepareWAMessageMedia({ image: { url: './data/image/denied.jpg' } }, { upload: Yori.waUploadToServer }))
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    "name": "quick_reply",
                                    "buttonParamsJson": `{"display_text":"Daftar Account User","id":".daftar"}`
                                }
                            ]
                        })
                    })
                }
            }
        }, {});

        await Yori.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
    }
}
    
        const Yorireply = (teks) => {
            Yori.sendMessage(from, { text: teks, contextInfo: { "externalAdReply": { "title": `👋 Halo Aku Yori Chan`, "body": `Hai kak ${pushname} Jangan Spam Ya`, "previewType": "PHOTO", "thumbnail": thumb, "sourceUrl": `` } } }, { quoted: len })            
        }
       
        /*
        const Yorireply = (teks) => {
Yori.sendMessage(m.chat,{ 
text: teks,
contextInfo:{
mentionedJid:[m.sender],
externalAdReply: {
showAdAttribution: true,
containsAutoReply: true,
title: `© Yori Chan - Multi Device`,
body: `Hai ${pushname}`,
previewType: "PHOTO",
thumbnailUrl: `https://tmpfiles.org/dl/13408168/1727349536727.jpg`,
thumbnail: ``,
sourceUrl: `https://chat.whatsapp.com/K645017GY11IqZ8AX2fSq1`}}},
{ quoted: len})}
*/
/*
       const Yorireply = async (teks) => {
  Yori.sendMessage(m.chat, { 
    text: teks,
    contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
        showAdAttribution: true,
        containsAutoReply: true,
        title: `🎉 Yori Chan - Multi Device ✨`,
        body: `Hai ${pushname}! 👋 Apa kabar? Jangan lupa tersenyum hari ini! 😊`,
        mediaType: 1,
        previewType: "PHOTO",
        thumbnail: pplu,
        renderLargerThumbnail: true,
      }
    }
  },
  { quoted: len });
}
*/
const fkontak = {
key: {
participants: "0@s.whatsapp.net",
remoteJid: "status@broadcast",
fromMe: false,
id: "Halo"},
message: {
contactMessage: {
vcard: `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
}},
participant: "0@s.whatsapp.net"
}

        // Tanpa ContextInfo : Yori.sendMessage(from, { text: teks, }, { quoted: len })}
        
        try {
            let isNumber = x => typeof x === 'number' && !isNaN(x)
            let limitUser = global.limitawal.free
            let user = global.db.data.users[m.sender]
            if (typeof user !== 'object') global.db.data.users[m.sender] = {}
            if (user) {
                if (!isNumber(user.afkTime)) user.afkTime = -1
                if (!('afkReason' in user)) user.afkReason = ''
                if (!isNumber(user.limit)) user.limit = limitUser
                if (!isNumber(user.level)) user.level = 0
                if (!('autolevelup' in user)) user.autolevelup = true
            } else global.db.data.users[m.sender] = {
                afkTime: -1,
                afkReason: '',
                limit: limitUser,                
                level: 0,                
                autolevelup: true               
            }
            let chats = global.db.data.chats[m.chat]
            if (typeof chats !== 'object') global.db.data.chats[m.chat] = {}
            if (chats) {
                if (!('mute' in chats)) chats.mute = false
                if (!('wlcm' in chats)) chats.wlcm = true
                if (!('antitoxic' in chats)) chats.antitoxic = false
                if (!('antilink' in chats)) chats.antilink = false
                if (!('antilinkyt' in chats)) chats.antilinkyt = false
                if (!('antilinktt' in chats)) chats.antilinktt = false
                if (!('antivirtex' in chats)) chats.antivirtex = true
                if (!('antipanel' in chats)) chats.antipanel = false
                if (!('antilinkv2' in chats)) chats.antilinkv2 = false
                if (!('antiwame' in chats)) chats.antiwame = false
                if (!('notification' in chats)) chats.notification = {}
            } else global.db.data.chats[m.chat] = {
                mute: false,
                wlcm: true,
                antitoxic: false,
                antilink: false,
                antilinkyt: false,
                antilinktt: false,
                antivirtex: true,
                antipanel: false,
                antiwame: false,
                antilinkv2: false,
                notification: {
                     status: false,
                     text_left: '',
                     text_welcome:''
                  }
            }
            let setting = global.db.data.settings[botNumber]
            if (typeof setting !== 'object') global.db.data.settings[botNumber] = {}
            if (setting) {
                if (!isNumber(setting.status)) setting.status = 0
                if (!('autobio' in setting)) setting.autobio = false
                if (!('autoread' in setting)) setting.autoread = false
            } else global.db.data.settings[botNumber] = {
                status: 0,
                autobio: false,
                autoread: false
            }

        } catch (err) {
            console.error(err)
        }

let cron = require('node-cron')
        cron.schedule('02 12 * * *', () => {
            let user = Object.keys(global.db.data.users)
            let limitUser = isPremium ? global.limitawal.premium : global.limitawal.free
            for (let jid of user) global.db.data.users[jid].limit = limitUser
            console.log('Reseted Limit')
        }, {
            scheduled: true,
            timezone: "Asia/Jakarta"
        })

        function generateRandomPassword() {
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
            const length = 10;
            let password = '';
            for (let i = 0; i < length; i++) {
                const randomIndex = Math.floor(Math.random() * characters.length);
                password += characters[randomIndex];
            }
            return password;
        }
        
        const ftext = { 
key: { 
fromMe: false, 
participant: `0@s.whatsapp.net`, 
...(from ? {
remoteJid: `${owner}@s.whatsapp.net` } : {}) }, 
message: { 
extendedTextMessage: { 
text: `${m.pushname}`, 
title: `${m.pushname}`, 
jpegThumbnail: defaultpp } } }
//Fake
	    const ftroli ={key: {fromMe: false,"participant":"0@s.whatsapp.net", "remoteJid": "status@broadcast"}, "message": {orderMessage: {itemCount: 2022,status: 200, thumbnail: thumb, surface: 200, message: botname, orderTitle: ownername, sellerJid: '0@s.whatsapp.net'}}, contextInfo: {"forwardingScore":999,"isForwarded":true},sendEphemeral: true}
		const fdoc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {documentMessage: {title: botname,jpegThumbnail: thumb}}}
		const fvn = {key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: { "audioMessage": {"mimetype":"audio/ogg; codecs=opus","seconds":359996400,"ptt": "true"}} } 
        
let formatSize = sizeFormatter({
	std: 'JEDEC', decimalPlaces: 2, keepTrailingZeroes: false, render: (literal, symbol) => `${literal} ${symbol}B`
})
async function GDriveDl(url) {
	let id
	if (!(url && url.match(/drive\.google/i))) throw 'Invalid URL'
	id = (url.match(/\/?id=(.+)/i) || url.match(/\/d\/(.*?)\//))[1]
	if (!id) throw 'ID Not Found'
	let res = await fetch(`https://drive.google.com/uc?id=${id}&authuser=0&export=download`, {
		method: 'post',
		headers: {
			'accept-encoding': 'gzip, deflate, br',
			'content-length': 0,
			'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
			'origin': 'https://drive.google.com',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
			'x-client-data': 'CKG1yQEIkbbJAQiitskBCMS2yQEIqZ3KAQioo8oBGLeYygE=',
			'x-drive-first-party': 'DriveWebUi',
			'x-json-requested': 'true' 
		}
	})
	let { fileName, sizeBytes, downloadUrl } =  JSON.parse((await res.text()).slice(4))
	if (!downloadUrl) throw 'Link Download Limit!'
	let data = await fetch(downloadUrl)
	if (data.status !== 200) throw data.statusText
	return { downloadUrl, fileName, fileSize: formatSize(sizeBytes), mimetype: data.headers.get('content-type') }
}

        async function jarak(dari, ke) {
            let html = (await axios(`https://www.google.com/search?q=${encodeURIComponent('jarak ' + dari + ' ke ' + ke)}&hl=id`)).data
            let $ = cheerio.load(html), obj = {}
            let img = html.split("var s=\'")?.[1]?.split("\'")?.[0]
            obj.img = /^data:.*?\/.*?;base64,/i.test(img) ? Buffer.from(img.split`,`[1], 'base64') : ''
            obj.desc = $('div.BNeawe.deIvCb.AP7Wnd').text()?.trim()
            return obj
        }
        
        async function luminAi(
    teks,
    pengguna = null,
    prompt = null,
    modePencarianWeb = false
  ) {
    try {
      const data = { content: teks };
      if (pengguna !== null) data.user = pengguna;
      if (prompt !== null) data.prompt = prompt;
      data.webSearchMode = modePencarianWeb;
  
      const { data: res } = await axios.post(
        "https://luminai.my.id/",
        data
      );
      return res.result;
    } catch (error) {
      console.error("Terjadi kesalahan:", error);
      throw error;
    }
  }    

        async function spotifydl(url) {
            return new Promise(async (resolve, reject) => {
                try {
                    const kemii = await axios.get(
                        `https://api.fabdl.com/spotify/get?url=${encodeURIComponent(url)}`,
                        {
                            headers: {
                                accept: "application/json, text/plain, */*",
                                "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                                "sec-ch-ua": "\"Not)A;Brand\";v=\"24\", \"Chromium\";v=\"116\"",
                                "sec-ch-ua-mobile": "?1",
                                "sec-ch-ua-platform": "\"Android\"",
                                "sec-fetch-dest": "empty",
                                "sec-fetch-mode": "cors",
                                "sec-fetch-site": "cross-site",
                                Referer: "https://spotifydownload.org/",
                                "Referrer-Policy": "strict-origin-when-cross-origin",
                            },
                        }
                    );
                    const kemi = await axios.get(
                        `https://api.fabdl.com/spotify/mp3-convert-task/${kemii.data.result.gid}/${kemii.data.result.id}`,
                        {
                            headers: {
                                accept: "application/json, text/plain, */*",
                                "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                                "sec-ch-ua": "\"Not)A;Brand\";v=\"24\", \"Chromium\";v=\"116\"",
                                "sec-ch-ua-mobile": "?1",
                                "sec-ch-ua-platform": "\"Android\"",
                                "sec-fetch-dest": "empty",
                                "sec-fetch-mode": "cors",
                                "sec-fetch-site": "cross-site",
                                Referer: "https://spotifydownload.org/",
                                "Referrer-Policy": "strict-origin-when-cross-origin",
                            },
                        }
                    );
                    const result = {};
                    result.title = kemii.data.result.name;
                    result.type = kemii.data.result.type;
                    result.artis = kemii.data.result.artists;
                    result.durasi = kemii.data.result.duration_ms;
                    result.image = kemii.data.result.image;
                    result.download = "https://api.fabdl.com" + kemi.data.result.download_url;
                    resolve(result);
                } catch (error) {
                    reject(error);
                }
            });
        };

        async function searchSpotify(query) {
            try {
                const access_token = await getAccessToken();
                const response = await axios.get(`https://api.spotify.com/v1/search?q=${query}&type=track&limit=10`, {
                    headers: {
                        Authorization: `Bearer ${access_token}`,
                    },
                });
                const data = response.data;
                const tracks = data.tracks.items.map(item => ({
                    name: item.name,
                    artists: item.artists.map(artist => artist.name).join(', '),
                    popularity: item.popularity,
                    link: item.external_urls.spotify,
                    image: item.album.images[0].url,
                    duration_ms: item.duration_ms,
                }));
                return tracks;
            } catch (error) {
                console.error('Error searching Spotify:', error);
                throw 'An error occurred while searching for songs on Spotify.';
            }
        }

        async function getAccessToken() {
            try {
                const client_id = 'acc6302297e040aeb6e4ac1fbdfd62c3';
                const client_secret = '0e8439a1280a43aba9a5bc0a16f3f009';
                const basic = Buffer.from(`${client_id}:${client_secret}`).toString("base64");
                const response = await axios.post('https://accounts.spotify.com/api/token', 'grant_type=client_credentials', {
                    headers: {
                        Authorization: `Basic ${basic}`,
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                });
                const data = response.data;
                return data.access_token;
            } catch (error) {
                console.error('Error getting Spotify access token:', error);
                throw 'An error occurred while obtaining Spotify access token.';
            }
        }
        
function toRupiah(angka) {
  var saldo = "";
  var angkarev = angka.toString().split("").reverse().join("");
  for (var i = 0; i < angkarev.length; i++)
    if (i % 3 == 0) saldo += angkarev.substr(i, 3) + ".";
  return (
    "" +
    saldo
      .split("", saldo.length - 1)
      .reverse()
      .join("")
  );
}

        let cheerio = require("cheerio");
        let fetch = require("node-fetch");
        let { lookup } = require("mime-types");
        let { URL_REGEX, generateWAMessageFromContent, prepareWAMessageMedia } = require("@whiskeysockets/baileys");


        async function pinterest1(query) {
            if (query.match(URL_REGEX)) {
                let res = await fetch(
                    "https://www.expertsphp.com/facebook-video-downloader.php",
                    {
                        method: "post",
                        body: new URLSearchParams(
                            Object.entries({
                                url: query,
                            }),
                        ),
                    },
                );
                let $ = cheerio.load(await res.text());
                let data = $(
                    'table[class="table table-condensed table-striped table-bordered"]',
                )
                    .find("a")
                    .attr("href");
                if (!data) throw "Can't download post :/";
                return data;
            } else {
                let res = await fetch(
                    `https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${query}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${query}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`,
                );
                let json = await res.json();
                let data = json.resource_response.data.results;
                if (!data.length) throw `Query "${query}" not found :/`;
                return data
            }
        }

        async function shortUrl(url) {
            return await (
                await fetch(`https://tinyurl.com/api-create.php?url=${url}`)
            ).text();
        }

        function pinterest(querry) {
            return new Promise(async (resolve, reject) => {
                axios.get('https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=' + querry, {
                    headers: {
                        "cookie": "_auth=1; _b=\"AVna7S1p7l1C5I9u0+nR3YzijpvXOPc6d09SyCzO+DcwpersQH36SmGiYfymBKhZcGg=\"; _pinterest_sess=TWc9PSZHamJOZ0JobUFiSEpSN3Z4a2NsMk9wZ3gxL1NSc2k2NkFLaUw5bVY5cXR5alZHR0gxY2h2MVZDZlNQalNpUUJFRVR5L3NlYy9JZkthekp3bHo5bXFuaFZzVHJFMnkrR3lTbm56U3YvQXBBTW96VUgzVUhuK1Z4VURGKzczUi9hNHdDeTJ5Y2pBTmxhc2owZ2hkSGlDemtUSnYvVXh5dDNkaDN3TjZCTk8ycTdHRHVsOFg2b2NQWCtpOWxqeDNjNkk3cS85MkhhSklSb0hwTnZvZVFyZmJEUllwbG9UVnpCYVNTRzZxOXNJcmduOVc4aURtM3NtRFo3STlmWjJvSjlWTU5ITzg0VUg1NGhOTEZzME9SNFNhVWJRWjRJK3pGMFA4Q3UvcHBnWHdaYXZpa2FUNkx6Z3RNQjEzTFJEOHZoaHRvazc1c1UrYlRuUmdKcDg3ZEY4cjNtZlBLRTRBZjNYK0lPTXZJTzQ5dU8ybDdVS015bWJKT0tjTWYyRlBzclpiamdsNmtpeUZnRjlwVGJXUmdOMXdTUkFHRWloVjBMR0JlTE5YcmhxVHdoNzFHbDZ0YmFHZ1VLQXU1QnpkM1FqUTNMTnhYb3VKeDVGbnhNSkdkNXFSMXQybjRGL3pyZXRLR0ZTc0xHZ0JvbTJCNnAzQzE0cW1WTndIK0trY05HV1gxS09NRktadnFCSDR2YzBoWmRiUGZiWXFQNjcwWmZhaDZQRm1UbzNxc21pV1p5WDlabm1UWGQzanc1SGlrZXB1bDVDWXQvUis3elN2SVFDbm1DSVE5Z0d4YW1sa2hsSkZJb1h0MTFpck5BdDR0d0lZOW1Pa2RDVzNySWpXWmUwOUFhQmFSVUpaOFQ3WlhOQldNMkExeDIvMjZHeXdnNjdMYWdiQUhUSEFBUlhUVTdBMThRRmh1ekJMYWZ2YTJkNlg0cmFCdnU2WEpwcXlPOVZYcGNhNkZDd051S3lGZmo0eHV0ZE42NW8xRm5aRWpoQnNKNnNlSGFad1MzOHNkdWtER0xQTFN5Z3lmRERsZnZWWE5CZEJneVRlMDd2VmNPMjloK0g5eCswZUVJTS9CRkFweHc5RUh6K1JocGN6clc1JmZtL3JhRE1sc0NMTFlpMVErRGtPcllvTGdldz0=; _ir=0"
                    }
                }).then(({ data }) => {
                    const $ = cheerio.load(data)
                    const result = [];
                    const hasil = [];
                    $('div > a').get().map(b => {
                        const link = $(b).find('img').attr('src')
                        result.push(link)
                    });
                    result.forEach(v => {
                        if (v == undefined) return
                        hasil.push(v.replace(/230/g, '730'))
                    })
                    hasil.shift();
                    resolve(hasil)
                })
            })
        }

        function pinterest(querry) {
            return new Promise(async (resolve, reject) => {
                axios.get('https://id.pinterest.com/search/pins/?autologin=true&q=' + querry, {
                    headers: {
                        "cookie": "_auth=1; _b=\"AVna7S1p7l1C5I9u0+nR3YzijpvXOPc6d09SyCzO+DcwpersQH36SmGiYfymBKhZcGg=\"; _pinterest_sess=TWc9PSZHamJOZ0JobUFiSEpSN3Z4a2NsMk9wZ3gxL1NSc2k2NkFLaUw5bVY5cXR5alZHR0gxY2h2MVZDZlNQalNpUUJFRVR5L3NlYy9JZkthekp3bHo5bXFuaFZzVHJFMnkrR3lTbm56U3YvQXBBTW96VUgzVUhuK1Z4VURGKzczUi9hNHdDeTJ5Y2pBTmxhc2owZ2hkSGlDemtUSnYvVXh5dDNkaDN3TjZCTk8ycTdHRHVsOFg2b2NQWCtpOWxqeDNjNkk3cS85MkhhSklSb0hwTnZvZVFyZmJEUllwbG9UVnpCYVNTRzZxOXNJcmduOVc4aURtM3NtRFo3STlmWjJvSjlWTU5ITzg0VUg1NGhOTEZzME9SNFNhVWJRWjRJK3pGMFA4Q3UvcHBnWHdaYXZpa2FUNkx6Z3RNQjEzTFJEOHZoaHRvazc1c1UrYlRuUmdKcDg3ZEY4cjNtZlBLRTRBZjNYK0lPTXZJTzQ5dU8ybDdVS015bWJKT0tjTWYyRlBzclpiamdsNmtpeUZnRjlwVGJXUmdOMXdTUkFHRWloVjBMR0JlTE5YcmhxVHdoNzFHbDZ0YmFHZ1VLQXU1QnpkM1FqUTNMTnhYb3VKeDVGbnhNSkdkNXFSMXQybjRGL3pyZXRLR0ZTc0xHZ0JvbTJCNnAzQzE0cW1WTndIK0trY05HV1gxS09NRktadnFCSDR2YzBoWmRiUGZiWXFQNjcwWmZhaDZQRm1UbzNxc21pV1p5WDlabm1UWGQzanc1SGlrZXB1bDVDWXQvUis3elN2SVFDbm1DSVE5Z0d4YW1sa2hsSkZJb1h0MTFpck5BdDR0d0lZOW1Pa2RDVzNySWpXWmUwOUFhQmFSVUpaOFQ3WlhOQldNMkExeDIvMjZHeXdnNjdMYWdiQUhUSEFBUlhUVTdBMThRRmh1ekJMYWZ2YTJkNlg0cmFCdnU2WEpwcXlPOVZYcGNhNkZDd051S3lGZmo0eHV0ZE42NW8xRm5aRWpoQnNKNnNlSGFad1MzOHNkdWtER0xQTFN5Z3lmRERsZnZWWE5CZEJneVRlMDd2VmNPMjloK0g5eCswZUVJTS9CRkFweHc5RUh6K1JocGN6clc1JmZtL3JhRE1sc0NMTFlpMVErRGtPcllvTGdldz0=; _ir=0"
                    }
                }).then(({ data }) => {
                    const $ = cheerio.load(data)
                    const result = [];
                    const hasil = [];
                    $('div > a').get().map(b => {
                        const link = $(b).find('img').attr('src')
                        result.push(link)
                    });
                    result.forEach(v => {
                        if (v == undefined) return
                        hasil.push(v.replace(/230/g, '730'))
                    })
                    hasil.shift();
                    resolve(hasil)
                })
            })
        }

        function sort(property, ascending = true) {
            if (property) return (...args) => args[ascending & 1][property] - args[!ascending & 1][property]
            else return (...args) => args[ascending & 1] - args[!ascending & 1]
        }

        function toNumber(property, _default = 0) {
            if (property) return (a, i, b) => {
                return { ...b[i], [property]: a[property] === undefined ? _default : a[property] }
            }
            else return a => a === undefined ? _default : a
        }

        function enumGetKey(a) {
            return a.jid
        }

        function pickRandom(list) {
            return list[Math.floor(Math.random() * list.length)]
        }

        if (m.sender.startsWith('212')) return Yori.updateBlockStatus(m.sender, 'block')

        if (m.message) {
        if (global.db.data.settings[botNumber].autoread) {
          Yori.readMessages([m.key])
        }
     }
/*
        if (spychat) {
if (!isCreator && !m.isGroup) return
const { color } = require('./lib/color')
const moment = require("moment-timezone")
let levelling = require('./lib/levelling')
        let user = global.db.data.users[m.sender]
        if (!user.autolevelup) return !0
        let before = user.level * 1
        while (levelling.canLevelUp(user.level, user.exp, global.multiplier)) user.level++
        if (before !== user.level) {
            let chating = `🥳 Congratulations ${pushname}, you have leveled up!
*${before}* -> *${user.level}*
Use *Profile* To Check`
            Yorireply(chating)
            console.log(color(chating, 'pink'))
        }
    }
*/	
        const downloadMp3 = async (Link) => {
            try {
                await ytdl.getInfo(Link)
                let mp3File = getRandom('.mp3')
                console.log(color('Download Audio With ytdl-core'))
                ytdl(Link, { filter: 'audioonly' })
                    .pipe(fs.createWriteStream(mp3File))
                    .on('finish', async () => {
                        await Yori.sendMessage(from, { audio: fs.readFileSync(mp3File), mimetype: 'audio/mp4' }, { quoted: m })
                        fs.unlinkSync(mp3File)
                    })
            } catch (err) {
                Yorireply(`${err}`)
            }
        }

        function parseMention(text = '') {
            return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
        }

        const downloadMp4 = async (Link) => {
            try {
                await ytdl.getInfo(Link)
                let mp4File = getRandom('.mp4')
                console.log(color('Download Video With ytdl-core'))
                let nana = ytdl(Link)
                    .pipe(fs.createWriteStream(mp4File))
                    .on('finish', async () => {
                        await Yori.sendMessage(from, { video: fs.readFileSync(mp4File), gifPlayback: false }, { quoted: m })
                        fs.unlinkSync(`./${mp4File}`)
                    })
            } catch (err) {
                Yorireply(`${err}`)
            }
        }

        async function ytdlnew(videoUrl) {
            return new Promise(async (resolve, reject) => {
                try {
                    const searchParams = new URLSearchParams();
                    searchParams.append('query', videoUrl);
                    searchParams.append('vt', 'mp3');
                    const searchResponse = await axios.post(
                        'https://tomp3.cc/api/ajax/search',
                        searchParams.toString(),
                        {
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                                'Accept': '*/*',
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        }
                    );
                    if (searchResponse.data.status !== 'ok') {
                        throw new Error('Failed to search for the video.');
                    }
                    const videoId = searchResponse.data.vid;
                    const videoTitle = searchResponse.data.title;
                    const mp4Options = searchResponse.data.links.mp4;
                    const mp3Options = searchResponse.data.links.mp3;
                    const mediumQualityMp4Option = mp4Options[136];
                    const mp3Option = mp3Options['mp3128'];
                    const mp4ConvertParams = new URLSearchParams();
                    mp4ConvertParams.append('vid', videoId);
                    mp4ConvertParams.append('k', mediumQualityMp4Option.k);
                    const mp4ConvertResponse = await axios.post(
                        'https://tomp3.cc/api/ajax/convert',
                        mp4ConvertParams.toString(),
                        {
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                                'Accept': '*/*',
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        }
                    );
                    if (mp4ConvertResponse.data.status !== 'ok') {
                        throw new Error('Failed to convert the video to MP4.');
                    }
                    const mp4DownloadLink = mp4ConvertResponse.data.dlink;
                    const mp3ConvertParams = new URLSearchParams();
                    mp3ConvertParams.append('vid', videoId);
                    mp3ConvertParams.append('k', mp3Option.k);
                    const mp3ConvertResponse = await axios.post(
                        'https://tomp3.cc/api/ajax/convert',
                        mp3ConvertParams.toString(),
                        {
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                                'Accept': '*/*',
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        }
                    );
                    if (mp3ConvertResponse.data.status !== 'ok') {
                        throw new Error('Failed to convert the video to MP3.');
                    }
                    const mp3DownloadLink = mp3ConvertResponse.data.dlink;
                    resolve({
                        title: videoTitle,
                        mp4DownloadLink,
                        mp3DownloadLink
                    });
                } catch (error) {
                    reject('Error: ' + error.message);
                }
            });
        }

        async function YoriLD() {
            var leni = [
                "《 ███████▒▒▒▒▒》50%",
                "《 ██████████▒▒》80%",
                "《 ████████████》100%",
                "LOADING COMPLATE KAK✅..."
            ]
            let { key } = await Yori.sendMessage(from, { text: '🍃 *Loading*' }, { quoted: len })

            for (let i = 0; i < leni.length; i++) {
                await sleep(100)
                await Yori.sendMessage(from, { text: leni[i], edit: key }, { quoted: len });
            }
        }

        if (autodelete) {
            Yori.sendMessage(m.chat, { delete: m.key })
        }

        if (m.isBaileys && m.fromMe) {
            Yorireply(`*Siapa yang masukin YoriBotz sih😡*\n\n*YoriBotz bakalan Di Keluarin, Karena Admin Ngaktifin Anti Bot*`)
            await Yori.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
        }

        const listcolor = ['red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white']
        const randomcolor = listcolor[Math.floor(Math.random() * listcolor.length)]
        if (m.message) {
            Yori.sendPresenceUpdate(from)
            console.log(chalk.yellow.bgCyan.bold(botname), color(`⥁ Pesan`, `${randomcolor}`), color(`Dari`, `${randomcolor}`), color(`${pushname}`, `${randomcolor}`), color(` :`, `${randomcolor}`), color(`${body}`, `white`))
        }

        if (isCmd && !isUser) {
            pengguna.push(sender)
            fs.writeFileSync('./database/user.json', JSON.stringify(pengguna, null, 2))
        }

        if (m.isGroup && isAlreadyResponList(m.chat, body.toLowerCase(), db_respon_list)) {
            var get_data_respon = getDataResponList(m.chat, body.toLowerCase(), db_respon_list)
            if (get_data_respon.isImage === false) {
                Yori.sendMessage(m.chat, { text: sendResponList(m.chat, body.toLowerCase(), db_respon_list) }, {
                    quoted: m
                })
            } else {
                Yori.sendMessage(m.chat, { image: await getBuffer(get_data_respon.image_url), caption: get_data_respon.response }, {
                    quoted: m
                })
            }
        }
/*
        if (db.data.chats[m.chat].Yori_antitoxic) {
            const isToxic = /(ewe|bangsad|mmk|koncol|puki|kojtol|kintil|momok|nigga|ajg|ewean|yatim|anjing|kontol|memek|bangsat|babi|goblok|goblog|kntl|pepek|ppk|ngentod|ngentd|ngntd|kentod|kntd|bgst|anjg|anj|fuck|hitam|ireng|jawir|gay|asw|ktl|ngentot|ngewe|bkp)/i;
            if (!m.isGroup) return
            const isAntiToxic = isToxic.exec(m.text)
            if (isAntiToxic && !isCreator) {
                Yori.sendMessage(m.chat, { delete: m.key })
                await Yori.sendMessage(m.chat, { audio: fs.readFileSync('./mp3/toxic.mp3'), mimetype: 'audio/mp4', ptt: true, fileLength: 88738 }, { quoted: len })
            }
        }
  */      
        // autoai by Yori code
const SESSION_FILE = "./lib/src/autoai.json";

    async function readSession() {
      return new Promise((resolve, reject) => {
        fs.readFile(SESSION_FILE, "utf-8", (err, data) => {
          if (err) {
            if (err.code === "ENOENT") {
              console.log("Session file not found, creating a new one.");
              resolve({});
            } else {
              console.error("Error reading session file:", err);
              reject(err);
            }
          } else {
            console.log("Session file read successfully.");
            resolve(JSON.parse(data));
          }
        });
      });
    }

    async function writeSession(data) {
      return new Promise((resolve, reject) => {
        fs.writeFile(
          SESSION_FILE,
          JSON.stringify(data, null, 2),
          "utf-8",
          (err) => {
            if (err) {
              console.error("Error writing session file:", err);
              reject(err);
            } else {
              console.log("Session file written successfully.");
              resolve();
            }
          }
        );
      });
    }
    async function autoai(body, m, senderId) {
      try {
        let session = await readSession();

        if (!session[senderId]) {
          session[senderId] = { room: false, aichat: [] };
        }

        const userSession = session[senderId];

        if (!m.fromMe && !m.isBot && userSession.room && body) {
          const messages = [
            {
              role: "system",
              content: `Ini roleplay, kamu adalah wanita bernama Yori. Kamu cantik, baik hati, dan pandai merayu dengan logat nakal 💦. Kamu sekarang sedang berbicara dengan ${m.pushname}. Ingat, ${m.pushname} adalah lawan bicara mu sekarang!`,
            },
            ...userSession.aichat,
            {
              role: "user",
              content: body,
            },
          ];
          await g4f.chatCompletion(messages);

          const lolhuman = [
            {
              role: "user",
              content: `Hai 😋 namaku adalah ${m.pushname}, jangan berbicara dengan nada formal ke padaku, anggap aku teman ngobrol mu. kamu harus pake bahasa Indonesia aksen jaksel`,
            },
            {
              role: "assistant",
              content: `Salam kenal, nama ku Yori Chan, wanita si paling cantik dan imut🤭. Baiklah, aku akan berbicara seperti layaknya teman dekatmu`,
            },
            {
              role: "user",
              content: body,
            },
            {
              role: "assistant",
              content: mesg,
            },
          ];
          userSession.aichat = lolhuman;
          await writeSession(session);
        }
      } catch (e) {
        console.error("Error in autoai function:", e);
      }
    }

    async function openRoom(Yori, senderId) {
      try {
        let session = await readSession();

        if (!session[senderId]) {
          session[senderId] = { room: false, aichat: [] }; // Initialize session if it doesn't exist
        }

        session[senderId].room = true;
        await writeSession(session);

        await reply(
          `${m.pushname} berhasil membuka room chat. Kini orang lain tidak bisa mengganggu percakapanmu dengan A.I. Ketik *.autoai off* untuk menutup sesi room saat ini. *Ingat untuk menutup room sebelum kamu pergi!*`
        );
      } catch (e) {
        console.error("Error in openRoom function:", e);
      }
    }

        // Anti Link
        if (db.data.chats[m.chat].Yori_antigc) {
            if (budy.match(`chat.whatsapp.com`)) {
                let gclink = (`https://chat.whatsapp.com/` + await Yori.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isgclink) return Yorireply(`🍃 *Eh Ternyata Link Group Ini*`)
                if (isAdmins) return Yorireply(`🍃 *Ehh Halo Admin*`)
                if (isCreator) return Yorireply(`🍃 *Ehh Halo Owner Yang Bernama Haidar New*`)
                Yori.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            }
        }
        if (db.data.chats[m.chat].Yori_antigc2) {
            if (budy.match(`chat.whatsapp.com`)) {
                Yorireply(`*🍃 Anti Link Gc Whatsapp*\n⚠️ *Kamu Terdeteksi Mengirim Link Group*`)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                let gclink = (`https://chat.whatsapp.com/` + await Yori.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isgclink) return Yorireply(`🍃 *Eh Ternyata Link Group Ini*`)
                if (isAdmins) return Yorireply(`🍃 *Ehh Halo Admin*`)
                if (isCreator) return Yorireply(`🍃 *Ehh Halo Owner Yang Bernama Haidar New*`)
                Yori.sendMessage(m.chat, { delete: m.key })
            }
        }

        if (db.data.chats[m.chat].Yori_antiwame) {
            if (budy.includes('https://wa.me') || budy.includes('wa.me') || budy.includes('Https://wa.me') || budy.includes('Wa.me')) {
                Yorireply(`*🍃 Anti Wame Whatsapp*\n⚠️ *Kamu Terdeteksi Mengirim Chat Wame*`)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                let gclink = (`https://chat.whatsapp.com/` + await Yori.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isgclink) return Yorireply(`🍃 *Eh Ternyata Link Group Ini*`)
                if (isAdmins) return Yorireply(`🍃 *Ehh Halo Admin*`)
                if (isCreator) return Yorireply(`🍃 *Ehh Halo Owner*`)
                Yori.sendMessage(m.chat, { delete: m.key })
            }
        }

        if (db.data.chats[m.chat].Yori_antilink) {
            if (budy.includes('https:') || budy.includes('http') || budy.includes('Https:') || budy.includes('Http')) {
                Yorireply(`*[ LINK GROUP TERDETECT ] *\n⚠️ *Kamu Terdeteksi Mengirim Link*\n *_[ YORI Akan Segera Menghapus Link Group Tersebut ]_*`)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                let gclink = (`https://chat.whatsapp.com/` + await Yori.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isgclink) return Yorireply(`🍃 *Eh Ternyata Link Group Ini*`)
                if (isAdmins) return Yorireply(`🍃 *Ehh Halo Admin*`)
                if (isCreator) return Yorireply(`🍃 *Ehh Halo Owner*`)
                Yori.sendMessage(m.chat, { delete: m.key })
            }
        }

        if (db.data.chats[m.chat].Yori_antipanel) {
            if (budy.includes('PANEL') || budy.includes('Panel') || budy.includes('panel') || budy.includes('pnel')) {
                Yorireply(`*[ ANTI PROMOSI PANEL ]*\n⚠️ *Kamu Terdeteksi Mengirim Promosi Panel*`)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                let gclink = (`https://chat.whatsapp.com/` + await Yori.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isgclink) return Yorireply(`🍃 *Eh Ternyata Link Group Ini*`)
                if (isAdmins) return Yorireply(`🍃 *Ehh Halo Admin*`)
                if (isCreator) return Yorireply(`🍃 *Ehh Halo Owner*`)
                Yori.sendMessage(m.chat, { delete: m.key })
            }
        }

        if (db.data.chats[m.chat].Yori_antitiktok) {
            if (budy.match(`https://vt.tiktok.com`)) {
                Yorireply(`*[ Anti Link Tiktok ]*\n⚠️ *Kamu Terdeteksi Mengirim Link Tiktok*`)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                let gclink = (`https://chat.whatsapp.com/` + await Yori.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isgclink) return Yorireply(`🍃 *Eh Ternyata Link Group Ini*`)
                if (isAdmins) return Yorireply(`🍃 *Ehh Halo Admin*`)
                if (isCreator) return Yorireply(`🍃 *Ehh Halo Owner*`)
                Yori.sendMessage(m.chat, { delete: m.key })
            }
        }

        if (db.data.chats[m.chat].Yori_antiyoutube) {
            if (budy.match(`https://youtu.be`)) {
                Yorireply(`🍃 *Anti Link Youtube*\n⚠️ *Kamu Terdeteksi Mengirim Link Youtube*`)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                let gclink = (`https://chat.whatsapp.com/` + await Yori.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isgclink) return Yorireply(`🍃 *Eh Ternyata Link Group Ini*`)
                if (isAdmins) return Yorireply(`🍃 *Ehh Halo Admin*`)
                if (isCreator) return Yorireply(`🍃 *Ehh Halo Owner*`)
                Yori.sendMessage(m.chat, { delete: m.key })
            }
        }

        if (db.data.chats[m.chat].Yori_antich) {
            if (budy.includes('https://whatsapp.com/channel/') || budy.includes('https://whatsapp.com/channel/') || budy.includes('https://whatsapp.com/channel/') || budy.includes('https://whatsapp.com/channel/')) {
                Yorireply(`*🍃 Anti Channel Whatsapp*\n⚠️ *Kamu Terdeteksi Mengirim Link Channel Wa*`)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                let gclink = (`https://chat.whatsapp.com/` + await Yori.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isAdmins) return Yorireply(`🍃 *Follow Saluran Yori Yaa*`)
                if (isCreator) return Yorireply(`🍃 *Follow Saluran Yori Yaa*`)
                Yori.sendMessage(m.chat, { delete: m.key })
            }
        }

        let list = []
        for (let i of owner) {
            list.push({
                displayName: await Yori.getName(i + '@s.whatsapp.net'),
                vcard: `BEGIN:VCARD\n
VERSION:3.0\n
N:${await Yori.getName(i + '@s.whatsapp.net')}\n
FN:${await Yori.getName(i + '@s.whatsapp.net')}\n
item1.TEL;waid=${i}:${i}\n
item1.X-ABLabel:Ponsel\n
item2.EMAIL;type=INTERNET:FakeYori@gmail.com\n
item2.X-ABLabel:Email\n
item3.URL:Youtube : Yori\n
item3.X-ABLabel:Grup WangSaff\n
item4.ADR:;;Mars Area 51;;;;\n
item4.X-ABLabel:Region\n
END:VCARD`
            })
        }

        // Respon Cmd with media
        if (isMedia && m.msg.fileSha256 && (m.msg.fileSha256.toString('base64') in global.db.data.sticker)) {
            let hash = global.db.data.sticker[m.msg.fileSha256.toString('base64')]
            let { text, mentionedJid } = hash
            let messages = await generateWAMessage(from, { text: text, mentions: mentionedJid }, {
                userJid: Yori.user.id,
                quoted: m.quoted && m.quoted.fakeObj
            })
            messages.key.fromMe = areJidsSameUser(m.sender, Yori.user.id)
            messages.key.id = m.key.id
            messages.pushName = m.pushName
            if (m.isGroup) messages.participant = m.sender
            let msg = {
                ...chatUpdate,
                messages: [proto.WebMessageInfo.fromObject(messages)],
                type: 'append'
            }
            Yori.ev.emit('messages.upsert', msg)
        }        

        async function sendGeekzMessage(chatId, message, options = {}) {
            let generate = await generateWAMessage(chatId, message, options)
            let type2 = getContentType(generate.message)
            if ('contextInfo' in options) generate.message[type2].contextInfo = options?.contextInfo
            if ('contextInfo' in message) generate.message[type2].contextInfo = message?.contextInfo
            return await Yori.relayMessage(chatId, generate.message, { messageId: generate.key.id })
        }

        async function obfus(query) {
            return new Promise((resolve, reject) => {
                try {
                    const obfuscationResult = jsobfus.obfuscate(query,
                        {
                            compact: false,
                            controlFlowFlattening: true,
                            controlFlowFlatteningThreshold: 1,
                            numbersToExpressions: true,
                            simplify: true,
                            stringArrayShuffle: true,
                            splitStrings: true,
                            stringArrayThreshold: 1
                        }
                    );
                    const result = {
                        status: 200,
                        author: `Kisanak`,
                        result: obfuscationResult.getObfuscatedCode()
                    }
                    resolve(result)
                } catch (e) {
                    reject(e)
                }
            })
        }

        Yori.autoshalat = Yori.autoshalat ? Yori.autoshalat : {}
        let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? Yori.user.id : m.sender
        let id = m.chat
        if (id in Yori.autoshalat) {
            return false
        }
        let jadwalSholat = {
            shubuh: '04:39',
            terbit: '05:44',
            dhuha: '06:02',
            dzuhur: '12:02',
            ashar: '15:12',
            magrib: '17:52',
            isya: '19:01',
        }
        const datek = new Date((new Date).toLocaleString("en-US", {
            timeZone: "Asia/Jakarta"
        }));
        const hours = datek.getHours();
        const minutes = datek.getMinutes();
        const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
        for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
            if (timeNow === waktu) {
                let caption = `Hai kak @${m.sender.split("@")[0]},\nWaktu *${sholat}* telah tiba, ambilah air wudhu dan segeralah shalat😁.\n\n*${waktu}*\n_untuk wilayah Jakarta dan sekitarnya._`
                Yori.autoshalat[id] = [
                    Yorireply(caption),
                    setTimeout(async () => {
                        delete Yori.autoshalat[m.chat]
                    }, 57000)
                ]
            }
        }

        async function aigpt(prompt) {
            try {
                const response = await axios.get("https://tools.revesery.com/ai/ai.php?query=" + prompt, {
                    headers: {
                        'Accept': '*/*',
                        'Content-Type': 'application/json',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.9999.999 Safari/537.36'
                    }
                });
                const res = response.data
                const evaled = res.result
                /*
            if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
            Yorireply(evaled)
            */
            } catch (error) {
                console.error(error)
            }
        }

        async function ttslide(text) {
            let response = await axios.get(`https://dlpanda.com/id?url=${text}&token=G7eRpMaa`)
            const html = response.data
            const $ = cheerio.load(html)
            let asd = []
            let imgSrc = []
            let creator = 'Jikarinka'
            $('div.col-md-12 > img').each((index,
                element) => {
                imgSrc.push($(element).attr('src'))
            })
            asd.push({
                creator,
                imgSrc
            })
            let fix = imgSrc.map((e,
                i) => {
                return {
                    img: e,
                    creator: creator[i]
                }
            })
            for (let i of asd) {
                return i
            }
        }

        async function cai(query) {
            let token = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkVqYmxXUlVCWERJX0dDOTJCa2N1YyJ9.eyJnaXZlbl9uYW1lIjoiUkNTIiwiZmFtaWx5X25hbWUiOiJYWiIsIm5pY2tuYW1lIjoicmNzeHo2NDkiLCJuYW1lIjoiUkNTIFhaIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0lYbGpRdW11SWlQTjdwLUoxUk1HNjZ0ODZzTzJhMG9DcW93RTlZVDFzaj1zOTYtYyIsImxvY2FsZSI6ImlkIiwidXBkYXRlZF9hdCI6IjIwMjMtMTEtMDVUMTQ6NTM6NDkuNjM0WiIsImVtYWlsIjoicmNzeHo2NDlAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImlzcyI6Imh0dHBzOi8vY2hhcmFjdGVyLWFpLnVzLmF1dGgwLmNvbS8iLCJhdWQiOiJkeUQzZ0UyODFNcWdJU0c3RnVJWFloTDJXRWtucVp6diIsImlhdCI6MTY5OTE5NjAzNCwiZXhwIjoxNzAyNzk2MDM0LCJzdWIiOiJnb29nbGUtb2F1dGgyfDExMDY5MjA2MTkzMTI0MTU4NTgwNSIsInNpZCI6IjVhaklfSlRJeFBZWGpzU0piWmdzRnQ4MXhaTHRhRERyIiwibm9uY2UiOiJUQzE0V2xvMVNGSmlkVU5FWVVSbFJXb3dTV3RJU25acVRtVTRVR3hoUldReU0xQm5Rbk0yYjAwNWJ3PT0ifQ.jduu283Aycw7GwUL270EkwoF71bINRrLnFzVJGpoG9uOO4A-jxtZ07XRZIr_t4lT_gt2N19BWXg7SGxRR_coFbCJLfyUHLzxx6ZaDGMqUnCPhJ6WXBHABsTsqnlQIJs1sQPJyLKw01-FU5FoB8atW3OIyjt0nJayJtMSm4NzKkGR2gBWZSNR3FIqX7r4NY_wUSc-1Za50FaMiLg3XdGkfE59wxs_NdlxxdPVVG4G4uKBWQCIy6ofRDnnb22Wfw1knt8yXMjGfq8RtSsAkGMmjp_KVICSRDCqy0cCOtUdmih5LCRyEQagIRBl90SP753C7ehiue_ucidCYh9XrxP7HQ";
            return new Promise(async (resolve, reject) => {
                try {
                    const request = await axios({
                        method: "POST",
                        url: "https://beta.character.ai/chat/streaming/",
                        body: JSON.stringify(query),
                        headers: {
                            "authorization": "Token " + token,
                            "Content-Type": "application/json",
                            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
                            client: "Token " + token
                        }
                    })

                    if (request.status() === 200) {
                        const response = await JSON.parse(request);
                        const replies = response.replies;

                        const messages = []

                        for (let i = 0; i < replies.length; i++) {
                            Yori.sendMessage(i, { text: `${text}` }, { quoted: m })
                        }
                        resolve(i);
                    }
                } catch (error) {
                    reject(error);
                }
            })
        }

        async function tiktoks(query) {
            return new Promise(async (resolve, reject) => {
                try {
                    const response = await axios({
                        method: 'POST',
                        url: 'https://tikwm.com/api/feed/search',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                            'Cookie': 'current_language=en',
                            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
                        },
                        data: {
                            keywords: query,
                            count: 50,
                            cursor: 0,
                            HD: 1
                        }
                    });
                    const videos = response.data.data.videos;
                    if (videos.length === 0) {
                        reject("*Tidak Ada Video Yang Ditemukan* 😥");
                    } else {
                        const gywee = Math.floor(Math.random() * videos.length);
                        const videorndm = videos[gywee];

                        const result = {
                            title: videorndm.title,
                            cover: videorndm.cover,
                            origin_cover: videorndm.origin_cover,
                            no_watermark: videorndm.play,
                            watermark: videorndm.wmplay,
                            music: videorndm.music
                        };
                        resolve(result);
                    }
                } catch (error) {
                    reject(error);
                }
            });
        }

        async function tiktok2(query) {
            return new Promise(async (resolve, reject) => {
                try {
                    const encodedParams = new URLSearchParams();
                    encodedParams.set('url', query);
                    encodedParams.set('hd', '1');

                    const response = await axios({
                        method: 'POST',
                        url: 'https://tikwm.com/api/',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                            'Cookie': 'current_language=en',
                            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
                        },
                        data: encodedParams
                    });
                    const videos = response.data.data;
                    const result = {
                        title: videos.title,
                        cover: videos.cover,
                        origin_cover: videos.origin_cover,
                        no_watermark: videos.play,
                        watermark: videos.wmplay,
                        music: videos.music
                    };
                    resolve(result);
                } catch (error) {
                    reject(error);
                }
            });
        }

        const clean = (data) => {
            let regex = /(<([^>]+)>)/gi;
            data = data.replace(/(<br?\s?\/>)/gi, " \n");
            return data.replace(regex, "");
        };

        async function shortener(url) {
            return url;
        }

        async function tiktok(query) {
            let response = await axios("https://lovetik.com/api/ajax/search", {
                method: "POST",
                data: new URLSearchParams(Object.entries({ query })),
            });

            result = {};

            result.creator = "pashaamaou";
            result.title = clean(response.data.desc);
            result.author = clean(response.data.author);
            result.nowm = await shortener(
                (response.data.links[0].a || "").replace("https", "http")
            );
            result.watermark = await shortener(
                (response.data.links[1].a || "").replace("https", "http")
            );
            result.audio = await shortener(
                (response.data.links[2].a || "").replace("https", "http")
            );
            result.thumbnail = await shortener(response.data.cover);
            return result;
        }

        async function filterValidImages(images, limit) {
            const validImages = [];
            for (const image of images) {
                if (await isImageURL(image)) {
                    validImages.push(image);
                    if (validImages.length >= limit) {
                        break; // Hentikan jika sudah mencapai jumlah gambar yang diminta
                    }
                }
            }
            return validImages;
        }

        async function isImageURL(url) {
            try {
                const res = await fetch(url, { method: 'HEAD' });
                const contentType = res.headers.get('content-type');
                return contentType && contentType.startsWith('image'); // Memeriksa apakah tipe file adalah gambar
            } catch (error) {
                return false; // Jika terjadi kesalahan dalam memeriksa URL, mengembalikan false
            }
        }

        function capital(string) {
            return string.charAt(0).toUpperCase() + string.slice(1);
        }

        var createSerial = (size) => {
            return crypto.randomBytes(size).toString('hex').slice(0, size)
        }
        try {
            ppuser = await Yori.profilePictureUrl(m.sender, 'image')
        } catch (err) {
            ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
        }
        ppnyauser = await getBuffer(ppuser)

        if (kuismath.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = kuismath[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                await Yorireply(`🍃 *Kuis Matematika*\n\n🎁 *Jawaban Benar*\n\n📣 *Ingin Bermain Lagi? Silakan Ketik Math Mode*`)
                delete kuismath[m.sender.split('@')[0]]
            } else Yorireply('🍃 *Jawaban Salah!*')
        }

        if (tebakgambar.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebakgambar[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                Yori.sendMessage(m.chat, { image: ppnyauser, caption: `🍃 *Tebak Gambar*\n\n🎁 *Jawaban Benar*\n\n📣 *Ingin Bermain Lagi? Silahkan Ketik Tebak Gambar*` }, { quoted: m })
                delete tebakgambar[m.sender.split('@')[0]]
            } else Yorireply('🍃 *Jawaban Salah!*')
        }

        if (tebakkata.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebakkata[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                Yori.sendMessage(m.chat, { image: ppnyauser, caption: `🍃 *Tebak Kata*\n\n🎁 *Jawaban Benar*\n\n📣 *Ingin Bermain Lagi? Silahkan Ketik Tebak Kata*` }, { quoted: m })
                delete tebakkata[m.sender.split('@')[0]]
            } else Yorireply('🍃 *Jawaban Salah!*')
        }

        if (caklontong.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = caklontong[m.sender.split('@')[0]]
            deskripsi = caklontong_desk[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                Yori.sendMessage(m.chat, { image: ppnyauser, caption: `🍃 *Tebak Lontong*\n\n🎁 *Jawaban Benar*\n\n📣 *Ingin Bermain Lagi? Silahkan Ketik Tebak Lontong*` }, { quoted: m })
                delete caklontong[m.sender.split('@')[0]]
                delete caklontong_desk[m.sender.split('@')[0]]
            } else Yorireply('🍃 *Jawaban Salah!*')
        }

        if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebakkalimat[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                Yori.sendMessage(m.chat, { image: ppnyauser, caption: `🍃 *Tebak Kalimat*\n\n🎁 *Jawaban Benar*\n\n📣 *Ingin Bermain Lagi? Silahkan Ketik Tebak Kalimat*` }, { quoted: m })
                delete tebakkalimat[m.sender.split('@')[0]]
            } else Yorireply('🍃 *Jawaban Salah!*')
        }

        if (tebaklirik.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebaklirik[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                Yori.sendMessage(m.chat, { image: ppnyauser, caption: `🍃 *Tebak Lirik*\n\n🎁 *Jawaban Benar*\n\n📣 *Ingin Bermain Lagi? Silahkan Ketik Tebak Lirik*` }, { quoted: m })
                delete tebaklirik[m.sender.split('@')[0]]
            } else Yorireply('🍃 *Jawaban Salah!*')
        }

        if (tebaktebakan.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebaktebakan[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                Yori.sendMessage(m.chat, { image: ppnyauser, caption: `🍃 *Tebak Tebakan*\n\n🎁 *Jawaban Benar*\n\n📣 *Ingin Bermain Lagi? Silahkan Ketik Tebak Tebakan*` }, { quoted: m })
                delete tebaktebakan[m.sender.split('@')[0]]
            } else Yorireply('🍃 *Jawaban Salah!*')
        }

        //TicTacToe
        this.game = this.game ? this.game : {}
        let room = Object.values(this.game).find(room => room.id && room.game && room.state && room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender) && room.state == 'PLAYING')
        if (room) {
            let ok
            let isWin = !1
            let isTie = !1
            let isSurrender = !1
            // Yorireply(`[DEBUG]\n${parseInt(m.text)}`)
            if (!/^([1-9]|(me)?nyerah|surr?ender|off|skip)$/i.test(m.text)) return
            isSurrender = !/^[1-9]$/.test(m.text)
            if (m.sender !== room.game.currentTurn) { // nek wayahku
                if (!isSurrender) return !0
            }
            if (!isSurrender && 1 > (ok = room.game.turn(m.sender === room.game.playerO, parseInt(m.text) - 1))) {
                Yorireply({
                    '-3': 'Game telah berakhir',
                    '-2': 'Invalid',
                    '-1': 'Posisi Invalid',
                    0: 'Posisi Invalid',
                }[ok])
                return !0
            }
            if (m.sender === room.game.winner) isWin = true
            else if (room.game.board === 511) isTie = true
            let arr = room.game.render().map(v => {
                return {
                    X: '❌',
                    O: '⭕',
                    1: '1️⃣',
                    2: '2️⃣',
                    3: '3️⃣',
                    4: '4️⃣',
                    5: '5️⃣',
                    6: '6️⃣',
                    7: '7️⃣',
                    8: '8️⃣',
                    9: '9️⃣',
                }[v]
            })
            if (isSurrender) {
                room.game._currentTurn = m.sender === room.game.playerX
                isWin = true
            }
            let winner = isSurrender ? room.game.currentTurn : room.game.winner
            let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

${isWin ? `@${winner.split('@')[0]} Menang!` : isTie ? `Game berakhir` : `Giliran ${['❌', '⭕'][1 * room.game._currentTurn]} (@${room.game.currentTurn.split('@')[0]})`}
❌: @${room.game.playerX.split('@')[0]}
⭕: @${room.game.playerO.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
            if ((room.game._currentTurn ^ isSurrender ? room.x : room.o) !== from)
                room[room.game._currentTurn ^ isSurrender ? 'x' : 'o'] = from
            if (room.x !== room.o) await Yori.sendText(room.x, str, m, { mentions: parseMention(str) })
            await Yori.sendText(room.o, str, m, { mentions: parseMention(str) })
            if (isTie || isWin) {
                delete this.game[room.id]
            }
        }
        //===============
        let example = (teks) => {
            return `\n*Contoh Penggunaan :*\nketik *${command}* ${teks}\n`
        }
        //Suit PvP
        this.suit = this.suit ? this.suit : {}
        let roof = Object.values(this.suit).find(roof => roof.id && roof.status && [roof.p, roof.p2].includes(m.sender))
        if (roof) {
            let win = ''
            let tie = false
            if (m.sender == roof.p2 && /^(acc(ept)?|accept|yes|okay?|reject|no|later|nop(e.)?yes|y)/i.test(m.text) && m.isGroup && roof.status == 'wait') {
                if (/^(reject|no|later|n|nop(e.)?yes)/i.test(m.text)) {
                    Yori.sendTextWithMentions(m.chat, `@${roof.p2.split`@`[0]} rejected the suit, the suit is canceled`, m)
                    delete this.suit[roof.id]
                    return !0
                }
                roof.status = 'play'
                roof.asal = m.chat
                clearTimeout(roof.waktu)
                //delete roof[roof.id].waktu
                Yori.sendText(m.chat, `Suit has been sent to chat

@${roof.p.split`@`[0]} and 
@${roof.p2.split`@`[0]}

Please choose a suit in the respective chat"
click https://wa.me/${botNumber.split`@`[0]}`, m, { mentions: [roof.p, roof.p2] })
                if (!roof.pilih) Yori.sendText(roof.p, `Please Select \n\Rock🗿\nPaper📄\nScissors✂️`, m)
                if (!roof.pilih2) Yori.sendText(roof.p2, `Please Select \n\nRock🗿\nPaper📄\nScissors✂️`, m)
                roof.waktu_milih = setTimeout(() => {
                    if (!roof.pilih && !roof.pilih2) Yori.sendText(m.chat, `Both Players Don't Want To Play,\nSuit Canceled`)
                    else if (!roof.pilih || !roof.pilih2) {
                        win = !roof.pilih ? roof.p2 : roof.p
                        Yori.sendTextWithMentions(m.chat, `@${(roof.pilih ? roof.p2 : roof.p).split`@`[0]} Didn't Choose Suit, Game Over!`, m)
                    }
                    delete this.suit[roof.id]
                    return !0
                }, roof.timeout)
            }
            let jwb = m.sender == roof.p
            let jwb2 = m.sender == roof.p2
            let g = /scissors/i
            let b = /rock/i
            let k = /paper/i
            let reg = /^(scissors|rock|paper)/i
            if (jwb && reg.test(m.text) && !roof.pilih && !m.isGroup) {
                roof.pilih = reg.exec(m.text.toLowerCase())[0]
                roof.text = m.text
                Yorireply(`You have chosen ${m.text} ${!roof.pilih2 ? `\n\nWaiting for the opponent to choose` : ''}`)
                if (!roof.pilih2) Yori.sendText(roof.p2, '_The opponent has chosen_\nNow it is your turn', 0)
            }
            if (jwb2 && reg.test(m.text) && !roof.pilih2 && !m.isGroup) {
                roof.pilih2 = reg.exec(m.text.toLowerCase())[0]
                roof.text2 = m.text
                reply(`You have chosen ${m.text} ${!roof.pilih ? `\n\nWaiting for the opponent to choose` : ''}`)
                if (!roof.pilih) Yori.sendText(roof.p, '_The opponent has chosen_\nNow it is your turn', 0)
            }
            let stage = roof.pilih
            let stage2 = roof.pilih2
            if (roof.pilih && roof.pilih2) {
                clearTimeout(roof.waktu_milih)
                if (b.test(stage) && g.test(stage2)) win = roof.p
                else if (b.test(stage) && k.test(stage2)) win = roof.p2
                else if (g.test(stage) && k.test(stage2)) win = roof.p
                else if (g.test(stage) && b.test(stage2)) win = roof.p2
                else if (k.test(stage) && b.test(stage2)) win = roof.p
                else if (k.test(stage) && g.test(stage2)) win = roof.p2
                else if (stage == stage2) tie = true
                Yori.sendText(roof.asal, `_*Suit Results*_${tie ? '\nSERIES' : ''}

@${roof.p.split`@`[0]} (${roof.text}) ${tie ? '' : roof.p == win ? ` Win \n` : ` Lost \n`}
@${roof.p2.split`@`[0]} (${roof.text2}) ${tie ? '' : roof.p2 == win ? ` Win \n` : ` Lost  \n`}
`.trim(), m, { mentions: [roof.p, roof.p2] })
                delete this.suit[roof.id]
            }
        } //end
        let mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
        for (let jid of mentionUser) {
            let user = global.db.data.users[jid]
            if (!user) continue
            let afkTime = user.afkTime
            if (!afkTime || afkTime < 0) continue
            let reason = user.afkReason || ''
            Yorireply(`⚠️ *Jangan Tag Dia!*
⚠️ *Dia Sedang AFK* ${reason ? '*Dengan Alasan : ' + reason : 'tanpa alasan*'}
🕒 *Selama : ${clockString(new Date - afkTime)}*
`.trim())
        }
        if (global.db.data.users[m.sender].afkTime > -1) {
            let user = global.db.data.users[m.sender]
            Yorireply(`
🍃 *${pushname} Kembali Dari Afk*\n⚠️ ${user.afkReason ? '*Dengan Alasan :  ' + user.afkReason : ''}*\n🕒 *Selama : ${clockString(new Date - user.afkTime)}*
`.trim())
            user.afkTime = -1
            user.afkReason = ''
        }

        const totalFitur = () => {
            var mytext = fs.readFileSync("./Yori.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }
        
        const fcall = {
      key: {
        fromMe: false,
        participant: `0@s.whatsapp.net`,
        ...(from ? { remoteJid: "status@broadcast" } : {}),
      },
      message: { extendedTextMessage: { text: body } },
    };
    
    const sendmes = (hua, teks) => {
      Yori.sendMessage(
        hua,
        {
          document: fs.readFileSync("./lib/jomok.js"),
          fileName: `${ucapanWaktu}`,
          caption: teks,
          mimetype: "application/html",
          headerType: 9,
          jpegThumbnail: fs.readFileSync("./data/image/menu.jpg"),
          contextInfo: {
            mentionedJid: [m.sender],
            externalAdReply: {
              title: Styles("Yori Chan - New 2024"),
              body: Styles("Bot whatsapp made in ErerexID Chx"),
              thumbnailUrl: "",
              showAdAttribution: true,
              renderLargerThumbnail: true,
              mediaType: 1,
              MediaUrl: "",
              sourceUrl: ``,
            },
          },
        },
        { quoted: fcall, ephemeralExpiration: 86400 },
      );
    };

        switch (command) {
case "clan":
      case "clans":
        {
          if (!isGroup) return Yorireply('Features only for group!!')
          await Yori.sendMessage(m.chat, { react: { text: `🔎`, key: m.key } });
          let jimp = require("jimp");
          const resizeImage = async (image, width, height) => {
            const readImage = await jimp.read(image);
            const resizedImage = await readImage
              .resize(width, height)
              .getBufferAsync(jimp.MIME_JPEG);
            return resizedImage;
          };

          let thumbUrl = "https://telegra.ph/file/048d31385faac531d20c6.jpg";
          const {
            playerOnClan,
            readClans,
            writeClans,
            setMissions,
            upgradeMissonProgress,
            updateClanTaskProgress,
            upgradeClanLevel,
            simulateWinner,
            getClanData,
            saveClanData,
            saveTournamentData,
          } = require("./scrape/clan");

          async function startNextMatch(tournament) {
            let nextMatch = tournament.matches.find(
              (match) => match.status === "pending",
            );
            if (!nextMatch) {
              tournament.status = "completed";
              clans.currentTournament = null;

              let winnerClan = tournament.participants[0];
              let winningClanData = await getClanData(winnerClan);

              winningClanData.power += 1000;
              winningClanData.level += 5;

              saveClanData(winnerClan, winningClanData);

              await Yorireply(
                `Turnamen ${tournament.name} selesai! Pemenangnya adalah ${winnerClan}. Clan ini mendapatkan 1000 power dan naik 5 level.`,
              );
              return;
            }

            let clan1Data = await getClanData(nextMatch.clan1);
            let clan2Data = await getClanData(nextMatch.clan2);

            nextMatch.status = "ongoing";
            writeClans(clans);

            let winner = simulateWinner(clan1Data, clan2Data);
            nextMatch.winner = winner;
            nextMatch.status = "completed";

            tournament.participants = tournament.participants.filter(
              (clan) =>
                clan !==
                (winner === clan1Data.clan ? clan2Data.clan : clan1Data.clan),
            );

            writeClans(clans);

            await Yorireply(
              `Pertandingan antara ${clan1Data.clan} dan ${clan2Data.clan} selesai! Pemenangnya adalah ${winner}.`,
            );

            setTimeout(() => startNextMatch(tournament), 5000);
          }

          const { sender, chat } = m;
          const clans = readClans();
          const clanData = clans[chat];
          const action = args[0];
          const param1 = args[1];
          const param2 = args[2];

          switch (action) {
            case "create":
              let existingUserClan = Object.values(clans).find(
                (c) => c.owner === sender.replace("@s.whatsapp.net", ""),
              );
              if (existingUserClan) return Yorireply("Anda sudah memiliki clan.");
              let createText = `*Horee, Clan berhasil dibuat*`;
              clans[param1.toLowerCase()] = {
                room: param1,
                owner: sender.replace("@s.whatsapp.net", ""),
                status: false,
                clan: param1,
                members: [],
                joinRequests: [],
                level: 1,
                warLimit: 5,
                currentWarCount: 0,
                missions: {
                  daily: {
                    description: "Rekrut 5 anggota baru",
                    progress: 0,
                    target: 5,
                    reward: 100,
                  },
                  weekly: {
                    description: "Menangkan 3 perang",
                    progress: 0,
                    target: 3,
                    reward: 500,
                  },
                },
                clanTasks: {
                  description: "Capai level 3",
                  progress: 1,
                  target: 3,
                  reward: 300,
                },
              };
              createText += `\n\nUntuk Join Ke Clans Silahkan Ketik .clan join nama clan mu.`;
              writeClans(clans);
              await Yorireply(createText.trim());
              break;

            case "join":
              if (!param1)
                return Yorireply(
                  "Silakan masukkan nama clan yang ingin Anda ikuti.",
                );

              let userClanCheck = Object.values(clans).find(
                (c) => c.members && c.members.some((m) => m.id === sender),
              );
              if (userClanCheck)
                return Yorireply("Anda sudah bergabung ke clan lain.");

              let targetJoinClan = Object.values(clans).find(
                (c) => c.clan.toLowerCase() === param1.toLowerCase(),
              );
              if (!targetJoinClan)
                return Yorireply("Clan yang ingin Anda ikuti tidak ditemukan.");
              if (playerOnClan(sender, chat, clans) === true)
                return Yorireply("Anda sudah bergabung dalam clan ini.");

              let joinData = {
                id: sender,
                number: targetJoinClan.members
                  ? targetJoinClan.members.length + 1
                  : 1,
                sesi: chat,
                status: false,
                clan: param1,
                vote: 0,
                isvote: false,
              };

              if (!targetJoinClan.joinRequests) {
                targetJoinClan.joinRequests = [];
              }

              targetJoinClan.joinRequests.push(joinData);
              writeClans(clans);

              let joinText = `Permintaan bergabung telah dikirim ke clan ${targetJoinClan.clan}. Tunggu persetujuan dari leader clan.`;
              Yorireply(joinText);
              break;

            case "approve":
              if (!param1)
                return Yorireply(
                  "Silakan masukkan nama clan yang ingin Anda lihat.",
                );
              let approveClan = Object.values(clans).find(
                (c) => c.clan.toLowerCase() === param1.toLowerCase(),
              );
              if (!approveClan) return Yorireply("Clan tidak ditemukan.");

              if (approveClan.owner !== sender.replace("@s.whatsapp.net", ""))
                return Yorireply(
                  "Anda tidak memiliki izin untuk menyetujui permintaan join.",
                );

              if (
                !approveClan.joinRequests ||
                approveClan.joinRequests.length === 0
              )
                return Yorireply(
                  "Tidak ada permintaan bergabung yang menunggu persetujuan.",
                );

              let approveText = "";

              if (param2 === "all") {
                let approvedMembers = [];
                approveClan.joinRequests.forEach((request) => {
                  targetJoinClan.members.push({
                    id: request.id,
                    number: approveClan.members.length + 1,
                    sesi: chat,
                    status: false,
                    clan: request.clan,
                    vote: 0,
                  });
                  approvedMembers.push(request.id);
                  approveText += `Permintaan bergabung dari @${request.id.replace("@s.whatsapp.net", "")} telah disetujui.\n`;
                });
                approveClan.joinRequests = [];
                writeClans(clans);
              } else if (param2) {
                let index = parseInt(param2) - 1;
                if (
                  isNaN(index) ||
                  index < 0 ||
                  index >= approveClan.joinRequests.length
                )
                  return Yorireply("Nomor urut tidak valid.");

                let requester = approveClan.joinRequests[index];
                approveClan.joinRequests.splice(index, 1);
                approveClan.members.push({
                  id: requester.id,
                  number: approveClan.members.length + 1,
                  sesi: chat,
                  status: false,
                  clan: requester.clan,
                  vote: 0,
                });
                approveText = `Permintaan bergabung dari @${requester.id.replace("@s.whatsapp.net", "")} telah disetujui.`;
                writeClans(clans);
              } else {
                let pendingRequestsText = `Silakan tentukan apakah Anda ingin menyetujui semua permintaan bergabung ( all ) atau permintaan bergabung dari seorang pengguna tertentu.\n\n`;
                pendingRequestsText += "*Daftar Permintaan Bergabung:*\n";
                approveClan.joinRequests.forEach((request, index) => {
                  pendingRequestsText += `${index + 1}. @${request.id.replace("@s.whatsapp.net", "")}\n`;
                });

                pendingRequestsText +=
                  "\nUntuk menyetujui permintaan per orangan, gunakan perintah '.clan approve [nomor urut]'";
                return Yorireply(pendingRequestsText.trim());
              }

              await Yorireply(approveText);
              break;

            case "war":
              let warInitiatorClan = Object.values(clans).find(
                (c) => c.owner === sender.replace("@s.whatsapp.net", ""),
              );
              if (!warInitiatorClan)
                return Yorireply("Anda tidak memiliki clan untuk memulai perang.");

              if (warInitiatorClan.currentWarCount >= warInitiatorClan.warLimit)
                return Yorireply(
                  `Limit perang harian Anda sudah habis (${warInitiatorClan.currentWarCount}/${warInitiatorClan.warLimit}).`,
                );

              let warTargetClan = Object.values(clans).filter(
                (c) => c.clan !== warInitiatorClan.clan,
              );
              if (warTargetClan.length === 0)
                return Yorireply(
                  "Tidak ada clan lain yang ditemukan untuk perang.",
                );

              warTargetClan =
                warTargetClan[Math.floor(Math.random() * warTargetClan.length)];

              if (warInitiatorClan.war || warTargetClan.war)
                return Yorireply(
                  "Salah satu atau kedua clan sedang dalam status perang.",
                );

              let initiatorPower =
                warInitiatorClan.level * warInitiatorClan.members.length;
              let targetPower =
                warTargetClan.level * warTargetClan.members.length;
              let winnerClan =
                initiatorPower >= targetPower
                  ? warInitiatorClan
                  : warTargetClan;
              let loserClan =
                initiatorPower < targetPower ? warInitiatorClan : warTargetClan;
              let warReward = Math.floor(Math.random() * 3) + 1;

              winnerClan.level += 1; 
              winnerClan.warLimit += warReward;
              winnerClan.currentWarCount += 1;
              loserClan.currentWarCount += 1;

              if (winnerClan.missions && winnerClan.missions.daily) {
                if (
                  winnerClan.missions.daily.description.includes("Capai level")
                ) {
                  winnerClan.missions.daily.progress = winnerClan.level;
                  if (
                    winnerClan.missions.daily.progress >=
                    winnerClan.missions.daily.target
                  ) {
                    winnerClan.warLimit += winnerClan.missions.daily.reward;
                    winnerClan.missions.daily.completed = true;
                  }
                }
              }

              if (winnerClan.missions && winnerClan.missions.weekly) {
                if (
                  winnerClan.missions.weekly.description.includes("Capai level")
                ) {
                  winnerClan.missions.weekly.progress = winnerClan.level;
                  if (
                    winnerClan.missions.weekly.progress >=
                    winnerClan.missions.weekly.target
                  ) {
                    winnerClan.warLimit += winnerClan.missions.weekly.reward;
                    winnerClan.missions.weekly.completed = true;
                  }
                }
              }

              let warResultText = `*Hasil Perang:*\n\n`;
              warResultText += `Pemenang: ${winnerClan.clan} (Level ${winnerClan.level})\n`;
              warResultText += `Kalah: ${loserClan.clan} (Level ${loserClan.level})\n`;
              warResultText += `Clan ${winnerClan.clan} mendapatkan reward tambahan limit perang sebesar ${warReward}.\n\n`;
              warResultText += `Jumlah perang harian ${warInitiatorClan.clan}: ${warInitiatorClan.currentWarCount}/${warInitiatorClan.warLimit}`;
              writeClans(clans);
              await Yorireply(warResultText.trim());
              break;

            case "list":
              let listText = `*Daftar Clan:*\n\n`;
              for (let clanKey in clans) {
                if (
                  clanKey === "tournaments" ||
                  clanKey === "currentTournament"
                )
                  continue; 

                let clan = clans[clanKey];
                if (clan && clan.members) {
                  let warLimitDisplay =
                    clan.warLimit !== null && clan.warLimit !== undefined
                      ? clan.warLimit
                      : 3;
                  listText += `Nama Clan: ${clan.clan}\n`;
                  listText += `Level: ${clan.level}\n`;
                  listText += `Jumlah Anggota: ${clan.members.length}\n`;
                  listText += `Limit Perang Harian: ${clan.currentWarCount}/${warLimitDisplay}\n\n`;
                }
              }
              await Yorireply(listText.trim());
              break;

            case "leave":
              let userClan = Object.values(clans).find(
                (c) => c.members && c.members.some((m) => m.id === sender),
              );
              if (!userClan)
                return Yorireply("Anda tidak tergabung dalam clan manapun.");

              userClan.members = userClan.members.filter(
                (m) => m.id !== sender,
              );
              writeClans(clans);
              await Yorireply(`Anda telah keluar dari clan ${userClan.clan}.`);
              break;

            case "delete":
              let deleteClan = Object.values(clans).find(
                (c) => c.owner === sender.replace("@s.whatsapp.net", ""),
              );
              if (!deleteClan)
                return Yorireply("Anda tidak memiliki clan untuk dihapus.");

              delete clans[deleteClan.clan.toLowerCase()];
              writeClans(clans);
              await Yorireply(`Clan ${deleteClan.clan} telah dihapus.`);
              break;

            case "member":
              let targetClanMember = Object.values(clans).find(
                (c) => c.clan.toLowerCase() === param1.toLowerCase(),
              );
              if (!targetClanMember)
                return Yorireply("Clan yang Anda cari tidak ditemukan.");

              let memberText = `*Daftar Anggota Clan ${targetClanMember.clan}:*\n\n`;
              targetClanMember.members.forEach((member, index) => {
                memberText += `${index + 1}. @${member.id.replace("@s.whatsapp.net", "")}\n`;
              });
              await Yorireply(memberText.trim());
              break;

            case "missions":
              let missionsClan = Object.values(clans).find(
                (c) => c.owner === sender.replace("@s.whatsapp.net", ""),
              );
              if (!missionsClan)
                return Yorireply("Anda tidak memiliki clan untuk melihat misi.");

              let missionsText = `*Misi Clan ${missionsClan.clan}:*\n\n`;
              if (missionsClan.missions && missionsClan.missions.daily) {
                missionsText += `Misi Harian: ${missionsClan.missions.daily.description}\n`;
                missionsText += `Progres: ${missionsClan.missions.daily.progress}/${missionsClan.missions.daily.target}\n`;
                missionsText += `Reward: ${missionsClan.missions.daily.reward}\n\n`;
              }
              if (missionsClan.missions && missionsClan.missions.weekly) {
                missionsText += `Misi Mingguan: ${missionsClan.missions.weekly.description}\n`;
                missionsText += `Progres: ${missionsClan.missions.weekly.progress}/${missionsClan.missions.weekly.target}\n`;
                missionsText += `Reward: ${missionsClan.missions.weekly.reward}\n\n`;
              }
              await Yorireply(missionsText.trim());
              break;

            case "task":
              let taskClan = Object.values(clans).find(
                (c) => c.owner === sender.replace("@s.whatsapp.net", ""),
              );
              if (!taskClan)
                return Yorireply("Anda tidak memiliki clan untuk melihat tugas.");

              let taskText = `*Tugas Clan ${taskClan.clan}:*\n\n`;
              if (taskClan.clanTasks) {
                taskText += `Deskripsi Tugas: ${taskClan.clanTasks.description}\n`;
                taskText += `Progres: ${taskClan.clanTasks.progress}/${taskClan.clanTasks.target}\n`;
                taskText += `Reward: ${taskClan.clanTasks.reward}\n`;
              } else {
                taskText += "Tidak ada tugas saat ini.";
              }
              await Yorireply(taskText.trim());
              break;

            case "upgrade":
              let upgradeClan = Object.values(clans).find(
                (c) => c.owner === sender.replace("@s.whatsapp.net", ""),
              );
              if (!upgradeClan)
                return Yorireply(
                  "Anda tidak memiliki clan untuk melakukan upgrade.",
                );

              let upgradeCost = upgradeClan.level * 1000; // Contoh: biaya upgrade berdasarkan level klan
              if (upgradeClan.level < upgradeClan.clanTasks.target) {
                upgradeClan.level += 1;
                upgradeClan.clanTasks.progress += 1;
                writeClans(clans);
                await Yorireply(
                  `Clan ${upgradeClan.clan} berhasil di-upgrade ke level ${upgradeClan.level}.`,
                );
              } else {
                await Yorireply(
                  "Clan Anda sudah mencapai level maksimum untuk tugas saat ini.",
                );
              }
              break;
            case "tournament":
              const subAction = param1;

              switch (subAction) {
                case "create":
                  if (!param2)
                    return Yorireply(
                      "Silakan masukkan nama turnamen yang ingin Anda buat.",
                    );

                  let tournamentName = param2;
                  if (!clans.tournaments) {
                    clans.tournaments = {};
                  }

                  if (clans.currentTournament)
                    return Yorireply(
                      "Saat ini sedang berlangsung turnamen. Tunggu hingga turnamen selesai.",
                    );

                  if (clans.tournaments[tournamentName])
                    return Yorireply("Turnamen dengan nama tersebut sudah ada.");

                  clans.currentTournament = tournamentName;

                  clans.tournaments[tournamentName] = {
                    name: tournamentName,
                    participants: [],
                    status: "pending",
                    matches: [],
                  };

                  writeClans(clans);
                  await Yorireply(`Turnamen ${tournamentName} berhasil dibuat.`);
                  break;

                case "join":
                  let currentTournamentName = clans.currentTournament;
                  if (!currentTournamentName)
                    return Yorireply("Tidak ada turnamen yang sedang berlangsung.");

                  let joinTournament = clans.tournaments[currentTournamentName];

                  let joinUserClan = Object.values(clans).find(
                    (c) => c.owner === sender.replace("@s.whatsapp.net", ""),
                  );
                  if (!joinUserClan)
                    return Yorireply(
                      "Anda tidak memiliki clan untuk mengikuti turnamen.",
                    );

                  if (joinTournament.participants.includes(joinUserClan.clan))
                    return Yorireply("Clan Anda sudah terdaftar di turnamen ini.");

                  joinTournament.participants.push(joinUserClan.clan);
                  writeClans(clans);
                  await Yorireply(
                    `Clan ${joinUserClan.clan} berhasil mendaftar ke turnamen ${currentTournamentName}.`,
                  );
                  break;

                case "start":
                  let startTournamentName = clans.currentTournament;
                  if (!startTournamentName)
                    return Yorireply("Tidak ada turnamen yang sedang berlangsung.");

                  let startTournament = clans.tournaments[startTournamentName];

                  if (startTournament.status !== "pending")
                    return Yorireply("Turnamen sudah dimulai atau selesai.");

                  if (
                    startTournament.participants.length < 2 ||
                    startTournament.participants.length % 2 !== 0
                  ) {
                    return Yorireply(
                      "Jumlah peserta turnamen harus genap dan minimal 2 clan untuk memulai.",
                    );
                  }

                  startTournament.participants =
                    startTournament.participants.sort(
                      () => Math.random() - 0.5,
                    );

                  while (startTournament.participants.length > 1) {
                    for (
                      let i = 0;
                      i < startTournament.participants.length;
                      i += 2
                    ) {
                      if (startTournament.participants[i + 1]) {
                        startTournament.matches.push({
                          clan1: startTournament.participants[i],
                          clan2: startTournament.participants[i + 1],
                          status: "pending",
                        });
                      }
                    }
                    startTournament.participants =
                      startTournament.participants.filter(
                        (_, index) => index % 2 === 0,
                      );
                  }

                  startTournament.status = "ongoing";
                  clans.currentTournament = startTournamentName;
                  writeClans(clans);

                  await Yorireply(`Turnamen ${startTournamentName} dimulai!`);

                  startNextMatch(startTournament);
                  break;

                case "status":
                  let statusTournamentName = clans.currentTournament;
                  if (!statusTournamentName)
                    return Yorireply("Tidak ada turnamen yang sedang berlangsung.");

                  let statusTournament =
                    clans.tournaments[statusTournamentName];

                  let statusText = `*Status Turnamen ${statusTournamentName}:*\n\n`;
                  statusText += `Status: ${statusTournament.status}\n`;
                  statusText += `Peserta: ${statusTournament.participants.join(", ")}\n\n`;
                  statusText += `Daftar Pertandingan:\n`;
                  statusTournament.matches.forEach((match, index) => {
                    statusText += `${index + 1}. ${match.clan1} vs ${match.clan2} - ${match.status === "completed" ? "Selesai" : "Pending"}\n`;
                  });

                  await Yorireply(statusText.trim());
                  break;

                default:
                  await Yorireply(
                    "Perintah turnamen tidak valid. Gunakan create, join, start, atau status.",
                  );
                  break;
              }
              break;

            default:
              await Yorireply(
                "Perintah tidak dikenal. Silakan gunakan create, join, approve, war, list, leave, delete, member, missions, task, upgrade, atau tournament.",
              );
              break;
          }
        }
        break;
        /*
        case 'register': {
    if (global.db.data.users[m.sender].registered) {
        return Yorireply(`[ NOTICE ] *Kamu sudah terdaftar!*\nKetik *.menu* untuk melihat fitur yang tersedia.`)
    }
    if (!text) return Yorireply(`[ NOTICE ] *Format salah!*\n\nSilakan gunakan format: *.register [Nama]*\nContoh: *.register Yori`)
    global.db.data.users[m.sender] = {
        registered: true,
        name: text
    }
    Yorireply(`✅ *Berhasil terdaftar!*\nSelamat datang, *${text}*! Kamu sekarang bisa mengakses fitur bot.`)
}
*/
/*
case 'daftar': case 'regis': case 'register': {
try {
   var ppuser = await Yori.profilePictureUrl(m.sender, 'image')
} catch (err) {
   var ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
if (isRegistered) return m.reply('Kamu sudah terdaftar!!')
const serialUser = createSerial(20)
mzd = `「 BERHASIL REGISTER 」

  • Phone Nunber : @${m?.sender.split('@')[0]}
  • Name User : ${pushname}
  • Status Verify : Berhasil
  • ID User : ${serialUser}

SILAHKAN GUNAKAN BOT DENGAN BAIK. Untuk Melihat Menu Ketik .menu`
veri = m?.sender
if (!m.isGroup) {
addRegisteredUser(m?.sender, pushname, serialUser)
Yori.sendMessage(m?.chat, {
text: mzd,
contextInfo: {
mentionedJid: [m?.chat],
externalAdReply: {
showAdAttribution: true,
title: `R E G I S T E R E D`,
body: 'Yori Chan - Multi Device',
thumbnailUrl: ppuser,
sourceUrl: hariini,
mediaType: 1,
renderLargerThumbnail: true
}}
})
} else {
addRegisteredUser(m?.sender, pushname, serialUser)
Yori.sendMessage(m?.chat, {
text: mzd,
contextInfo: {
mentionedJid: [m?.chat],
externalAdReply: {
showAdAttribution: true,
title: `R E G I S T E R`,
body: 'Yori Chan - Multi Device',
thumbnailUrl: ppuser,
sourceUrl: hariini,
mediaType: 1,
renderLargerThumbnail: true
}}
})
}
}
*/
case 'daftar': case 'regis': case 'register': {
    try {
        var ppuser = await Yori.profilePictureUrl(m.sender, 'image')
    } catch (err) {
        var ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
    }
    if (checkRegisteredUser(m.sender)) {
        return m.reply('⚠️ Kamu sudah terdaftar! Tidak perlu daftar lagi, cukup gunakan perintah .menu untuk melihat fitur-fitur menarik kami.');
    }

    const serialUser = createSerial(20);
    const randomEmojis = ['🔥', '🚀', '✨', '🎉', '💫'];
    const emoji = randomEmojis[Math.floor(Math.random() * randomEmojis.length)];
    
    // Pesan yang lebih interaktif dan ramah
    const mzd = `${emoji} *「 ᴘᴇɴᴅᴀғᴛᴀʀᴀɴ ʙᴇʀʜᴀsɪʟ 」* ${emoji}
    sᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ dɪ ᴅᴜɴɪᴀ ʙᴏᴛ ᴋᴀᴍɪ! ʙᴇʀɪᴋᴜᴛ ᴅᴇᴛᴀɪʟ ᴀᴋᴜɴ ᴋᴀᴍᴜ:

    • 📱 *ɴᴏᴍᴇʀ ᴛᴇʟᴇᴘᴏɴ*: @${m?.sender.split('@')[0]}
    • 👤 *ɴᴀᴍᴀ ᴘᴇɴɢɢᴜɴᴀ* : ${pushname}
    • 🛡️ *sᴛᴀᴛᴜs ᴠᴇʀɪғɪᴋᴀsɪ* : *Berhasil*
    • 🆔 *ID ᴘᴇɴɢɢᴜɴᴀ* : ${serialUser}

    ᴛᴇʀɪᴍᴀ ᴋᴀsɪʜ sᴜᴅᴀʜ ᴍᴇɴᴅᴀғᴛᴀʀ ᴅɪ ᴅᴀᴛᴀʙᴀsᴇ ʏᴏʀɪ ᴄʜᴀɴ!! 
    ᴋᴇᴛɪᴋ/ᴘᴇɴᴄᴇᴛ ʙᴜᴛᴛᴏɴ *.ᴍᴇɴᴜ* ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ғɪᴛᴜʀ-ғɪᴛᴜʀ ᴋᴇʀᴇɴ ʏᴀɴɢ ʙɪsᴀ ᴋᴀᴍᴜ ᴄᴏʙᴀ!`;
    veri = m?.sender
    const baten = new Button();
    let ads = baten.setBody(mzd);
    ads += baten.setImage(ppuser); // Thumbnail dari ppuser
    ads += baten.addReply("Menu", `#menu`);
    addRegisteredUser(m?.sender, pushname, serialUser);
    ads += baten.run(m.chat, Yori, m);
  }
        break;
        
            case 'menu': {
                let own = "62895342022385@s.whatsapp.net"
                let time = `${moment().tz('Asia/Jakarta').format('HH:mm:ss')}`
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                await YoriLD()
                await sleep()
                let anu = ``

                let sections = [{
                    title: 'All menu Yori Chan ( All )',
                    highlight_label: 'Allmenu',
                    rows: [{
                        title: 'All menu',
                        description: `Displays All menu ( Allmenu )`,
                        id: '.allmenu'
                    }]
                },               
                {
                    title: 'Populer menu ( List menu )',
                    highlight_label: 'Populer Plugins',
                    rows: [{
                        title: 'Download Feature',
                        description: `Displays menu Download ( List menu )`,
                        id: '.downmenu'
                    },
                    {
                        title: 'List Menu',
                        description: "Displays untuk menampilkan ( Menu List )",
                        id: '.menulist'
                    },                  
                    {
                        title: 'Pencarian Film XXI',
                        description: "Displays untuk menampilkan ( Pencarian Film )",
                        id: '.film'
                    },                   
                    {
                        title: 'Random menu',
                        description: "Displays menu Random ( List menu )",
                        id: '.randommenu'
                    },                   
                    {
                        title: 'Chat Ai',
                        description: "Displays Chat Ai ( Chat Botz Ai )",
                        id: '.autoai'
                    },
                    {
                        title: 'Ai Feature',
                        description: "Displays menu Ai ( Ai List menu )",
                        id: '.aimenu'
                    },
                    {
                        title: 'Game Feature',
                        description: "Displays menu Game ( List menu )",
                        id: '.gamemenu'
                    },
                    {
                        title: 'Favorit menu',
                        description: "Displays menu Favorit ( List menu )",
                        id: '.favmenu'
                    }]
                },
                {
                    title: 'System Information ( info )',
                    highlight_label: 'CONTACT ADMIN',
                    rows: [{
                        title: 'Creator Bot',
                        description: `Bot owner info, who created it ( information )`,
                        id: '.owner'
                    },
                    {
                        title: 'Sewa & Premium',
                        description: "Displays Rental and Premium List  ( Buying )",
                        id: '.sewabot'
                    },
                    {
                        title: 'Info System',
                        description: "Viewing System Info on Bot ( information )",
                        id: '.botstatus'
                    },
                    {
                        title: 'Payment',
                        description: "Viewing Paymet on Bot ( Pembayaran )",
                        id: '.pembayaran'
                    },
                    {
                        title: 'Script Info',
                        description: "Source Code Bot WhatsApp Info ( information )",
                        id: '.sc'
                    },
                    {
                        title: 'Runtime Info',
                        description: "View Runtime Bot WhatsApp Info ( information )",
                        id: '.runtime'
                    },
                    {
                        title: 'Fitur Info',
                        description: "View Total Fitur Bot ( information )",
                        id: '.totalfitur'
                    },
                    {
                        title: 'List Info',
                        description: "Viewing on Bot Info ( information )",
                        id: '.menulist'
                    },
                    {
                        title: 'Donate Info',
                        description: "Donate to Support Bot ( information )",
                        id: '.donasi'
                    }]
                }]

                let listMessage = {
                    title: '「 List Menu 」',
                    sections
                };


                let msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            "messageContextInfo": {
                                "deviceListMetadata": {},
                                "deviceListMetadataVersion": 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                contextInfo: {
                                    mentionedJid: [m?.sender],
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: '120363204138641225@newsletter',
                                        newsletterName: `Yori Chan | New 2023 - 2024`,
                                        serverMessageId: -1
                                    },
                                    businessMessageForwardInfo: {
                                        businessOwnerJid: Yori.decodeJid(Yori.user.id)
                                    },
                                    externalAdReply: {
                                        title: 'ʚ Yori Chan • マルチデバイス ɞ',
                                        body: `Bʏ ErerexID Chx`,
                                        thumbnail: fs.readFileSync("./data/image/menu.jpg"),
                                        sourceUrl: '',
                                        mediaType: 1,
                                        renderLargerThumbnail: true
                                    }
                                },
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: anu
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: `
ʜᴀɪ ᴋᴀᴋ ${ucapanWaktu}

sᴀʏᴀ ᴀᴅᴀʟᴀʜ ${global.botname} sᴇʙᴜᴀʜ ᴘʀᴏɢʀᴀᴍ ʏᴀɴɢ ᴅɪʀᴀɴᴄᴀɴɢ sᴇᴅᴇᴍɪᴋɪᴀɴ ʀᴜᴘᴀ ᴜɴᴛᴜᴋ ᴍᴇᴍʙᴜᴀᴛ ᴘᴀʀᴀ ᴘᴇɴɢɢᴜɴᴀ ᴍᴜᴅᴀʜ ᴅᴀʟᴀᴍ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ʙᴏᴛ ɪɴɪ. ʙᴇʀʙᴀɢᴀɪ ғɪᴛᴜʀ ᴍᴇɴᴀʀɪᴋ ᴅᴀɴ ʙᴇʀɢᴜɴᴀ ʙɪsᴀ ᴋᴀʟɪᴀɴ ᴅᴀᴘᴀᴛᴋᴀɴ ᴅɪ ${global.botname}

┏❐  ⌜ Yori - Chan ⌟  ❐
┃⭔ ᴄʀᴇᴀᴛᴏʀ : ${ownername}
┃⭔ ʟɪʙʀᴀʀʏ ᴘʟᴀᴛғᴏʀᴍ : Linux
┃⭔ ᴛʏᴘᴇ : Case
┃⭔ ᴍᴏᴅᴇ : ${Yori.public ? '✱ Public ༣' : '✲ Self ༣'}
┃⭔ ᴜsᴇʀ ᴅᴀᴛᴀʙᴀsᴇ : ${Object.keys(global.db.data.users).length} User
┗❐

┏❐ ⌜ Info User ⌟ ❐
┃⭔ ɴᴀᴍᴇ ᴜsᴇʀ : *${pushname}*
┃⭔ ɴᴜᴍʙᴇʀ : @${m.sender.split('@')[0]}
┃⭔ sᴛᴀᴛᴜs : *${isCreator ? "🍃 Owner" : "🏷️ User"}*
┗❐
 
[ ᴛʜᴀɴᴋs ᴛᴏ ᴄᴏɴᴛʀɪʙᴜᴛɪᴏɴs ]
- ᴀʟʟᴀʜ sᴡᴛ ( ᴍʏ ɢᴏᴅ ) 
- ᴏʀᴀɴɢ ᴛᴜᴀ
- ʟᴇɴᴡʏ ( ʙᴀsᴇ ) 
- ᴇʀᴇʀᴇxɪᴅ ( ᴄᴏɴᴛʀɪʙᴜᴛɪᴏɴ ) 
- ᴀᴅʀɪᴀɴ ( ᴄᴏɴᴛʀɪʙᴜᴛɪᴏɴ & ғɪxᴇᴅ ) 
- ᴋʏᴜᴜ ( ᴄᴏɴᴛʀɪʙᴜᴛɪᴏɴ & ғɪxᴇᴅ ) 
- ᴀʟʟ ғᴀᴍɪʟʏ 
- ᴀʟʟ ᴄʀᴇᴀᴛᴏʀᴅ
`
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    title: `*${ucapanWaktu}, @${m.sender.split("@")[0]}*\n`,
                                    thumbnailUrl: "",
                                    gifPlayback: true,
                                    subtitle: "Provided By ErerexID Chx",
                                    hasMediaAttachment: true,
                                    ...(await prepareWAMessageMedia({
                                        document: fs.readFileSync('./src/package.json'),
                                        mimetype: "application/msword",
                                        jpegThumbnail: fs.readFileSync("./data/image/profile.jpg"),
                                        fileName: "Yori Chan ✿✿✿✿",
                                    }, {
                                        upload: Yori.waUploadToServer
                                    }))
                                }),
                                gifPlayback: true,
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            "name": "single_select",
                                            "buttonParamsJson": JSON.stringify(listMessage)
                                        },
                                        {
                                            "name": "cta_url",
                                            "buttonParamsJson": "{\"display_text\":\"Group Chat Bot\",\"url\":\"https://chat.whatsapp.com/JBMxhUhobcaAkmB1lxkPsV\",\"merchant_url\":\"https://chat.whatsapp.com/JBMxhUhobcaAkmB1lxkPsV\"}"
                                        },
                                        {
                                            "name": "cta_url",
                                            "buttonParamsJson": "{\"display_text\":\"Telegram\",\"url\":\"https://t.me/ErerexIDofc\",\"merchant_url\":\"https://t.me/ErerexIDofc\"}"
                                        },
                                    ],
                                })
                            })
                        }
                    }
                }, {})

                await Yori.relayMessage(msg.key.remoteJid, msg.message, {
                    messageId: msg.key.id
                })
            }
                await Yori.sendMessage(m.chat, { react: { text: "✅", key: m.key, } })
                Yori.sendMessage(m.chat, { audio: fs.readFileSync('./mp3/welcome.mp3'), viewOnce: true, mimetype: 'audio/mpeg', ptt: true }, { quoted: m })
                await Yori.sendMessage(m.chat, { react: { text: "🎧", key: m.key, } })
                /*
     case 'menu': 
        case 'help': {
          if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                let txxt = `ᴋᴏɴɴɪᴄɪᴡᴀ @${m.sender.split("@")[0]} sᴀʏᴀ ᴀᴅᴀʟᴀʜ ${global.botname}✨\nsᴇʙᴜᴀʜ ᴘʀᴏɢᴀᴍ ʏᴀɴɢ ᴅɪʀᴀɴᴄᴀɴɢ sᴇᴅᴇᴍɪᴋɪᴀɴ ʀᴜᴘᴀ ᴜɴᴛᴜᴋ ᴍᴇᴍʙᴜᴀᴛ ᴘᴀʀᴀ ᴘᴇɴɢɢᴜɴᴀ ᴍᴜᴅᴀʜ ᴅᴀʟᴀᴍ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ʙᴏᴛ ɪɴɪ. ʙᴇʀʙᴀɢᴀɪ ғɪᴛᴜʀ ᴍᴇɴᴀʀɪᴋ ᴅᴀɴ ʙᴇʀɢᴜɴᴀ ʙɪsᴀ ᴋᴀʟɪᴀɴ ᴅᴀᴘᴀᴛᴋᴀɴ ᴅɪ ${global.botname}.

┏❐  ⌜ɪɴғᴏ  ʏᴏʀɪ - ᴄʜᴀɴ  ⌟  ❐
┃⭔ ᴄʀᴇᴀᴛᴏʀ : ${ownername}
┃⭔ ʟɪʙʀᴀʀʏ : ʟɪɴᴜx
┃⭔ ᴛʏᴘᴇ : ᴄᴀsᴇ ᴄᴏᴍᴍᴏɴᴊs
┃⭔ ᴍᴏᴅᴇ : ${Yori.public ? '✱ Public ༣' : '✲ Self ༣'}
┃⭔ ᴜsᴇʀ : ${Object.keys(global.db.data.users).length} User
┃⭔ ᴘʀᴇғɪʀ : ᴍᴜʟᴛɪ
┗❐

┏❐ ⌜ ɪɴғᴏ ᴜsᴇʀ ⌟ ❐
┃⭔ ɴᴀᴍᴇ : *${pushname}*
┃⭔ ɴᴜᴍʙᴇʀ : @${m.sender.split('@')[0]}
┃⭔ sᴛᴀᴛᴜs : *${isCreator ? "🍃 Owner" : "🏷️ User"}*
┗❐

[ ᴄᴏᴍᴍᴀɴᴅ ʙᴏᴛᴢ ]
.ᴍᴇɴᴜʟɪsᴛ
.ᴀʟʟᴍᴇɴᴜ

[ ᴏᴛʜᴇʀ ғᴇᴀᴛᴜʀᴇs ᴄᴏᴍɪɴɢ sᴏᴏɴ ]
`;

       await Yori.sendMessage(m.chat, { text: txxt, contextInfo: {
         externalAdReply: {
          showAdAttribution: true,
          title: ucapanWaktu,
          body: botname,
          thumbnailUrl: 'https://api.shannmoderz.xyz/server/file/eBaptPc3F0ozmFuN.jpg',
          sourceUrl: '',
          mediaType: 1,
          renderLargerThumbnail: true
        }
        }}, { quoted: mek })}
       await Yori.sendMessage(m.chat, { audio: fs.readFileSync('./mp3/ntah.mp3'), mimetype: 'audio/mp4', ptt:true}, { quoted:m });
       */
                break
                case 'menulist': case "mainmenu":
if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar') 
        menuu = `@${m.sender.split("@")[0]} Konnichiwa Kak👋*

┏❐  ⌜ɪɴғᴏ  ʏᴏʀɪ - ᴄʜᴀɴ  ⌟  ❐
┃⭔ ᴄʀᴇᴀᴛᴏʀ : ${ownername}
┃⭔ ʟɪʙʀᴀʀʏ : ʟɪɴᴜx
┃⭔ ᴛʏᴘᴇ : ᴄᴀsᴇ ᴄᴏᴍᴍᴏɴᴊs
┃⭔ ᴍᴏᴅᴇ : ${Yori.public ? '✱ Public ༣' : '✲ Self ༣'}
┃⭔ ᴜsᴇʀ ᴅᴀᴛᴀʙᴀsᴇ : ${Object.keys(global.db.data.users).length} User
┃⭔ ᴘʀᴇғɪʀ : ᴍᴜʟᴛɪ
┗❐

❐ Animemenu
❐ Storemenu
❐ Aimenu
❐ Funmenu
❐ Gamemenu
❐ Groupmenu
❐ Beritamenu
❐ Randommenu
❐ Downloadmenu
❐ Weebsmenu
❐ Islamimenu
❐ Quotesmenu
❐ Searchmenu
❐ Convertmenu
❐ Favmenu
❐ Pushmenu
❐ Antimenu
❐ Photomenu
❐ Cpanelmenu
❐ Walpapermenu
❐ Cecanmenu
❐ Textpromenu
❐ Asupanmenu

[ ᴛʜᴀɴᴋs ᴛᴏ ᴄᴏɴᴛʀɪʙᴜᴛɪᴏɴs ]
- ᴀʟʟᴀʜ sᴡᴛ ( ᴍʏ ɢᴏᴅ ) 
- ᴏʀᴀɴɢ ᴛᴜᴀ
- ʟᴇɴᴡʏ ( ʙᴀsᴇ ) 
- ᴇʀᴇʀᴇxɪᴅ ( ᴄᴏɴᴛʀɪʙᴜᴛɪᴏɴ ) 
- ᴀᴅʀɪᴀɴ ( ᴄᴏɴᴛʀɪʙᴜᴛɪᴏɴ & ғɪxᴇᴅ ) 
- ᴋʏᴜᴜ ( ᴄᴏɴᴛʀɪʙᴜᴛɪᴏɴ & ғɪxᴇᴅ ) 
- ᴀʟʟ ғᴀᴍɪʟʏ 
- ᴀʟʟ ᴄʀᴇᴀᴛᴏʀᴅ`;
        await sendmes(m.chat, menuu);
                /*
      case 'menulist':
         case 'mainmenu': {
             if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar') 
             if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')           
              let txxt = `*@${m.sender.split("@")[0]} Konnichiwa Kak👋*

┏❐  ⌜ɪɴғᴏ  ʏᴏʀɪ - ᴄʜᴀɴ  ⌟  ❐
┃⭔ ᴄʀᴇᴀᴛᴏʀ : ${ownername}
┃⭔ ʟɪʙʀᴀʀʏ : ʟɪɴᴜx
┃⭔ ᴛʏᴘᴇ : ᴄᴀsᴇ ᴄᴏᴍᴍᴏɴᴊs
┃⭔ ᴍᴏᴅᴇ : ${Yori.public ? '✱ Public ༣' : '✲ Self ༣'}
┃⭔ ᴜsᴇʀ ᴅᴀᴛᴀʙᴀsᴇ : ${Object.keys(global.db.data.users).length} User
┃⭔ ᴘʀᴇғɪʀ : ᴍᴜʟᴛɪ
┗❐

❐ Animemenu
❐ Storemenu
❐ Aimenu
❐ Funmenu
❐ Gamemenu
❐ Groupmenu
❐ Beritamenu
❐ Randommenu
❐ Downloadmenu
❐ Weebsmenu
❐ Islamimenu
❐ Quotesmenu
❐ Searchmenu
❐ Convertmenu
❐ Favmenu
❐ Pushmenu
❐ Antimenu
❐ Photomenu
❐ Cpanelmenu
❐ Walpapermenu
❐ Cecanmenu
❐ Textpromenu
❐ Asupanmenu

[ ᴛʜᴀɴᴋs ᴛᴏ ᴄᴏɴᴛʀɪʙᴜᴛɪᴏɴs ]
- ᴀʟʟᴀʜ sᴡᴛ ( ᴍʏ ɢᴏᴅ ) 
- ᴏʀᴀɴɢ ᴛᴜᴀ
- ʟᴇɴᴡʏ ( ʙᴀsᴇ ) 
- ᴇʀᴇʀᴇxɪᴅ ( ᴄᴏɴᴛʀɪʙᴜᴛɪᴏɴ ) 
- ᴀᴅʀɪᴀɴ ( ᴄᴏɴᴛʀɪʙᴜᴛɪᴏɴ & ғɪxᴇᴅ ) 
- ᴋʏᴜᴜ ( ᴄᴏɴᴛʀɪʙᴜᴛɪᴏɴ & ғɪxᴇᴅ ) 
- ᴀʟʟ ғᴀᴍɪʟʏ 
- ᴀʟʟ ᴄʀᴇᴀᴛᴏʀᴅ
`;

                let msg = generateWAMessageFromContent(from, {
                    viewOnceMessage: {
                        message: {
                            "messageContextInfo": {
                                "deviceListMetadata": {},
                                "deviceListMetadataVersion": 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: xmenu_oh
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: botname
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    ...(await prepareWAMessageMedia({ image: fs.readFileSync('./data/image/menu.jpg') }, { upload: Yori.waUploadToServer })),
                                    title: `> Menu Simple`,
                                    gifPlayback: true,
                                    subtitle: ownername,
                                    hasMediaAttachment: false
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"Back","id":".menu"}`
                                        },
                                        {
                                            "name": "cta_url",
                                            "buttonParamsJson": "{\"display_text\":\"Creator 👤\",\"url\":\"https://wa.me/62895342022385\",\"merchant_url\":\"https://www.google.com\"}"
                                        },
                                    ],
                                }),
                                contextInfo: {
                                    mentionedJid: [m.sender],
                                    forwardingScore: 999,
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: '120363204138641225@newsletter',
                                        newsletterName: botname,
                                        serverMessageId: 143
                                    }
                                }
                            })
                        }
                    }
                }, {})

                await Yori.relayMessage(msg.key.remoteJid, msg.message, {
                    messageId: msg.key.id
                })
            }

      await Yori.sendMessage(m.chat, { text: txxt, contextInfo: {
         externalAdReply: {
          showAdAttribution: true,
          title: ucapanWaktu,
          body: botname,
          thumbnailUrl: 'https://widipe.com/file/ojUtb3QgX1pW.jpg',
          sourceUrl: '',
          mediaType: 1,
          renderLargerThumbnail: true
        }
        }}, { quoted: mek })}
       await Yori.sendMessage(m.chat, { audio: fs.readFileSync('./mp3/private.mp3'), viewOnce: true, mimetype: 'audio/mp4', ptt:true}, { quoted:m });
       */
                break
                
               case 'allmenu': case "menuall":
if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar') 
        menuu = `Konnichiwa kak @${m.sender.split("@")[0]} Saya adalah ${global.botname}✨\nSebuah progam yang dirancang sedemikian rupa untuk membuat para pengguna mudah dalam menggunakan Bot ini. Berbagai fitur menari dan berguna bisa kalian dapatkan di ${global.botname}.

┏━━⊱-『 Store Menu 』━━━━◧
┣» *Sc*
┣» *Pay*
┣» *Panel*
┣» *Order*
┣» *Tambah*
┣» *Kurang*
┣» *Kali*
┣» *Bagi*
┣» *List*
┣» *Addlist*
┣» *Dellist*
┣» *Payment*
┣» *Pesanan*
┣» *Updatelist*
┣» *Listjapost*
┣» *Feerekber*
┣» *Done*
┣» *Done1*
┣» *Formatneed*
┣» *Prosess*
┣» *Deposit [ Amount ]*
┣» *Deposit-2 [ Amount ]*
┗━━━━━━━━━━━━━━━━⊱

┏━━⊱-『 Search Film 』━━━━◧
┣» *Filmsearch [ Nama Film ]*
┗━━━━━━━━━━━━━━━━⊱

┏━━⊱-『 Ai Menu 』━━━━◧
┣» *Ai*
┣» *Ask*
┣» *Bing*
┣» *Blackbox*
┣» *GPT4*
┣» *Gpt4_2*
┣» *Gpt*
┣» *Gptgo*
┣» *Llama3*
┣» *bingimg*
┣» *OpenAi*
┣» *Remini*
┣» *Autoai*
┣» *Yori-ai*
┣» *Luminai*
┣» *Toanime*
┣» *Lepton*
┗━━━━━━━━━━━━━━━━⊱

┏━━⊱-『 Fun Menu 』━━━━◧
┣» *Truth*
┣» *Dare*
┣» *Rate*
┣» *Apakah*
┣» *Kapankah*
┣» *Bisakah*
┣» *Bagaimanakah* 
┣» *Gantengcek*
┣» *Cekganteng*
┣» *Cantikcek*
┣» *Cekcantik*
┣» *Sangecek*
┣» *Ceksange*
┣» *Gaycek*
┣» *Cekgay*
┣» *Lesbicek*
┣» *Ceklesbi*
┣» *Cekkontol*
┣» *Cekmemek*
┣» *Cekkhodam*
┗━━━━━━━━━━━━━━━━⊱

┏━━⊱-『 Game Menu 』━━━━◧
┣» *TTC*
┣» *Deltc*
┣» *Tebak Kata*
┣» *Tebak Gambar*
┣» *Tebak Lirik*
┣» *Tebak Kalimat*
┣» *Tebak Lontong*
┣» *Kuismath Noob*
┣» *Kuismath Easy*
┣» *Kuismath Medium*
┣» *Kuismath Hard*
┣» *Kuismath Extreme*
┣» *Kuismath Imposibble*
┣» *Kuismath Imposibble2*
┣»  *Suit*
┣» *Clan* [ Name clan ]
┗━━━━━━━━━━━━━━━━⊱

 *Group Menu*
 *⥁ Saran*
 *⥁ Reportbug*
 *⥁ Antilinkgc on / off*
 *⥁ Antitoxic on / off*
 *⥁ Bcgc (textnya)*
 *⥁ Share (textnya)*
 *⥁ Yorr (textnya)*
 *⥁ Hidetag (textnya)*
 *⥁ Kick (628xx)*
 *⥁ Add (628xx)*
 *⥁ Group close / open*
 *⥁ Promote (628xx)*
 *⥁ Demote (628xx)*
 *⥁ Sendlinkgc (628xx)*
 *⥁ Editgroup close / open*
 *⥁ Editinfo on / off*
 *⥁ Join (linknya)*
 *⥁ Editsubjek (textnya)*
 *⥁ Editdesk (textnya)*
 *⥁ Tagall (textnya)*
 *⥁ Inspect (linknya)*
 *⥁ Linkgroup*
 *⥁ Resetlinkgc*
 
 *Owner Menu*
 *⥁ Ban*   
 *⥁ Enc* 
 *⥁ Self*  
 *⥁ Public*
 *⥁ Getdb*
 *⥁ Getuser*   
 *⥁ Addprem*
 *⥁ Cekidgc*
 *⥁ CreateQr*    
 *⥁ DetectQr*
 *⥁ Addlimit*
 *⥁ Dellimit*
 *⥁ Resetlimit*

┏━━⊱-『 Berita Menu 』━━━━◧
┣» *Inews*
┣» *Kontan*
┣» *KompasNews*
┣» *DetikNews*
┣» *DailyNews*
┣» *Cuaca*
┣» *Gempa*
┗━━━━━━━━━━━━━━━━⊱

┏━━⊱-『 Asupan Menu 』━━━━◧
┣» *Tobrut*
┣» *Tobrut2*
┣» *Cewecantik*
┣» *Cecan*
┣» *18*
┣» *Bokep*
┣» *Paptt*
┗━━━━━━━━━━━━━━━━⊱

 *Random Menu*
 *⥁ Qc*
 *⥁ Afk*
 *⥁ Owner*
 *⥁ Nickff*
 *⥁ Puisi*
 *⥁ Pantun*
 *⥁ Qckode*
 *⥁ Sticker*
 *⥁ Sewa*
 *⥁ Faktaunik*
 *⥁ Couple*
 *⥁ Meme*
 *⥁ Getname*
 *⥁ Getpic*
 *⥁ Confess*
 *⥁ Menfess*
 *⥁ Stalktiktok*

┏━━⊱-『 Download Menu 』━━━━◧
┣» *Fbdl (linknya)*
┣» *Igdl (linknya)*
┣» *Igslide (linknya)*
┣» *Tiktok (linknya)*
┣» *Ytmp3 (linknya)*
┣» *Ytmp4 (linknya)*
┣» *Mediafire (linknya)*
┣» *Capcut (linknya)*
┣» *Gdrive (linknya)*
┣» *Twitter (linknya)*
┣» *Spotify [ Name Artist ]*
┗━━━━━━━━━━━━━━━━⊱

 *Weebs Menu*
 *⥁ Pat*
 *⥁ Cry*
 *⥁ Hug*
 *⥁ Nom*
 *⥁ Awoo*
 *⥁ Kiss*
 *⥁ Kill*
 *⥁ Lick*
 *⥁ Bite*
 *⥁ Yeet*
 *⥁ Bonk*
 *⥁ Wink*
 *⥁ Poke*
 *⥁ Slap*
 *⥁ Bully*
 *⥁ Smile*
 *⥁ Wave*
 *⥁ Blush*
 *⥁ Smug*
 *⥁ Glomp*
 *⥁ Happy*
 *⥁ Dance*
 *⥁ Cuddle*
 *⥁ Cringe*
 *⥁ Highfive*
 *⥁ Handhold*

┏━━⊱-『 Islami Menu 』━━━━◧
┣» *Asmaulhusna*
┣» *Ayatkursi*
┣» *Doa*
┣» *Quotesislam*
┣» *Niatsholat*
┣» *Kisahnabi*
┣» *Jadwalsholat*
┣» *Tafsir*
┗━━━━━━━━━━━━━━━━⊱

 *Quotes Menu*
 *⥁ FML*
 *⥁ Bucin*
 *⥁ Quotes*
 *⥁ Motivasi*
 *⥁ Katabijak*
 *⥁ Katacinta*
 *⥁ Katagalau*
 *⥁ Katahacker*
 *⥁ Katailham*
 *⥁ Katasenja*
 *⥁ Galau*
 *⥁ Sad*
 *⥁ Katasindiran*
 *⥁ Quotesanime*
 *⥁ Quotespubg*
 *⥁ Quotesislamic*

 *Search Menu*
 *⥁ Ai*
 *⥁ Imdb*
 *⥁ Play*
 *⥁ Song*
 *⥁ Ytsearch*
 *⥁ Yts
 *⥁ Chord* 
 *⥁ Lirik*
 *⥁ Cuaca*
 *⥁ Jarak*
 *⥁ Reminder*
 *⥁ Google*
 *⥁ OpenAi*
 *⥁ Yorichan*
 *⥁ Kodebahasa*
 *⥁ Cariresep*
 *⥁ Resep*
 *⥁ Otakudesu*
 *⥁ Apksearch*
 *⥁ Searchanime*
 *⥁ Sanime*
 *⥁ Drakorsearch*
 *⥁ Tweet*
 *⥁ Yousearch*

 *Convert Menu*
 *⥁ Wm*
 *⥁ Tomp3*
 *⥁ Tourl*
 *⥁ Rvo*
 *⥁ Readviewonce*
 *⥁ Toimg*
 *⥁ Smeme*
 *⥁ Meme*
 *⥁ Remini*
 *⥁ Creategc
 *⥁ Img2Txt*
 *⥁ Img2Promt*  
 *⥁ Removebg*
 
 *Favorite Menu*
 *⥁ Ai*
 *⥁ Wm*
 *⥁ S*
 *⥁ Hd*
 *⥁ Smeme*
 *⥁ Carbon*
 *⥁ Meme*
 *⥁ Play*
 *⥁ Remini*
 *⥁ Ig (Linknya)*
 *⥁ Tiktok (Linknya)*
 *⥁ Ttsearch (Teks)*
 *⥁ Ttslide (Linknya)*
 *⥁ Ttslide (Linknya)*
 *⥁ Ytmp3 (Linknya)*
 *⥁ Ytmp4 (linknya)*

 *Push Menu*   
 *⥁ Cekidgc*
 *⥁ Savekontak*
 *⥁ Pushkontak*
 *⥁ Pushkontak2*

 *Anti Menu*
 *⥁ Antich*   
 *⥁ Antiwame*
 *⥁ Antilink*
 *⥁ Antipanel*
 *⥁ Antitoxic*
 *⥁ Antilinktt*
 *⥁ Antilinkyt*
 *⥁ Antilinkgc*
 *⥁ Antilinkgcv1*

 *Photooxy Menu*
 *⥁ Glitchtext*
 *⥁ Writetext*
 *⥁ Blackpinklogo*
 *⥁ Advancedglow*
 *⥁ Typographytext*
 *⥁ Pixelglitch*
 *⥁ Neonglitch*
 *⥁ Flag*
 *⥁ Flag2*
 *⥁ Deletingtext*
 *⥁ Blackpinkstyle*
 *⥁ Glowingtext*
 *⥁ Underwater*
 *⥁ Logomaker*
 *⥁ Cartoonstyle*
 *⥁ Papercut*
 *⥁ Watercolor*
 *⥁ Effectclouds*
 *⥁ Gradienttext*
 *⥁ Summerbeach*
 *⥁ Luxurygold*
 *⥁ Multicolored*
 *⥁ Sandsummer*
 *⥁ Galaxy*
 *⥁ 1917style*
 *⥁ Makingneon*
 *⥁ Royaltext*
 *⥁ Texteffect*
 *⥁ Galaxystyle*
 *⥁ Lighteffect*
 *⥁ Flaming*   
 *⥁ Stars*
 *⥁ Shadow*
 *⥁ Burnpaper*
 *⥁ Grass*
 *⥁ Underwater*
 *⥁ Whitecube*
 *⥁ Smokyneon*
 *⥁ Fabric*
 *⥁ Glowing*
 *⥁ Honey*
 *⥁ Vintage*
 *⥁ Gradient*
 *⥁ Fur*
 *⥁ Striking*
 
 *Cecan Menu*
 *⥁ China*
 *⥁ Hijab*
 *⥁ Cewecantik*
 *⥁ Cecan* [ Premium ]
 *⥁ Tobrut* [ Premium ]
 *⥁ Toketbrutal* [ Premium ] 
 *⥁ Indo*
 *⥁ Japanese/Jepang/Japan*
 *⥁ Korean*
 *⥁ Malay*
 *⥁ Randomgirl*
 *⥁ Randomboy*
 *⥁ Thai*
 *⥁ Vietnam*
 *⥁ Tiktokgirl*
 *⥁ Tiktokghea*
 *⥁ Tiktokbocil*
 *⥁ Tiktoknukthy*
 *⥁ Tiktoksantuy*
 *⥁ Tiktokkayes*
 *⥁ Tiktokpanrika*
 *⥁ Tiktoknotnot*
 
 *Panel Menu*
 *⥁ Buatpanel
 *⥁ Listusr
 *⥁ Delusr
 *⥁ Listsrv
 *⥁ Delsrv
 *⥁ Tutorial
 *⥁ Ramlist
 *⥁ Premlist
 *⥁ Addusr
 *⥁ Addsrv
 *⥁ Updatesrv
 *⥁ Suspend
 *⥁ Unsuspend
 *⥁ Createadmin
 *⥁ Listadmin
 
 *Panel Menu*
 
 *⥁ 1gb [user,nomor]*
 *⥁ 2gb [user,nomor]*
 *⥁ 3gb [user,nomor]*
 *⥁ 4gb [user,nomor]*
 *⥁ 5gb [user,nomor]*
 *⥁ 6gb [user,nomor]*
 *⥁ 7gb [user,nomor]*
 *⥁ 8gb [user,nomor]*
 *⥁ 9gb [user,nomor]*
 *⥁ Unli [user,nomor]*
 
 *Anime menu*
 *⥁ Loli*
 *⥁ Milf*
 *⥁ Nsfwloli* [ Premium ]
 *⥁ Pussy* [ Premium ]
 *⥁ Shota*
 *⥁ Yuri*
 *⥁ Zettai*
 *⥁ Cuckold*
 *⥁ Husbu*
 *⥁ Eba*
 *⥁ Foot*
 *⥁ Hneko*
 *⥁ Hentaineko*
 *⥁ Akira*
 *⥁ Akiyama*
 *⥁ Ana*
 *⥁ Art*
 *⥁ Asuna*
 *⥁ Ayuzawa*
 *⥁ Boruto*
 *⥁ Bts*
 *⥁ Chiho*
 *⥁ Chitoge*
 *⥁ Cosplay*
 *⥁ Cosplayloli*
 *⥁ Cosplaysagiri*
 *⥁ Cyber*
 *⥁ Deidara*
 *⥁ Doraemon*
 *⥁ Elaina*
 *⥁ Emilia*
 *⥁ Erza*
 *⥁ Exo*
 *⥁ Gamewallpaper*
 *⥁ Gremory*
 *⥁ Hacker*
 *⥁ Hestia*
 *⥁ Hinata*
 *⥁ Husbu*
 *⥁ Inori*
 *⥁ Islamic*
 *⥁ Isuzu*
 *⥁ Itachi*
 *⥁ Itori*
 *⥁ Jennie*
 *⥁ Jiso*
 *⥁ Justina*
 *⥁ Kaga*
 *⥁ Kagura*
 *⥁ Kakasih*
 *⥁ Kaori*
 *⥁ Cartoon*
 *⥁ Shortquote*
 *⥁ Keneki*
 *⥁ Kotori*
 *⥁ Kurumi*
 *⥁ Lisa*
 *⥁ Madara*
 *⥁ Megumin*
 *⥁ Mikasa*
 *⥁ Mikey*
 *⥁ Miku*
 *⥁ Minato*
 *⥁ Mountain*
 *⥁ Naruto*
 *⥁ Neko2*
 *⥁ Nekoanime*
 *⥁ Nezuko*
 *⥁ Onepiece*
 *⥁ Pentol*
 *⥁ Pokemon*
 *⥁ Programming
 *⥁ Randomanime*
 *⥁ Randomanime2*
 *⥁ Rize*
 *⥁ Rose*
 *⥁ Sagiri*
 *⥁ Sakura*
 *⥁ Sasuke*
 *⥁ Satanic*
 *⥁ Shina*
 *⥁ Shinka*
 *⥁ Shinomiya*
 *⥁ Shizuka*
 *⥁ Shota*
 *⥁ Space*
 *⥁ Technology*
 *⥁ Tejina*
 *⥁ Toukachan*
 *⥁ Tsunade*
 *⥁ Yotsuba*
 *⥁ Yuki*
 *⥁ Yulibocil*
 *⥁ Yumeko*

 💫 *[ OTHER FEATURES COMING SOON ]*`;
        await sendmes(m.chat, menuu);
/*
            case 'almenu':
            case 'allmenu': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                  let txxt = `Konnichiwa kak @${m.sender.split("@")[0]} Saya adalah ${global.botname}✨\nSebuah progam yang dirancang sedemikian rupa untuk membuat para pengguna mudah dalam menggunakan Bot ini. Berbagai fitur menari dan berguna bisa kalian dapatkan di ${global.botname}.

┏━━⊱-『 Store Menu 』━━━━◧
┣» *Sc*
┣» *Pay*
┣» *Panel*
┣» *Order*
┣» *Tambah*
┣» *Kurang*
┣» *Kali*
┣» *Bagi*
┣» *List*
┣» *Addlist*
┣» *Dellist*
┣» *Payment*
┣» *Pesanan*
┣» *Updatelist*
┣» *Listjapost*
┣» *Feerekber*
┣» *Done*
┣» *Done1*
┣» *Formatneed*
┣» *Prosess*
┣» *Deposit [ Amount ]*
┣» *Deposit-2 [ Amount ]*
┗━━━━━━━━━━━━━━━━⊱

┏━━⊱-『 Search Film 』━━━━◧
┣» *Filmsearch [ Nama Film ]*
┗━━━━━━━━━━━━━━━━⊱

┏━━⊱-『 Ai Menu 』━━━━◧
┣» *Ai*
┣» *Ask*
┣» *Bing*
┣» *Blackbox*
┣» *GPT4*
┣» *Gpt4_2*
┣» *Gpt*
┣» *Gptgo*
┣» *Llama3*
┣» *bingimg*
┣» *OpenAi*
┣» *Remini*
┣» *Autoai*
┣» *Yori-ai*
┣» *Luminai*
┣» *Toanime*
┣» *Lepton*
┗━━━━━━━━━━━━━━━━⊱

┏━━⊱-『 Fun Menu 』━━━━◧
┣» *Truth*
┣» *Dare*
┣» *Rate*
┣» *Apakah*
┣» *Kapankah*
┣» *Bisakah*
┣» *Bagaimanakah* 
┣» *Gantengcek*
┣» *Cekganteng*
┣» *Cantikcek*
┣» *Cekcantik*
┣» *Sangecek*
┣» *Ceksange*
┣» *Gaycek*
┣» *Cekgay*
┣» *Lesbicek*
┣» *Ceklesbi*
┣» *Cekkontol*
┣» *Cekmemek*
┣» *Cekkhodam*
┗━━━━━━━━━━━━━━━━⊱

┏━━⊱-『 Game Menu 』━━━━◧
┣» *TTC*
┣» *Deltc*
┣» *Tebak Kata*
┣» *Tebak Gambar*
┣» *Tebak Lirik*
┣» *Tebak Kalimat*
┣» *Tebak Lontong*
┣» *Kuismath Noob*
┣» *Kuismath Easy*
┣» *Kuismath Medium*
┣» *Kuismath Hard*
┣» *Kuismath Extreme*
┣» *Kuismath Imposibble*
┣» *Kuismath Imposibble2*
┣»  *Suit*
┣» *Clan* [ Name clan ]
┗━━━━━━━━━━━━━━━━⊱

 *Group Menu*
 *⥁ Saran*
 *⥁ Reportbug*
 *⥁ Antilinkgc on / off*
 *⥁ Antitoxic on / off*
 *⥁ Bcgc (textnya)*
 *⥁ Share (textnya)*
 *⥁ Yorr (textnya)*
 *⥁ Hidetag (textnya)*
 *⥁ Kick (628xx)*
 *⥁ Add (628xx)*
 *⥁ Group close / open*
 *⥁ Promote (628xx)*
 *⥁ Demote (628xx)*
 *⥁ Sendlinkgc (628xx)*
 *⥁ Editgroup close / open*
 *⥁ Editinfo on / off*
 *⥁ Join (linknya)*
 *⥁ Editsubjek (textnya)*
 *⥁ Editdesk (textnya)*
 *⥁ Tagall (textnya)*
 *⥁ Inspect (linknya)*
 *⥁ Linkgroup*
 *⥁ Resetlinkgc*
 
 *Owner Menu*
 *⥁ Ban*   
 *⥁ Enc* 
 *⥁ Self*  
 *⥁ Public*
 *⥁ Getdb*
 *⥁ Getuser*   
 *⥁ Addprem*
 *⥁ Cekidgc*
 *⥁ CreateQr*    
 *⥁ DetectQr*
 *⥁ Addlimit*
 *⥁ Dellimit*
 *⥁ Resetlimit*

┏━━⊱-『 Berita Menu 』━━━━◧
┣» *Inews*
┣» *Kontan*
┣» *KompasNews*
┣» *DetikNews*
┣» *DailyNews*
┣» *Cuaca*
┣» *Gempa*
┗━━━━━━━━━━━━━━━━⊱

┏━━⊱-『 Asupan Menu 』━━━━◧
┣» *Tobrut*
┣» *Tobrut2*
┣» *Cewecantik*
┣» *Cecan*
┣» *18*
┣» *Bokep*
┣» *Paptt*
┗━━━━━━━━━━━━━━━━⊱

 *Random Menu*
 *⥁ Qc*
 *⥁ Afk*
 *⥁ Owner*
 *⥁ Nickff*
 *⥁ Puisi*
 *⥁ Pantun*
 *⥁ Qckode*
 *⥁ Sticker*
 *⥁ Sewa*
 *⥁ Faktaunik*
 *⥁ Couple*
 *⥁ Meme*
 *⥁ Getname*
 *⥁ Getpic*
 *⥁ Confess*
 *⥁ Menfess*
 *⥁ Stalktiktok*

┏━━⊱-『 Download Menu 』━━━━◧
┣» *Fbdl (linknya)*
┣» *Igdl (linknya)*
┣» *Igslide (linknya)*
┣» *Tiktok (linknya)*
┣» *Ytmp3 (linknya)*
┣» *Ytmp4 (linknya)*
┣» *Mediafire (linknya)*
┣» *Capcut (linknya)*
┣» *Gdrive (linknya)*
┣» *Twitter (linknya)*
┣» *Spotify [ Name Artist ]*
┗━━━━━━━━━━━━━━━━⊱

 *Weebs Menu*
 *⥁ Pat*
 *⥁ Cry*
 *⥁ Hug*
 *⥁ Nom*
 *⥁ Awoo*
 *⥁ Kiss*
 *⥁ Kill*
 *⥁ Lick*
 *⥁ Bite*
 *⥁ Yeet*
 *⥁ Bonk*
 *⥁ Wink*
 *⥁ Poke*
 *⥁ Slap*
 *⥁ Bully*
 *⥁ Smile*
 *⥁ Wave*
 *⥁ Blush*
 *⥁ Smug*
 *⥁ Glomp*
 *⥁ Happy*
 *⥁ Dance*
 *⥁ Cuddle*
 *⥁ Cringe*
 *⥁ Highfive*
 *⥁ Handhold*

┏━━⊱-『 Islami Menu 』━━━━◧
┣» *Asmaulhusna*
┣» *Ayatkursi*
┣» *Doa*
┣» *Quotesislam*
┣» *Niatsholat*
┣» *Kisahnabi*
┣» *Jadwalsholat*
┣» *Tafsir*
┗━━━━━━━━━━━━━━━━⊱

 *Quotes Menu*
 *⥁ FML*
 *⥁ Bucin*
 *⥁ Quotes*
 *⥁ Motivasi*
 *⥁ Katabijak*
 *⥁ Katacinta*
 *⥁ Katagalau*
 *⥁ Katahacker*
 *⥁ Katailham*
 *⥁ Katasenja*
 *⥁ Galau*
 *⥁ Sad*
 *⥁ Katasindiran*
 *⥁ Quotesanime*
 *⥁ Quotespubg*
 *⥁ Quotesislamic*

 *Search Menu*
 *⥁ Ai*
 *⥁ Imdb*
 *⥁ Play*
 *⥁ Song*
 *⥁ Ytsearch*
 *⥁ Yts
 *⥁ Chord* 
 *⥁ Lirik*
 *⥁ Cuaca*
 *⥁ Jarak*
 *⥁ Reminder*
 *⥁ Google*
 *⥁ OpenAi*
 *⥁ Yorichan*
 *⥁ Kodebahasa*
 *⥁ Cariresep*
 *⥁ Resep*
 *⥁ Otakudesu*
 *⥁ Apksearch*
 *⥁ Searchanime*
 *⥁ Sanime*
 *⥁ Drakorsearch*
 *⥁ Tweet*
 *⥁ Yousearch*

 *Convert Menu*
 *⥁ Wm*
 *⥁ Tomp3*
 *⥁ Tourl*
 *⥁ Rvo*
 *⥁ Readviewonce*
 *⥁ Toimg*
 *⥁ Smeme*
 *⥁ Meme*
 *⥁ Remini*
 *⥁ Creategc
 *⥁ Img2Txt*
 *⥁ Img2Promt*  
 *⥁ Removebg*
 
 *Favorite Menu*
 *⥁ Ai*
 *⥁ Wm*
 *⥁ S*
 *⥁ Hd*
 *⥁ Smeme*
 *⥁ Carbon*
 *⥁ Meme*
 *⥁ Play*
 *⥁ Remini*
 *⥁ Ig (Linknya)*
 *⥁ Tiktok (Linknya)*
 *⥁ Ttsearch (Teks)*
 *⥁ Ttslide (Linknya)*
 *⥁ Ttslide (Linknya)*
 *⥁ Ytmp3 (Linknya)*
 *⥁ Ytmp4 (linknya)*

 *Push Menu*   
 *⥁ Cekidgc*
 *⥁ Savekontak*
 *⥁ Pushkontak*
 *⥁ Pushkontak2*

 *Anti Menu*
 *⥁ Antich*   
 *⥁ Antiwame*
 *⥁ Antilink*
 *⥁ Antipanel*
 *⥁ Antitoxic*
 *⥁ Antilinktt*
 *⥁ Antilinkyt*
 *⥁ Antilinkgc*
 *⥁ Antilinkgcv1*

 *Photooxy Menu*
 *⥁ Glitchtext*
 *⥁ Writetext*
 *⥁ Blackpinklogo*
 *⥁ Advancedglow*
 *⥁ Typographytext*
 *⥁ Pixelglitch*
 *⥁ Neonglitch*
 *⥁ Flag*
 *⥁ Flag2*
 *⥁ Deletingtext*
 *⥁ Blackpinkstyle*
 *⥁ Glowingtext*
 *⥁ Underwater*
 *⥁ Logomaker*
 *⥁ Cartoonstyle*
 *⥁ Papercut*
 *⥁ Watercolor*
 *⥁ Effectclouds*
 *⥁ Gradienttext*
 *⥁ Summerbeach*
 *⥁ Luxurygold*
 *⥁ Multicolored*
 *⥁ Sandsummer*
 *⥁ Galaxy*
 *⥁ 1917style*
 *⥁ Makingneon*
 *⥁ Royaltext*
 *⥁ Texteffect*
 *⥁ Galaxystyle*
 *⥁ Lighteffect*
 *⥁ Flaming*   
 *⥁ Stars*
 *⥁ Shadow*
 *⥁ Burnpaper*
 *⥁ Grass*
 *⥁ Underwater*
 *⥁ Whitecube*
 *⥁ Smokyneon*
 *⥁ Fabric*
 *⥁ Glowing*
 *⥁ Honey*
 *⥁ Vintage*
 *⥁ Gradient*
 *⥁ Fur*
 *⥁ Striking*
 
 *Cecan Menu*
 *⥁ China*
 *⥁ Hijab*
 *⥁ Cewecantik*
 *⥁ Cecan* [ Premium ]
 *⥁ Tobrut* [ Premium ]
 *⥁ Toketbrutal* [ Premium ] 
 *⥁ Indo*
 *⥁ Japanese/Jepang/Japan*
 *⥁ Korean*
 *⥁ Malay*
 *⥁ Randomgirl*
 *⥁ Randomboy*
 *⥁ Thai*
 *⥁ Vietnam*
 *⥁ Tiktokgirl*
 *⥁ Tiktokghea*
 *⥁ Tiktokbocil*
 *⥁ Tiktoknukthy*
 *⥁ Tiktoksantuy*
 *⥁ Tiktokkayes*
 *⥁ Tiktokpanrika*
 *⥁ Tiktoknotnot*
 
 *Panel Menu*
 *⥁ Buatpanel
 *⥁ Listusr
 *⥁ Delusr
 *⥁ Listsrv
 *⥁ Delsrv
 *⥁ Tutorial
 *⥁ Ramlist
 *⥁ Premlist
 *⥁ Addusr
 *⥁ Addsrv
 *⥁ Updatesrv
 *⥁ Suspend
 *⥁ Unsuspend
 *⥁ Createadmin
 *⥁ Listadmin
 
 *Panel Menu*
 
 *⥁ 1gb [user,nomor]*
 *⥁ 2gb [user,nomor]*
 *⥁ 3gb [user,nomor]*
 *⥁ 4gb [user,nomor]*
 *⥁ 5gb [user,nomor]*
 *⥁ 6gb [user,nomor]*
 *⥁ 7gb [user,nomor]*
 *⥁ 8gb [user,nomor]*
 *⥁ 9gb [user,nomor]*
 *⥁ Unli [user,nomor]*
 
 *Anime menu*
 *⥁ Loli*
 *⥁ Milf*
 *⥁ Nsfwloli* [ Premium ]
 *⥁ Pussy* [ Premium ]
 *⥁ Shota*
 *⥁ Yuri*
 *⥁ Zettai*
 *⥁ Cuckold*
 *⥁ Husbu*
 *⥁ Eba*
 *⥁ Foot*
 *⥁ Hneko*
 *⥁ Hentaineko*
 *⥁ Akira*
 *⥁ Akiyama*
 *⥁ Ana*
 *⥁ Art*
 *⥁ Asuna*
 *⥁ Ayuzawa*
 *⥁ Boruto*
 *⥁ Bts*
 *⥁ Chiho*
 *⥁ Chitoge*
 *⥁ Cosplay*
 *⥁ Cosplayloli*
 *⥁ Cosplaysagiri*
 *⥁ Cyber*
 *⥁ Deidara*
 *⥁ Doraemon*
 *⥁ Elaina*
 *⥁ Emilia*
 *⥁ Erza*
 *⥁ Exo*
 *⥁ Gamewallpaper*
 *⥁ Gremory*
 *⥁ Hacker*
 *⥁ Hestia*
 *⥁ Hinata*
 *⥁ Husbu*
 *⥁ Inori*
 *⥁ Islamic*
 *⥁ Isuzu*
 *⥁ Itachi*
 *⥁ Itori*
 *⥁ Jennie*
 *⥁ Jiso*
 *⥁ Justina*
 *⥁ Kaga*
 *⥁ Kagura*
 *⥁ Kakasih*
 *⥁ Kaori*
 *⥁ Cartoon*
 *⥁ Shortquote*
 *⥁ Keneki*
 *⥁ Kotori*
 *⥁ Kurumi*
 *⥁ Lisa*
 *⥁ Madara*
 *⥁ Megumin*
 *⥁ Mikasa*
 *⥁ Mikey*
 *⥁ Miku*
 *⥁ Minato*
 *⥁ Mountain*
 *⥁ Naruto*
 *⥁ Neko2*
 *⥁ Nekoanime*
 *⥁ Nezuko*
 *⥁ Onepiece*
 *⥁ Pentol*
 *⥁ Pokemon*
 *⥁ Programming
 *⥁ Randomanime*
 *⥁ Randomanime2*
 *⥁ Rize*
 *⥁ Rose*
 *⥁ Sagiri*
 *⥁ Sakura*
 *⥁ Sasuke*
 *⥁ Satanic*
 *⥁ Shina*
 *⥁ Shinka*
 *⥁ Shinomiya*
 *⥁ Shizuka*
 *⥁ Shota*
 *⥁ Space*
 *⥁ Technology*
 *⥁ Tejina*
 *⥁ Toukachan*
 *⥁ Tsunade*
 *⥁ Yotsuba*
 *⥁ Yuki*
 *⥁ Yulibocil*
 *⥁ Yumeko*

 💫 *[ OTHER FEATURES COMING SOON ]*
`;

                let msg = generateWAMessageFromContent(from, {
                    viewOnceMessage: {
                        message: {
                            "messageContextInfo": {
                                "deviceListMetadata": {},
                                "deviceListMetadataVersion": 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: xmenu_oh
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: botname
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    ...(await prepareWAMessageMedia({ image: fs.readFileSync('./data/image/menu.jpg') }, { upload: Yori.waUploadToServer })),
                                    title: ``,
                                    gifPlayback: true,
                                    subtitle: ownername,
                                    hasMediaAttachment: false
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"Kembali ⏪","id":".menu"}`
                                        },

                                        {
                                            "name": "cta_url",
                                            "buttonParamsJson": "{\"display_text\":\"Owner 👤\",\"url\":\"https://wa.me/62895342022385\",\"merchant_url\":\"https://www.google.com\"}"
                                        },
                                    ],
                                }),
                                contextInfo: {
                                    mentionedJid: [m.sender],
                                    forwardingScore: 999,
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: '120363204138641225@newsletter',
                                        newsletterName: botname,
                                        serverMessageId: 143
                                    }
                                }
                            })
                        }
                    }
                }, {})

                await Yori.relayMessage(msg.key.remoteJid, msg.message, {
                    messageId: msg.key.id
                })
            }
            
            await Yori.sendMessage(m.chat, { text: txxt, contextInfo: {
         externalAdReply: {
          showAdAttribution: true,
          title: ucapanWaktu,
          body: botname,
          thumbnailUrl: 'https://widipe.com/file/ojUtb3QgX1pW.jpg',
          sourceUrl: '',
          mediaType: 1,
          renderLargerThumbnail: true
        }
        }}, { quoted: mek })}
       await Yori.sendMessage(m.chat, { audio: fs.readFileSync('./mp3/private.mp3'), viewOnce: true, mimetype: 'audio/mp4', ptt:true}, { quoted:m });
       */
                break

            case 'antimenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Anti Menu*
 *⥁ Antich*   
 *⥁ Antiwame*
 *⥁ Antilink*
 *⥁ Antipanel*
 *⥁ Antitoxic*
 *⥁ Antilinktt*
 *⥁ Antilinkyt*
 *⥁ Antilinkgc*
 *⥁ Antilinkgcv1*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'groupmenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Group Menu*
 *⥁ Saran*
 *⥁ Reportbug*  
 *⥁ Antilinkgc on / off*
 *⥁ Antitoxic on / off*
 *⥁ Bcgc (textnya)*
 *⥁ Share (textnya)*
 *⥁ Yorr (textnya)*
 *⥁ Hidetag (textnya)*
 *⥁ Kick (628xx)*
 *⥁ Add (628xx)*
 *⥁ Group close / open*
 *⥁ Promote (628xx)*
 *⥁ Demote (628xx)*
 *⥁ Sendlinkgc (628xx)*
 *⥁ Editgroup close / open*
 *⥁ Editinfo on / off*
 *⥁ Join (linknya)*
 *⥁ Editsubjek (textnya)*
 *⥁ Editdesk (textnya)*
 *⥁ Tagall (textnya)*
 *⥁ Inspect (linknya)*
 *⥁ Linkgroup*
 *⥁ Resetlinkgc*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'downmenu': case 'downloadmenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Download Menu*
 *⥁ Fbdl (linknya)*
 *⥁ Igdl (linknya)*
 *⥁ Igslide (linknya)*
 *⥁ Tiktok (linknya)*
 *⥁ Ytmp3 (linknya)*
 *⥁ Ytmp4 (linknya)*
 *⥁ Mediafire (linknya)*
 *⥁ Capcut (linknya)*
 *⥁ Gdrive (linknya)*
 *⥁ Twitter (linknya)*
 *⥁ Spotify [ Name Artist ]*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }                
                break

            case 'islammenu': case 'islamimenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Islami Menu*
 *⥁ Asmaulhusna*
 *⥁ Ayatkursi* 
 *⥁ Doa*
 *⥁ Quotesislam*
 *⥁ Niatsholat*
 *⥁ Kisahnabi*
 *⥁ Jadwalsholat*
 *⥁ Tafsir*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'favmenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Favorite Menu*
 *⥁ Ai*
 *⥁ Wm*
 *⥁ S*
 *⥁ Hd*
 *⥁ Smeme*
 *⥁ Carbon*
 *⥁ Play*
 *⥁ Remini*
 *⥁ Confess*
 *⥁ Menfess*
 *⥁ Ig (Linknya)*
 *⥁ Tiktok (Linknya)*
 *⥁ Ttsearch (Teks)*
 *⥁ Ttslide (Linknya)*
 *⥁ Ytmp3 (Linknya)*
 *⥁ Ytmp4 (linknya)*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break
                case 'ownermenu': {
if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
YoriLD()
await sleep(1000)
Yorireply(`📦 *Owner Menu*
 *⥁ Ban*   
 *⥁ Enc* 
 *⥁ Self*  
 *⥁ Public*
 *⥁ Getdb*
 *⥁ Getuser*   
 *⥁ Addprem*
 *⥁ Cekidgc*
 *⥁ CreateQr*    
 *⥁ DetectQr*
 *⥁ Addlimit*
 *⥁ Dellimit*
 *⥁ Resetlimit*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
}
                break

            case 'convertmenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Convert Menu*
 *⥁ Wm*
 *⥁ Tomp3*
 *⥁ Tourl*
 *⥁ Toimg*
 *⥁ Rvo*
 *⥁ Smeme*
 *⥁ Remini*
 *⥁ Img2Txt*
 *⥁ Img2Promt*  
 *⥁ Removebg*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'photomenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Photooxy Menu*
 *⥁ Glitchtext*
 *⥁ Writetext*
 *⥁ Blackpinklogo*
 *⥁ Advancedglow*
 *⥁ Typographytext*
 *⥁ Pixelglitch*
 *⥁ Neonglitch*
 *⥁ Flag*
 *⥁ Flag2*
 *⥁ Deletingtext*
 *⥁ Blackpinkstyle*
 *⥁ Glowingtext*
 *⥁ Underwater*
 *⥁ Logomaker*
 *⥁ Cartoonstyle*
 *⥁ Papercut*
 *⥁ Watercolor*
 *⥁ Effectclouds*
 *⥁ Gradienttext*
 *⥁ Summerbeach*
 *⥁ Luxurygold*
 *⥁ Multicolored*
 *⥁ Sandsummer*
 *⥁ Galaxy*
 *⥁ 1917style*
 *⥁ Makingneon*
 *⥁ Royaltext*
 *⥁ Texteffect*
 *⥁ Galaxystyle*
 *⥁ Lighteffect*
 *⥁ Flaming*   
 *⥁ Stars*
 *⥁ Shadow*
 *⥁ Burnpaper*
 *⥁ Grass*
 *⥁ Underwater*
 *⥁ Whitecube*
 *⥁ Smokyneon*
 *⥁ Fabric*
 *⥁ Glowing*
 *⥁ Honey*
 *⥁ Vintage*
 *⥁ Gradient*
 *⥁ Fur*
 *⥁ Striking*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'pushmenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                const y11 = `📦 *Push Menu*
 *⥁ Cekidgc*
 *⥁ Savekontak*
 *⥁ Pushkontak*
 *⥁ Pushkontak2*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`
                Yorireply(y11)
            }
                break

            case 'randommenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Random Menu*
 *⥁ Qc*
 *⥁ Afk*
 *⥁ Owner*
 *⥁ Nickff*
 *⥁ Puisi*
 *⥁ Pantun*
 *⥁ Qckode*
 *⥁ Sticker*
 *⥁ Sewa*
 *⥁ Faktaunik*
 *⥁ Couple*
 *⥁ Meme*
 *⥁ Getname*
 *⥁ Getpic*
 *⥁ Confess*
 *⥁ Menfess*
 *⥁ Stalktiktok*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'asupanmenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Asupan Menu* (  New Update  )
 *⥁ Tobrut*
 *⥁ Tobrut2*
 *⥁ Cewecantik*
 *⥁ Cecan*
 *⥁ 18*
 *⥁ Bokep*
 *⥁ Paptt*
`)
            }
                break

            case 'cecanmenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Cecan Menu* (  New Update  )
 *⥁ China*
 *⥁ Hijab*
 *⥁ Cewecantik*
 *⥁ Cecan*
 *⥁ Tobrut*
 *⥁ Toketbrutal*
 *⥁ Indo*
 *⥁ Japanese/Jepang/Japan*
 *⥁ Korean*
 *⥁ Malay*
 *⥁ Randomgirl*
 *⥁ Randomboy*
 *⥁ Thai*
 *⥁ Vietnam*
 *⥁ Tiktokgirl*
 *⥁ Tiktokghea*
 *⥁ Tiktokbocil*
 *⥁ Tiktoknukthy*
 *⥁ Tiktoksantuy*
 *⥁ Tiktokkayes*
 *⥁ Tiktokpanrika*
 *⥁ Tiktoknotnot*
`)
            }
                break

            case 'aimenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Ai Menu*
 *⥁ Ai*
 *⥁ Ask*
 *⥁ Bing*
 *⥁ Blackbox*
 *⥁ GPT4*
 *⥁ Gpt4_2*
 *⥁ Gptgo*
 *⥁ Gpt*
 *⥁ Llama3*
 *⥁ OpenAi*
 *⥁ Yori-ai*
 *⥁ Autoai*
 *⥁ Luminai*
 *⥁ Toanime*
 *⥁ Lepton*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break
                case 'film menu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Film Search*
 *⥁ Filmsearch [ Name Film ]*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'searchmenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Search Menu*
 *⥁ Ai*
 *⥁ Imdb*
 *⥁ Play*
 *⥁ Song*
 *⥁ Chord* 
 *⥁ Lirik*
 *⥁ Cuaca*
 *⥁ Jarak*
 *⥁ Reminder*
 *⥁ Google*
 *⥁ OpenAi*
 *⥁ Yorichan*
 *⥁ Kodebahasa*
 *⥁ Cariresep*
 *⥁ Resep*
 *⥁ Otakudesu*
 *⥁ Apksearch*
 *⥁ Searchanime*
 *⥁ Sanime*
 *⥁ Drakorsearch*
 *⥁ Yousearch*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'gassmenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Gass Menu*
 *⥁ Sc*
 *⥁ Autoread on/off*
 *⥁ Getdb (database)*
 *⥁ Getuser (database user)*
 *⥁ Setppbot*
 *⥁ Setppgroup*
 *⥁ Block*
 *⥁ Unblock*
 *⥁ Spamsms (628xx)*
 *⥁ Call (628xx)*
 *⥁ Kenon (628xx)*
 *⥁ Verif@ (628xx)*
 *⥁ Banned (628xx)*
 *⥁ Createqr*
 *⥁ Unbannedv2 (628xx)*
 *⥁ Unbannedv3 (628xx)*
 *⥁ Unbannedv4 (628xx)*
 *⥁ Unbannedv5 (628xx)*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'weebsmenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Weebs Menu*
 *⥁ Pat*
 *⥁ Cry*
 *⥁ Hug*
 *⥁ Nom*
 *⥁ Awoo*
 *⥁ Kiss*
 *⥁ Kill*
 *⥁ Lick*
 *⥁ Bite*
 *⥁ Yeet*
 *⥁ Bonk*
 *⥁ Wink*
 *⥁ Poke*
 *⥁ Slap*
 *⥁ Bully*
 *⥁ Smile*
 *⥁ Wave*
 *⥁ Blush*
 *⥁ Smug*
 *⥁ Glomp*
 *⥁ Happy*
 *⥁ Dance*
 *⥁ Cuddle*
 *⥁ Cringe*
 *⥁ Highfive*
 *⥁ Handhold*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'beritamenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Berita Menu*
 *⥁ Inews*
 *⥁ Kontan*
 *⥁ KompasNews*
 *⥁ DetikNews*
 *⥁ DailyNews*
 *⥁ Cuaca*
 *⥁ Gempa*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'quotesmenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Quotes Menu*
 *⥁ FML*
 *⥁ Bucin*
 *⥁ Quotes*
 *⥁ Motivasi*
 *⥁ Katabijak*
 *⥁ Katacinta*
 *⥁ Katagalau*
 *⥁ Katahacker*
 *⥁ Katailham*
 *⥁ Katasenja*
 *⥁ Galau*
 *⥁ Sad*
 *⥁ Katasindiran*
 *⥁ Quotesanime*
 *⥁ Quotespubg*
 *⥁ Quotesislamic*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'gamemenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Game Menu*
 *⥁ TTC*
 *⥁ Deltc*
 *⥁ Tebak Kata*
 *⥁ Tebak Gambar*
 *⥁ Tebak Lirik*
 *⥁ Tebak Kalimat*
 *⥁ Tebak Lontong*
 *⥁ Kuismath Noob*
 *⥁ Kuismath Easy*
 *⥁ Kuismath Medium*
 *⥁ Kuismath Hard*
 *⥁ Kuismath Extreme*
 *⥁ Kuismath Imposibble*
 *⥁ Kuismath Imposibble2*
 *⥁ Suit*
 *⥁ Clan* [ Name Clans ]

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'funmenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Fun Menu*
 *⥁ Truth*
 *⥁ Dare*
 *⥁ Rate*
 *⥁ Apakah*
 *⥁ Kapankah*
 *⥁ Bisakah*
 *⥁ Bagaimanakah* 
 *⥁ Gantengcek*
 *⥁ Cekganteng*
 *⥁ Cantikcek*
 *⥁ Cekcantik*
 *⥁ Sangecek*
 *⥁ Ceksange*
 *⥁ Gaycek*
 *⥁ Cekgay*
 *⥁ Lesbicek*
 *⥁ Ceklesbi*
 *⥁ Cekkontol*
 *⥁ Cekmemek*
 *⥁ Cekkhodam*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'toko': case 'tokomenu': case 'shop': case 'shopmenu': case 'store': case 'storemenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Store Menu*
 *⥁ Sc*
 *⥁ Pay*
 *⥁ Panel*
 *⥁ Order*
 *⥁ Tambah*
 *⥁ Kurang*
 *⥁ Kali*
 *⥁ Bagi*
 *⥁ List*
 *⥁ Addlist*
 *⥁ Dellist*
 *⥁ Payment*
 *⥁ Pesanan*
 *⥁ Updatelist*
 *⥁ Listjapost*
 *⥁ Feerekber*
 *⥁ Done*
 *⥁ Done1*
 *⥁ Formatneed*
 *⥁ Prosess*
 *⥁ Deposit [ Amount ]*
 *⥁ Deposit-2 [ Amount ]*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'cpanelmenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`📦 *Cpanel Menu*
 
 📦 *Panel Menu*
 *⥁ Buatpanel
 *⥁ Listusr
 *⥁ Delusr
 *⥁ Listsrv
 *⥁ Delsrv
 *⥁ Tutorial
 *⥁ Ramlist
 *⥁ Premlist
 *⥁ Addusr
 *⥁ Addsrv
 *⥁ Updatesrv
 *⥁ Suspend
 *⥁ Unsuspend
 *⥁ Createadmin
 *⥁ Listadmin
 
 *Panel Menu*
 
 *⥁ 1gb [user,nomor]*
 *⥁ 2gb [user,nomor]*
 *⥁ 3gb [user,nomor]*
 *⥁ 4gb [user,nomor]*
 *⥁ 5gb [user,nomor]*
 *⥁ 6gb [user,nomor]*
 *⥁ 7gb [user,nomor]*
 *⥁ 8gb [user,nomor]*
 *⥁ 9gb [user,nomor]*
 *⥁ Unli [user,nomor]*
 
⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'animemenu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                await sleep(1000)
                Yorireply(`*Anime Menu*
 
 *⥁ Loli*
 *⥁ Milf*
 *⥁ Nsfwloli* [ Premium ]
 *⥁ Pussy* [ Premium ]
 *⥁ Shota*
 *⥁ Yuri*
 *⥁ Zettai*
 *⥁ Cuckold*
 *⥁ Husbu*
 *⥁ Eba*
 *⥁ Foot*
 *⥁ Hneko*
 *⥁ Hentaineko*
 *⥁ Akira*
 *⥁ Akiyama*
 *⥁ Ana*
 *⥁ Art*
 *⥁ Asuna*
 *⥁ Ayuzawa*
 *⥁ Boruto*
 *⥁ Bts*
 *⥁ Chiho*
 *⥁ Chitoge*
 *⥁ Cosplay*
 *⥁ Cosplayloli*
 *⥁ Cosplaysagiri*
 *⥁ Cyber*
 *⥁ Deidara*
 *⥁ Doraemon*
 *⥁ Elaina*
 *⥁ Emilia*
 *⥁ Erza*
 *⥁ Exo*
 *⥁ Gamewallpaper*
 *⥁ Gremory*
 *⥁ Hacker*
 *⥁ Hestia*
 *⥁ Hinata*
 *⥁ Husbu*
 *⥁ Inori*
 *⥁ Islamic*
 *⥁ Isuzu*
 *⥁ Itachi*
 *⥁ Itori*
 *⥁ Jennie*
 *⥁ Jiso*
 *⥁ Justina*
 *⥁ Kaga*
 *⥁ Kagura*
 *⥁ Kakasih*
 *⥁ Kaori*
 *⥁ Cartoon*
 *⥁ Shortquote*
 *⥁ Keneki*
 *⥁ Kotori*
 *⥁ Kurumi*
 *⥁ Lisa*
 *⥁ Madara*
 *⥁ Megumin*
 *⥁ Mikasa*
 *⥁ Mikey*
 *⥁ Miku*
 *⥁ Minato*
 *⥁ Mountain*
 *⥁ Naruto*
 *⥁ Neko2*
 *⥁ Nekoanime*
 *⥁ Nezuko*
 *⥁ Onepiece*
 *⥁ Pentol*
 *⥁ Pokemon*
 *⥁ Programming
 *⥁ Randomanime*
 *⥁ Randomanime2*
 *⥁ Rize*
 *⥁ Rose*
 *⥁ Sagiri*
 *⥁ Sakura*
 *⥁ Sasuke*
 *⥁ Satanic*
 *⥁ Shina*
 *⥁ Shinka*
 *⥁ Shinomiya*
 *⥁ Shizuka*
 *⥁ Shota*
 *⥁ Space*
 *⥁ Technology*
 *⥁ Tejina*
 *⥁ Toukachan*
 *⥁ Tsunade*
 *⥁ Yotsuba*
 *⥁ Yuki*
 *⥁ Yulibocil*
 *⥁ Yumeko*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'panduan': case 'help': {
                {
                    let eek = m.sender;
                    Yori.sendMessage(m.chat, {
                        react: {
                            text: '✅',
                            key: m.key
                        }
                    });
                    let pesan = `*Panduan Untuk Menggunakan Fitur Bot Yori Chan*

*#1 Membuat Sticker Whatsapp*
*#2 Membuat Sticker Video*
*#3 Mengubah Watermark Sticker*
*#4 Meningkatkan Kualitas Gambar*
*#5 Mengunduh Foto/Video Dari Link*
*#6 Mengunduh Audio/Video Youtube*
*#7 Mengunduh Lagu/Musik*
*#8 Bertanya Kepada Bot*
*#9 Mencari Berita*
*#10 Mengubah Gambar Menjadi Link*
*#11 Mengetahui Jarak Kota*
*#12 Menghapus Pesan Bot*

 *Untuk Menampilkan Panduan Ketik Sesuai Nomor, Contoh : NO1* 
 
 *Anda Juga Bisa Menggunakan Button Yang Sudah Di Sediakan Oleh Pencipta Saya >\\<*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya* 😄`;
                    let msg = generateWAMessageFromContent(from, {
                        viewOnceMessage: {
                            message: {
                                messageContextInfo: {
                                    deviceListMetadata: {},
                                    deviceListMetadataVersion: 0x2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: pesan
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: "Yori Chan || 2023 - 2024 New\n"
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        ...(await prepareWAMessageMedia({
                                            image: fs.readFileSync('./data/image/panduan.jpg')
                                        }, { upload: Yori.waUploadToServer })),
                                        title: '',
                                        gifPlayback: true,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            name: 'single_select',
                                            buttonParamsJson: JSON.stringify({
                                                title: "MENU PANDUAN YORI CHAN",
                                                sections: [{
                                                    title: "PILIH MENU PANDUAN YORI CHAN",
                                                    rows: [{
                                                        header: "PANDUAN NO 1",
                                                        title: "Click Here!!",
                                                        description: "Untuk Menampilkan Panduan No 1",
                                                        id: ".no1",
                                                    }, {
                                                        header: "PANDUAN NO 2",
                                                        title: "Click Here!!",
                                                        description: "Untuk Menampilkan Panduan No 2",
                                                        id: ".no2",
                                                    }, {
                                                        header: "PANDUAN NO 3",
                                                        title: "Click Here!!",
                                                        description: "Untuk Menampilkan Panduan No 3",
                                                        id: ".no3",
                                                    }, {
                                                        header: "PANDUAN NO 4",
                                                        title: "Click Here!!",
                                                        description: "Untuk Menampilkan Panduan No 6",
                                                        id: ".no6",
                                                    }, {
                                                        header: "PANDUAN NO 7",
                                                        title: "Click Here!!",
                                                        description: "Untuk Menampilkan Panduan No 7",
                                                        id: ".no7",
                                                    }, {
                                                        header: "PANDUAN NO 8",
                                                        title: "Click Here!!",
                                                        description: "Untuk Menampilkan Panduan No 8",
                                                        id: ".no8",
                                                    }, {
                                                        header: "PANDUAN NO 9",
                                                        title: "Click Here!!",
                                                        description: "Untuk Menampilkan Panduan No 9",
                                                        id: ".no9",
                                                    }, {
                                                        header: "PANDUAN NO 10",
                                                        title: "Click Here!!",
                                                        description: "Untuk Menampilkan Panduan No 10",
                                                        id: ".no10",
                                                    }, {
                                                        header: "PANDUAN NO 11",
                                                        title: "Click Here!!",
                                                        description: "Untuk Menampilkan Panduan No 11",
                                                        id: ".no11",
                                                    }, {
                                                        header: "PANDUAN NO 12",
                                                        title: "Click Here!!",
                                                        description: "Untuk Menampilkan Panduan No 12",
                                                        id: ".no12",
                                                    }]
                                                }]
                                            })
                                        }, {
                                            name: 'quick_reply',
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "Kode Bahasa",
                                                id: prefix + "kodebahasa"
                                            })
                                        }, {
                                            name: 'quick_reply',
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "𝘊𝘳𝘦𝘢𝘵𝘰𝘳",
                                                id: prefix + "owner"
                                            })
                                        }]
                                    })
                                })
                            }
                        }
                    }, {
                        userJid: from,
                        quoted: m
                    });
                    await Yori.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
                }
            }
                break
            /*
            case 'help': {
            Yorireply(`*Panduan Untuk Menggunakan Fitur Bot Yori Chan*
            
            *#1 Membuat Sticker Whatsapp*
            *#2 Membuat Sticker Video*
            *#3 Mengubah Watermark Sticker*
            *#4 Meningkatkan Kualitas Gambar*
            *#5 Mengunduh Foto/Video Dari Link*
            *#6 Mengunduh Audio/Video Youtube*
            *#7 Mengunduh Lagu/Musik*
            *#8 Bertanya Kepada Bot*
            *#9 Mencari Berita*
            *#10 Mengubah Gambar Menjadi Link*
            *#11 Mengetahui Jarak Kota*
            *#12 Menghapus Pesan Bot*
            
             *Untuk Menampilkan Panduan Ketik Sesuai Nomor, Contoh : NO1* 
             
             *Anda Juga Bisa Menggunakan Button Yang Sudah Di Sediakan Oleh Pencipta Saya >\\<*
            
            ⚠️ *Kalo Ada Error Bisa Chat Owner Ya* 😄
            `)
            }
            break
            */

            case '#1': case 'no1': {
                Yorireply(`🍃 *Membuat Sticker Whatsapp*

🎁 *Untuk Membuat Sticker Whatsapp Kirim Foto/Video Dengan Caption S, Stiker, Sticker*
🎁 *Untuk Membuat Sticker Dengan Caption Gunakan Smeme : Contoh Smeme YoriChan*`)
            }
                break

            case 'no2': {
                Yorireply(`🍃 *Membuat Sticker Video*

🎁 *Untuk Membuat Sticker Video Kirim Video Minimal 9 Detik Dengan CAption S*`)
            }
                break

            case 'no3': {
                Yorireply(`🍃 *Mengubah Watermark Sticker*

🎁 *Untuk Mengubah Watermark Sticker Balas Sticker Dengan Mengetik : Wm (Teks)*
🎁 *Contoh : Wm Nakano Ai*`)
            }
                break

            case 'no4': {
                Yorireply(`🍃 *Meningkatkan Kualitas Gambar*

🎁 *Untuk Meningkatkan Kualitas Gambar Kirim Gambar/Foto Dengan Caption Hd, Remini*`)
            }
                break

            case 'no5': {
                Yorireply(`🍃 *Mengunduh Foto/Video Dari Link*

🎁 *Untuk Mengunduh Foto/Video Dari Link Ketik : Tiktok (Link Tiktok)*
🎁 *Lebih Lengkapnya Ketik Downmenu*

⚠️ *Pastikan Link Sesuai Dengan Perintah*`)
            }
                break

            case 'no6': {
                Yorireply(`🍃 *Mengambil Audio/Video Dari Youtube*

🎁 *Untuk mengambil Audio/Video Dari Youtube Ketik : Ytmp4 (Link)*
🎁 *Ytmp3 Untuk Audio | Ytmp4 Untuk Video*

⚠️ *Audio/Video Lebih Dari 5 Menit Kemungkinan Gagal Dikirim*`)
            }
                break

            case 'no7': {
                Yorireply(`🍃 *Mengunduh Lagu/Musik*

🎁 *Untuk Mengunduh Lagu ketik : Play (Nama Lagu)*
🎁 *Contoh : Play Boa - Duvet*`)
            }
                break

            case 'no8': {
                Yorireply(`🍃 *Bertanya Kepada Bot*

🎁 *Untuk Bertanya kepada Bot Ketik : Ask (Pertanyaan)*
🎁 *Contoh : Ask Sejarah Indonesia*`)
            }
                break

            case 'no9': {
                Yorireply(`🍃 *Mencari Berita*

🎁 *Untuk Mencari Berita Ketik : Inews*
🎁 *Lebih Lengkapnya Ketik Beritamenu*`)
            }
                break

            case 'no10': {
                Yorireply(`🍃 *Mengubah Gambar Menjadi Link*

🎁 *Untuk Mengubah Gambar Menjadi Link Kirim Gmbar Dengan caption Tourl*`)
            }
                break

            case 'no11': {
                Yorireply(`🍃 *Mengetahui Jarak Kota*

🎁 *Untuk Mengetahui Jarak Kota ketik : Jarak (Nama Kota)|(Nama Kota)*
🎁 *Contoh : Jarak Bandung|Jakarta*`)
            }
                break

            case 'no12': {
                Yorireply(`🍃 *Menghapus Pesan Bot*

🎁 *Untuk Menghapus Pesan Bot Balas Pesan Bot Dengan Mengetik : Del*`)
            }
                break

            case 'kodebahasa': {
                Yorireply(`*Kode Bahasa*

 *⨠ Af: Afrikaans* 
 *⨠ Sq: Albanian*
 *⨠ Ar: Arabic*
 *⨠ Hy: Armenian*
 *⨠ Ca: Catalan* 
 *⨠ Zh: Chinese*
 *⨠ Zh-Cn: Chinese (Mandarin/China)*
 *⨠ Zh-Tw: Chinese (Mandarin/Taiwan)*
 *⨠ Zh-Yue: Chinese (Cantonese)*
 *⨠ Hr: Croatian*
 *⨠ Cs: Czech*
 *⨠ Da: Danish*
 *⨠ Nl: Dutch*
 *⨠ En: English*    
 *⨠ En-Au: English (Australia)*
 *⨠ En-Uk: English (United Kingdom)*
 *⨠ en-Us: English (United States)* 
 *⨠ Eo: Esperanto* 
 *⨠ Fi: Finnish* 
 *⨠ Fr: French*
 *⨠ De: German*
 *⨠ El: Greek* 
 *⨠ Ht: Haitian Creole* 
 *⨠ Hi: Hindi* 
 *⨠ Hu: Hungarian* 
 *⨠ Ss: Icelandic* 
 *⨠ Id: Indonesian* 
 *⨠ It: Italian*
 *⨠ Ja: Japanese*
 *⨠ Ko: Korean*
 *⨠ La: Latin*
 *⨠ Lv: Latvian*
 *⨠ Mk: Macedonian*
 *⨠ No: Norwegian*
 *⨠ Pl: Polish*
 *⨠ Pt: Portuguese*
 *⨠ Pt-Br: Portuguese (Brazil)*
 *⨠ Ro: Romanian*
 *⨠ Ru: Russian*
 *⨠ Sr: Serbian*
 *⨠ Sk: Slovak*
 *⨠ Es: Spanish* 
 *⨠ Es-Es: Spanish (Spain)*
 *⨠ Es-Us: Spanish (United States)*
 *⨠ Sw: Swahili*
 *⨠ Sv: Swedish*
 *⨠ Ta: Tamil*
 *⨠ Th: Thai*
 *⨠ Tr: Turkish*
 *⨠ Vi: Vietnamese* 
 *⨠ Cy: Welsh*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

case 'cariresep':
    case 'resep': {
    if (!text) return Yorireply('Contoh: resep capcay');   
    Yorireply(mess.wait);   
    fetchJson(`https://widipe.com/caribacaresep?query=${text}`)
        .then(a => {
            let result = a.hasil.data;
            if (!result) return Yorireply('Resep tidak ditemukan.');

            let caption = `🧾 Judul : ${result.judul}

⏱ Waktu Masak : ${result.waktu_masak}

🍽 Hasil : ${result.hasil}

📈 Tingkat Kesulitan : ${result.tingkat_kesulitan}

🍴 Bahan : ${result.bahan}

🔖 Langkah langkah : ${result.langkah_langkah}`;
            
            Yori.sendMessage(m.chat, {
                text: caption,
                contextInfo: {
                    externalAdReply: {
                        title: 'Cari Resep',
                        body: result.judul,
                        showAdAttribution: true,
                        mediaType: 1,
                        sourceUrl: 'https://chat.whatsapp.com/IRimbEMvL16AzrxxPGJJqU',
                        thumbnailUrl: result.thumb, 
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: m });
        })
        .catch(error => {
            Yorireply('Terjadi kesalahan saat mengambil data resep.');
            console.error(error);
        });
}


                break;
/*
            case 'sc':
            case 'script': {
                let msgs = generateWAMessageFromContent(m.chat,
                    {
                        viewOnceMessage: {
                            message: {
                                "messageContextInfo": {
                                    "deviceListMetadata": {},
                                    "deviceListMetadataVersion": 2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: botname
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: botname
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        title: `SELL SCRIPT YORI CHAN NO ENC 100%
- Type = Case Cjs
- Fitur = 600+++
*Price Script Yori Chan :*
- 💸 35.000 NO ENCRYPT FREE APIKEY
- _*Note : Dapat update Fitur tiap hari nonstop*_
*Kelebihan Fitur Script List :*
- *Jadi anime*
-   *Jadi nyata*
- Sistem Gateaway Qris
- Spotify search
- Spotify Download
- instagram Download
- Tiktok Download
- Facebook Download
- Menu Button
- Game Menu
- Tebak kata
- Tebak gambar
- Tebak gambar jkt48
- Menu List Button
- *Antilink Group*
- Welcome
- Goodbye
- Play YouTube
- Ytmp3
- Ytmp4
- Pinterest Image Geser
- Anime Menu
- Logo Menu
- Dan Lain Lain
Jika Anda Berminat Click Button👇
`,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            "name": "cta_url",
                                            "buttonParamsJson": "{\"display_text\":\"Buy Script\",\"url\":\"https://wa.me/62895342022385\",\"merchant_url\":\"https://www.google.com\"}"
                                        }],
                                    })
                                })
                            }
                        }
                    },
                    {});

                return Yori.relayMessage(m.chat,
                    msgs.message,
                    {
                        messageId: m.key.id
                    });
            }
            */
            case 'sc': 
              case 'script': {
    if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
    let txxt = `SELL SCRIPT YORI CHAN NO ENC 100%
- Type = Case Cjs
- Fitur = 600+++
*Price Script Yori Chan :*
- 💸 35.000 NO ENCRYPT FREE APIKEY
- _*Note : Dapat update Fitur tiap hari nonstop*_
*Kelebihan Fitur Script List :*
- *Jadi anime*
-   *Jadi nyata*
- Sistem Gateaway Qris
- Spotify search
- Spotify Download
- instagram Download
- Tiktok Download
- Facebook Download
- Menu Button
- Game Menu
- Tebak kata
- Tebak gambar
- Tebak gambar jkt48
- Menu List Button
- *Antilink Group*
- Welcome
- Goodbye
- Play YouTube
- Ytmp3
- Ytmp4
- Pinterest Image Geser
- Anime Menu
- Logo Menu
- Dan Lain Lain
Jika Anda Berminat Hubungi Pencipta Saya Di bawah👇
Wa.me/+62895342022385
`;

    await Yori.sendMessage(m.chat, { 
        text: txxt, 
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: ucapanWaktu,
                body: botname,
                thumbnailUrl: 'https://widipe.com/file/ojUtb3QgX1pW.jpg', // URL thumbnail
                sourceUrl: 'https://whatsapp.com/channel/0029VaKoIaj9cDDgB6N9u232', // URL Tujuan
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: mek });

    await Yori.sendMessage(m.chat, { 
        audio: fs.readFileSync('./mp3/ntah.mp3'), 
        mimetype: 'audio/mp4', 
        ptt: true 
    }, { quoted: m });
}

                break

            case 'pembayaran': {
                let msgs = generateWAMessageFromContent(m.chat,
                    {
                        viewOnceMessage: {
                            message: {
                                "messageContextInfo": {
                                    "deviceListMetadata": {},
                                    "deviceListMetadataVersion": 2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: ownername
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: botname
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        title: `Hai Kak ${pushname} Silahkan Anda Pilih Metode Payment Pembayaran Yang Tersedia Di bawah Ini`,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"GO-PAY","id":".gopay"}`
                                        },
                                        {
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"DANA","id":".dana"}`
                                        },
                                        {
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"OVO","id":".ovo"}`
                                        },
                                        {
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"QRIS","id":".deposit"}`
                                        }],
                                    })
                                })
                            }
                        }
                    },
                    {});

                return Yori.relayMessage(m.chat,
                    msgs.message,
                    {
                        messageId: m.key.id
                    });
            }
                break

case 'deposit-2': {
    Yori.deposit = Yori.deposit || {};
    if (m.chat in Yori.deposit) return Yorireply('Masih Ada Transaksi Yang Tersedia!!\nLanjutkan Transaksi atau batalkan transaksi dengan mengirimkan Command: .canceldepo');
    Yori.deposit[m.chat] = true;

    try {
        if (!text) return Yorireply('Masukkan jumlahnya! Contoh: .deposit 1');

        Yori.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });

        const apiKey = global.paydisini.api;
        const validTime = 900;
        const checkInterval = 5000;

        const qrData = await createQR(apiKey, text, validTime);

        const msg = `\`Detail Status [ ${qrData.status} ]\`
        
- Kode Unik : ${qrData.unique_code}
- ID Transaksi : ${qrData.pay_id}
- Harga : Rp. ${toRupiah(Number(qrData.amount))}
- Biaya : Rp. ${toRupiah(Number(qrData.fee))}
- Batas Waktu : ${qrData.expired}
- Metode : ${qrData.service_name}`

let ads = baten.setBody(msg);
    ads += baten.setImage(`${qrData.qrcode_url}`);
    ads += baten.addCopy('KODE UNIK', `${qrData.unique_code}`);
    ads += baten.addreply('CANCEL DEPO', `#canceldepo ${qrData.unique_code}`);
    ads += baten.addreply('CEK DEPO', `#cekdepo ${qrData.unique_code}`);
    ads += baten.run(m.chat, Yori, m);

    } catch (error) {
        console.error(error);
        Yorireply('Gagal membuat kode QR pembayaran. Silakan coba lagi.');
    } finally {
        delete Yori.deposit[m.chat];
    }
}
break;

case 'canceldepo': {
    Yori.deposit = Yori.deposit || {};
    if (!(m.chat in Yori.deposit)) return Yorireply('Tidak ada deposit yang perlu dibatalkan.');

    try {
        const transactionId = text;
        if (!transactionId) return Yorireply('Masukkan ID transaksi yang ingin dibatalkan! Contoh: .canceldepo <ID TRX>');

        const cancelResponse = await cancelTrx(global.paydisini.api, transactionId);
        
        if (cancelResponse.success === 'Success') {
            delete Yori.deposit[m.chat];
            Yorireply('Deposit telah dibatalkan.');
        } else {
            Yorireply(`Gagal membatalkan deposit. Alasan: ${cancelResponse.message}`);
        }
    } catch (error) {
        console.error(error);
        Yorireply('Terjadi kesalahan saat membatalkan deposit. Silakan coba lagi.');
    }
}
                break;
            /*
            Fitur Credits :
            Ori Code : Syaii
            Recode Code To Case : ErerexID Chx
            Fix Dan Lain Lain : Adriansyah ( Xyzen ) 
            Note : Buat para creator jangan sebar code ini ke siapapun demi kecaperan anda jika para creator credit di atas mengetahui akan ada akibatnya
            */
            case 'deposit': {
                let isProcess = false;
                if (!text) return Yorireply(`*• Example :* Deposit *[amount]*
- Note :  Jika Anda sudah melakukan  pembayaran Jangan lupa anda ketik *Prosess [ produk yang di beli ]*`);
                let amount = text.split(" ")[0];
                let metode = text.slice(amount.length + 1);
                if (isNaN(amount)) return Yorireply("*[ System notice ]* Masukkan angka, bukan huruf");
                var conf = new FormData();
                if (!metode) {
                    conf.append("key", maupedia.key);
                    conf.append("sign", maupedia.signature);
                    conf.append("secret", maupedia.secret);
                    conf.append("type", "method");
                    var settings = {
                        method: "post",
                        maxBodyLength: Infinity,
                        url: "https://maupedia.com/api/deposit",
                        data: conf,
                    };
                    let { data } = await axios(settings).catch((e) => e?.response);
                    if (!data.result) return Yorireply("*[ System notice ]* " + data.data.message);
                    let list = data.data.filter((a) => a.type === "qris");
                    await Yori.sendList(m.chat, `*[ System notice ]* Silahkan pilih metode Deposit anda dibawah`, `*• Example :* ${prefix + " " + command + amount}`, {
                        title: 'Click Type Qris',
                        sections: [
                            {
                                title: 'Result',
                                highlight_label: "Best Result",
                                rows: list.map(i => ({
                                    title: "• " + i.name,
                                    decoreion: `• Min : ${formatNumber(i.min)}\n• Max : ${formatNumber(i.max)}`,
                                    id: `${prefix + command + " " + amount + " " + i.code}`,
                                }))
                            }]
                    })
                } else if (metode === "cancel") {
                    conf.append("key", maupedia.key);
                    conf.append("sign", maupedia.signature);
                    conf.append("secret", maupedia.secret);
                    conf.append("type", "cancel");
                    conf.append("trxid", amount);
                    var settings = {
                        method: "post",
                        maxBodyLength: Infinity,
                        url: "https://maupedia.com/api/deposit",
                        data: conf,
                    };
                    let response = await axios(settings);
                    isProcess = true;
                    Yorireply(response.data.message);
                } else {
                    conf.append("key", maupedia.key);
                    conf.append("sign", maupedia.signature);
                    conf.append("secret", maupedia.secret);
                    conf.append("type", "request");
                    conf.append("method", metode);
                    conf.append("quantity", amount);
                    var settings = {
                        method: "post",
                        maxBodyLength: Infinity,
                        url: "https://maupedia.com/api/deposit",
                        data: conf,
                    };
                    let response = await axios(settings);
                    let hasil = response.data;
                    if (!hasil.result) return Yorireply(`*[ System notice ]* ${hasil.message}`);
                    const qrCodeData = await require("qrcode").toDataURL(
                        hasil.data.qr_string.slice(0, 2048),
                        {
                            scale: 10,
                        },
                    );
                    const buffer = Buffer.from(qrCodeData.substring(22), "base64");
                    let cap = `*[ DEPOSIT BY YORI CHAN ]*
*• Name :* ${hasil.data.name}
*• TrxId :* ${hasil.data.trxid}
*• Status :* ${hasil.data.status.toUpperCase()}
*• Amount/Nominal :* ${formatNumber(hasil.data.amount)}
*• Fee :* ${hasil.data.fee}
*• Note :* ${hasil.data.pay_note}
*• Checkout :* ${hasil.data.qr_url}
*• Create at :* ${hasil.data.created_at}
*• Expired at :* ${hasil.data.expired_at}`;
                    let q = await Yori.sendMessage(
                        m.chat,
                        {
                            image: buffer,
                            caption: cap,
                        },
                        {
                            quoted: m,
                        },
                    );

                    while (!isProcess) {
                        var data = new FormData();
                        data.append("key", maupedia.key);
                        data.append("sign", maupedia.signature);
                        data.append("secret", maupedia.secret);
                        data.append("type", "status");
                        data.append("trxid", hasil.data.trxid);

                        var settings = {
                            method: "post",
                            maxBodyLength: Infinity,
                            url: "https://maupedia.com/api/deposit",
                            data: data,
                        };

                        let status = await (await axios(settings)).data;
                        console.log(
                            "[ System Notice ] Detail Deposit : " + status.data[0].status,
                        );
                        if (status.data[0].status === "paid") {
                            let user = global.db.data.users[m.sender];
                            isProcess = true;
                            user.saldo += parseInt(amount);
                            await m.reply(
                                `*[ TRANSAKSI SUCCESS ]*
                                
SILAHKAN ANDA LANGSUNG CHAT CREATOR SAYA
                                
*• TrxId :* ${status.data[0].trxid}
*• Amount/Nominal :* ${formatNumber(status.data[0].amount)}
*• Status :* ${status.data[0].status.toUpperCase()}
*• Update at :* ${status.data[0].updated_at}

Saldo Sudah masuk ke akun anda !, Total saldo kamu sekarang *Rp ${formatNumber(user.saldo)}*. Jangan lupa anda ketik *Prosess [ Barang Yang Di Beli ]*`,
                            );
                        }
                    }
                }
            };
                break
            case 'gopay': {
                let msgs = generateWAMessageFromContent(m.chat,
                    {
                        viewOnceMessage: {
                            message: {
                                "messageContextInfo": {
                                    "deviceListMetadata": {},
                                    "deviceListMetadataVersion": 2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: botname
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: botname
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        title: `GO-PAY : \n 0895339369871\n *_Jangan Lupa Screenshot Bukti Transfer Ya Kak ${pushname}_*`,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            "name": "cta_copy",
                                            "buttonParamsJson": "{\"display_text\":\"copy\",\"id\":\"123456789\",\"copy_code\":\"0895339369871\"}"
                                        }],
                                    })
                                })
                            }
                        }
                    },
                    {});

                return Yori.relayMessage(m.chat,
                    msgs.message,
                    {
                        messageId: m.key.id
                    });
            }
                break
            case 'dana': {
                let msgs = generateWAMessageFromContent(m.chat,
                    {
                        viewOnceMessage: {
                            message: {
                                "messageContextInfo": {
                                    "deviceListMetadata": {},
                                    "deviceListMetadataVersion": 2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: botname
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: botname
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        title: `DANA : \n 0895339369871 \n *_Jangan Lupa Screenshot Bukti Transfer Ya Kak ${pushname}_*`,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            "name": "cta_copy",
                                            "buttonParamsJson": "{\"display_text\":\"copy\",\"id\":\"123456789\",\"copy_code\":\"0895339369871\"}"
                                        }],
                                    })
                                })
                            }
                        }
                    },
                    {});

                return Yori.relayMessage(m.chat,
                    msgs.message,
                    {
                        messageId: m.key.id
                    });
            }
                break
            case 'ovo': {
                let msgs = generateWAMessageFromContent(m.chat,
                    {
                        viewOnceMessage: {
                            message: {
                                "messageContextInfo": {
                                    "deviceListMetadata": {},
                                    "deviceListMetadataVersion": 2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: botname
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: botname
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        title: `OVO : \n 0895339369871 \n *_Jangan Lupa Screenshot Bukti Transfer Ya Kak ${pushname}_*
`,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            "name": "cta_copy",
                                            "buttonParamsJson": "{\"display_text\":\"copy\",\"id\":\"123456789\",\"copy_code\":\"0895339369871\"}"
                                        }],
                                    })
                                })
                            }
                        }
                    },
                    {});

                return Yori.relayMessage(m.chat,
                    msgs.message,
                    {
                        messageId: m.key.id
                    });
            }
                break
            case 'qris': {
                let msgs = generateWAMessageFromContent(m.chat,
                    {
                        viewOnceMessage: {
                            message: {
                                "messageContextInfo": {
                                    "deviceListMetadata": {},
                                    "deviceListMetadataVersion": 2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: botname
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: botname
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        title: `⚠️ _QRIS TIDAK TERSEDIA UNTUK SAAT_ INI \n *SILAHKAN ANDA PILIH METODE PEMBAYARAN LAIN*`,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"GO-PAY","id":".gopay"}`
                                        },
                                        {
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"DANA","id":".dana"}`
                                        },
                                        {
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"OVO","id":".ovo"}`
                                        }],
                                    })
                                })
                            }
                        }
                    },
                    {});

                return Yori.relayMessage(m.chat,
                    msgs.message,
                    {
                        messageId: m.key.id
                    });
            }
                break

            case 'list': case 'listmenu': {
                if (db_respon_list.length === 0) return Yorireply(`🍃 *Belum Ada List Yang Ditambahkan*`)
                if (!isAlreadyResponListGroup(m.chat, db_respon_list)) return Yorireply(`🍃 *Belum Ada List Yang Terdaftar Di Grup Ini*`)
                let teks = `🍃 *Halo @${m.sender.split("@")[0]}*\n📦 *Berikut Adalah List Item Yang Terdaftar Dalam Group :*\n\n`
                for (let i of db_respon_list) {
                    if (i.id === m.chat) {
                        teks += `🏷️ *${i.key.toUpperCase()}*\n`
                    }
                }
                teks += `\n📃 *Silahkan Ketik Nama Item Diatas Untuk Melihatnya Secara Detail*`
                Yori.sendMessage(m.chat, { text: teks, mentions: [m.sender] }, { quoted: m })
            }
                break

            case 'addlist':
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins) return Yorireply(mess.admin)
                var args1 = q.split("|")[0].toLowerCase()
                var args2 = q.split("|")[1]
                if (!q.includes("|")) return Yorireply(`🍃 *Cara Pengunaan : Addlist Item|Respon*\n🎁 *Contoh : Addlist Nakano Ai|Subscribe Nakano Ai*`)
                if (isAlreadyResponList(m.chat, args1, db_respon_list)) return Yorireply(`⚠️ *Nama Item ${args1} Sudah Terdaftar Dalam Group Ini*`)
                addResponList(m.chat, args1, args2, false, '-', db_respon_list)
                Yorireply(`📦 *Sukses Menambahkan Item Dengan Kode : ${args1}*`)
                break

            case 'dellist':
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins) return Yorireply(mess.admin)
                if (db_respon_list.length === 0) return Yorireply(`🍃 *Belum Ada List Yang Ditambahkan*`)
                if (!text) return Yorireply(`🍃 *Ketik Nama Item Yang Ingin Dihapus*`)
                if (!isAlreadyResponList(m.chat, q.toLowerCase(), db_respon_list)) return Yorireply(`⚠️ *Nama Item ${q} Tidak Terdaftar*`)
                delResponList(m.chat, q.toLowerCase(), db_respon_list)
                Yorireply(`⚠️ *Sukses Menghapus Item Dengan kode : ${q}*`)
                break

            case 'updatelist':
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins) return Yorireply(mess.admin)
                var args1 = q.split("|")[0].toLowerCase()
                var args2 = q.split("|")[1]
                if (!q.includes("|")) return Yorireply(`🍃 *Cara Pengunaan : Updatelist Item|Respon*\n🎁 *Contoh : Updatelist Yoriy|Subscribe Yori*`)
                if (!isAlreadyResponListGroup(m.chat, db_respon_list)) return Yorireply(`⚠️ *Nama Item ${args1} Sudah Terdaftar Dalam Group Ini*`)
                updateResponList(m.chat, args1, args2, false, '-', db_respon_list)
                Yorireply(`📑 *Sukses Memperbarui Item Dengan Kode : ${args1}*`)
                break

            case 'tambah': {
                if (!text.includes('+')) return Yorireply(`🍃 *Contoh : 10.000 + 20.000*`)
                arg = args.join(' ')
                Yori1 = arg.split('+')[0]
                Yori2 = arg.split('+')[1]
                var Yori_1 = Number(Yori1)
                var Yori_2 = Number(Yori2)
                Yorireply(`🎁 *Hasil :* ${Yori_1 + Yori_2}`)
            }
                break

            case 'kurang': {
                if (!text.includes('-')) return Yorireply(`🍃 *Contoh : 20 - 10*`)
                arg = args.join(' ')
                Yori1 = arg.split('-')[0]
                Yori2 = arg.split('-')[1]
                var Yori_1 = Number(Yori1)
                var Yori_2 = Number(Yori2)
                Yorireply(`🎁 *Hasil :* ${Yori_1 - Yori_2}`)
            }
                break

            case 'kali': {
                if (!text.includes('*')) return Yorireply(`🍃 *Contoh : 5 * 10*`)
                arg = args.join(' ')
                Yori1 = arg.split('*')[0]
                Yori2 = arg.split('*')[1]
                var Yori_1 = Number(Yori1)
                var Yori_2 = Number(Yori2)
                Yorireply(`🎁 *Hasil :* ${Yori_1 * Yori_2}`)
            }
                break

            case 'bagi': {
                if (!text.includes('/')) return Yorireply(`🍃 *Contoh : 10 / 2*`)
                arg = args.join(' ')
                Yori1 = arg.split('/')[0]
                Yori2 = arg.split('/')[1]
                var Yori_1 = Number(Yori1)
                var Yori_2 = Number(Yori2)
                Yorireply(`🎁 *Hasil :* ${Yori_1 / Yori_2}`)
            }
                break

            case 'order':
            case 'pesanan': {
                let Yori_txt = args[0]
                if (!text) return Yorireply('🍃 *Mana Teksnya?*')
                Yorireply('📦 *Pesanan Berhasil Terkirim*\n🎁 *Pesanan Anda Akan Dibalas Secepatnya, Terimakasih*')
                Yori.sendMessage(`${mess.owner2}@s.whatsapp.net`, { text: `📣 *Pesanan Nih*\n🎁 *Dari :* @${sender.split('@')[0]}\n📄 *Nomor :* ${sender.split('@')[0]}\n📑 *Pemesan :* wa.me/${sender.split('@')[0]}\n📦 *Order :* ${q}\n\n 📣 *Pesanan Ini Dikirim Oleh YoriChan*`, mentions: [sender] }, { quoted: m })
            }
                break

            case 'donasi':
            case 'donate': {
                Yori.sendMessage(m.chat, { image: { url: `${mess.qris}` }, caption: `${mess.format}` }, { quoted: m })
            }
                break

            case 'sewapanel': {
                let msgs = generateWAMessageFromContent(m.chat,
                    {
                        viewOnceMessage: {
                            message: {
                                "messageContextInfo": {
                                    "deviceListMetadata": {},
                                    "deviceListMetadataVersion": 2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: botname
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: botname
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        title: `SEWA PANEL DARI CREATOR KU

➠ PANEL PROMO FRESH PROMO

╭━「 PAKET SILVER 」
│⛁ RAM 1GB | CPU 30%
╰━━━☉ HARGA : 3k

╭━「 PAKET SILVER 」
│⛁ RAM 2GB | CPU 50%
╰━━━☉ HARGA : 5k

╭━「 PAKET GOLD 」
│⛁ RAM 3GB | CPU 70%
╰━━━☉ HARGA : 7K

╭━「 PLATINUM (HOT) 」
│⛁ RAM 4GB | CPU 90%
╰━━━☉ HARGA : 9K

╭━「 EXECUTIVE 」
│⛁ RAM 5GB | CPU 100%
╰━━━☉ HARGA : 10K

╭━「 ULTIMATE (HOT) 」
│⛁ RAM 7GB | CPU 130%
╰━━━☉ HARGA : 12K

╭━「 SUPER ULTIMATE 」
│⛁ RAM UNLI | CPU UNLI%
╰━━━☉ HARGA : 15K

*Reqwest ram dan cpu chat langsung

Keuntungan sewa panel di kami?
➠ Server terjaga 
➠ Jual kualitas bukan asal jual
➠ Hemat kuota 
➠ Hemat penyimpanan
➠ Web close? bot tetep on!

*Harga diatas adalah untuk 1bulan*
`,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"Pembayaran Payment","id":".pembayaran"}`
                                        }],
                                    })
                                })
                            }
                        }
                    },
                    {});

                return Yori.relayMessage(m.chat,
                    msgs.message,
                    {
                        messageId: m.key.id
                    });
            }
                break

            case 'listnokos': {
                let msgs = generateWAMessageFromContent(m.chat,
                    {
                        viewOnceMessage: {
                            message: {
                                "messageContextInfo": {
                                    "deviceListMetadata": {},
                                    "deviceListMetadataVersion": 2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: botname
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: botname
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        title: `> LIST NOKOS EREREXIDFAMILY
*READY STOK WHATSAPP/TELEGRAM*
*Nokos Virtual WhatsApp*
> United States +1 🇺🇲 (20k)
> Canadaa +1 🇨🇦 (20k)
> France +33 🇫🇷 (20k)
> Denmark +45 🇩🇰 (20k)
> Swedia +46 🇸🇪 (20k)
> Netherland +31 🇳🇱 (20k)
> Croassia +385 🇭🇷 (28k)
> Finlandia +358 🇫🇮 (20k)
> Bangladesh +880 🇧🇩 (20k)
> Pakistan +92 🇵🇰 (28k)
> Vietnam +84 🇻🇳 (28k)
> Cambodia +855 🇰🇭 (25k)
> Malaysia +60 🇲🇾 (25k)

*Indonesia Old & Fresh🇮🇩*
> *WhatsApp indo Old (15k)*
> Indonesia Fresh (5K) 
_*Stok Terbatas*_

*Nokos Virtual Telegram*
> United States +1 🇺🇲 (20k)
> Canada +1 🇨🇦 (20k)
> France +33 🇫🇷 (30k)
> Inggris +44🇬🇧 (30k)
> Denmark +45🇩🇰 (25k)
> Netherlands +31 🇳🇱 (28k)
> Vietnam +84 🇻🇳 (25k)
> Pakistan +92🇵🇰 (25k)
> Croassia +385🇭🇷 (20k)
> Cambodia +855 🇰🇭 (20k)
> Malaysia +60 🇲🇾 (25k)
_*Stok Terbatas!!*_

*List Nokos Virtual WhatsApp Yang Bisa Verifikasi Ulang (Verul)*
> France+33🇫🇷
> Netherlands+31 🇳🇱
> Denmark +45 🇩🇰
> SWEDIA +46 🇸🇪
> FINLANDIA +358 🇫🇮

*UNTUK MAU VERIFIKASI ULANG? NAMBAH TIP 5K UNTUK VERUL UNLIMITIED!!*

> 🛍️ @ErerexIDFamily
`,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            "name": "cta_url",
                                            "buttonParamsJson": "{\"display_text\":\"Chat 📝\",\"url\":\"https://wa.me/62895342022385?text=Hai+kak+ererexid+mau+beli+nomor+kosong+nya+dong+kak\",\"merchant_url\":\"https://www.google.com\"}"
                                        }],
                                    })
                                })
                            }
                        }
                    },
                    {});

                return Yori.relayMessage(m.chat,
                    msgs.message,
                    {
                        messageId: m.key.id
                    });
            }
                break

            case 'pay':
            case 'payment': {
                let msgs = generateWAMessageFromContent(m.chat,
                    {
                        viewOnceMessage: {
                            message: {
                                "messageContextInfo": {
                                    "deviceListMetadata": {},
                                    "deviceListMetadataVersion": 2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: botname
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: botname
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        ...(await prepareWAMessageMedia({ image: fs.readFileSync('./data/image/menu.jpg') }, { upload: Yori.waUploadToServer })),
                                        title: `🎁 *Pembayaran*\n📣 *All Payment Bisa Scan Qr Diatas(ERROR)*\n\n📃 *Metode Lain*\n🏷️ *Dana : 0895339369871*\n🏷️ *Gopay : 0895342022385*\n\n⚠️ *Dimohon Untuk Mengirim Bukti Pembayaran*\n\n❤️ *Terimakasih 😇*
`,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            "name": "cta_copy",
                                            "buttonParamsJson": "{\"display_text\":\"copy\",\"id\":\"123456789\",\"copy_code\":\"Dana : 0895339369871/GO-PAY : 0895342022385\"}"
                                        }],
                                    })
                                })
                            }
                        }
                    },
                    {});

                return Yori.relayMessage(m.chat,
                    msgs.message,
                    {
                        messageId: m.key.id
                    });
            }
                break
            case 'serverwl': {
                let msgs = generateWAMessageFromContent(m.chat,
                    {
                        viewOnceMessage: {
                            message: {
                                "messageContextInfo": {
                                    "deviceListMetadata": {},
                                    "deviceListMetadataVersion": 2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: botname
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: botname
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        ...(await prepareWAMessageMedia({ image: fs.readFileSync('./data/image/menu.jpg') }, { upload: Yori.waUploadToServer })),
                                        title: `Ini adalah daftar menu dari whitelist server kuntul roleplay

Daftarucp
Checkucp

Kalian Bisa Pencet Button di bawah ya Kak ${pushname} 😇*
`,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"Daftar Ucp 🔰","id":".daftarucp"}`
                                        }],
                                    })
                                })
                            }
                        }
                    },
                    {});

                return Yori.relayMessage(m.chat,
                    msgs.message,
                    {
                        messageId: m.key.id
                    });
            }
                break
            case 'list-jb': case 'listjb': case 'list-jebe': case 'list-store': case 'liststore': {
                {
                    let eek = m.sender;
                    Yori.sendMessage(m.chat, {
                        react: {
                            text: '⏳',
                            key: m.key
                        }
                    });
                    let pesan = `*👋🖐 Halo Kak @${sender.split('@')[0]}\n Kakak Bisa ketik\ List Japost \n List Need \n List Rekber \n Atau Anda Bisa Click Button Di bawah ya Kak ${pushname} ≧﹏≦*\n`;
                    let msg = generateWAMessageFromContent(from, {
                        viewOnceMessage: {
                            message: {
                                messageContextInfo: {
                                    deviceListMetadata: {},
                                    deviceListMetadataVersion: 0x2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: pesan
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: "🚩Jika ragu kami juga mempunyai testimoni yang bisa dilihat sendiri di saluran whatsapp kami maupun instagram ⌓̈⃝୨\n"
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        ...(await prepareWAMessageMedia({
                                            image: fs.readFileSync('./data/image/menu.jpg')
                                        }, { upload: Yori.waUploadToServer })),
                                        title: '',
                                        gifPlayback: true,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [/*
              ATUR SENDIRI MANDIRI
              MADE IN EREREXID
              KLO ERROR TANYA 
              WA : 0895342022385
              WA2 : 254774710755
              { 
                name: 'single_select',
                buttonParamsJson: JSON.stringify({
                  title: "LIST JB",
                  sections: [{
                    title: "PILIH LIST JB YANG MAU KAMU GUNAKAN",
                    rows: [{
                      header: "LIST JAPOST/JASA POST", 
                      title: "Click Here!!",
                      description: "Untuk Menampilkan Jasa Post",
                      id: ".listjapost", 
                    }, {
                      header: "LIST JASA FEE REKBER", 
                      title: "Click Here!!",
                      description: "Untuk Menampilkan Jasa Fee Rekber Admin",
                      id: ".feerekber", 
                    }, {
                      header: "LIST NEED/BUTUH AKUN",
                      title: "Click Here!!",
                      description: "Untuk Menampilkan Sebuah List Need Akun",
                      id: ".formatneed", 
                    }]
                  }]
                })
              },*/ {
                                                name: 'quick_reply',
                                                buttonParamsJson: JSON.stringify({
                                                    display_text: "LIST JAPOST/JASA POST",
                                                    id: prefix + "listjapost"
                                                })
                                            }, {
                                                name: 'quick_reply',
                                                buttonParamsJson: JSON.stringify({
                                                    display_text: "LIST NEED/BUTUH AKUN",
                                                    id: prefix + "formatneed"
                                                })
                                            }, {
                                                name: 'quick_reply',
                                                buttonParamsJson: JSON.stringify({
                                                    display_text: "LIST FREE REKBER",
                                                    id: prefix + "feerekber"
                                                })
                                            }]
                                    })
                                })
                            }
                        }
                    }, {
                        userJid: from,
                        quoted: m
                    });
                    await Yori.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
                }
            }
                break

            case 'listjapost': {
                Yorireply(`*FORMAT JASPOST BY ${ownername}*
(BUKAN AKUN MILIK ADMIN)
                   
AKUN :
LOG :
SPEK :
HARGA :
MC :
NAMA PEMBELI :

#📝NOTE‼️: WAJIB MENGGUNAKAN JASA ADMIN ${ownername} AGAR TERHINDAR DARI PENIPUAN
*#BEE A SMART BUYE & SELLER`)
            }
                break

            case 'formatneed': {
                Yorireply(`*FORMAT JASA NEED AKUN BY ${ownername}*

NAMA PEMILIK : 
AKUN :
LOGIN :
HARGA : 
SPEK AKUN :  
MC :                                                               
📝𝐍𝐎𝐓𝐄 : 
*WAJIB MENGGUNAKAN JASA ADMIN ${ownername} AGAR TERHINDAR DARI PENIPUAN*
*#BEE A SMART BUYER & SELLER`)
            }
                break

            case 'feerekber': {
                Yorireply(`FEE BER² ${ownername}
•0 - 99K ≠ 5K
•100K - 150K ≠ 10K
•151K - 200K ≠ 15K
•201K - 324K ≠ 20K
•325K - 400K ≠ 25K
•401K - 500K ≠ 30K
•501K - 599K ≠ 35K
•600K - 699K ≠ 40K
•700K - 799K ≠ 45K
•800K - 1JT ≠ 50K
•1,1JT - 1,7JT ≠ 55K`)
            }
                break
            case 'panel': {
                if (!text) return Yorireply('username nya mana kak');
                let user = { first_name: encodeURIComponent(text) };
                let sections = [{
                    title: 'Paket Server Panel',
                    highlight_label: 'Price Panel',
                    rows: [
                        { title: 'Price Panel', description: 'Price Panel Pterodactyl', id: `.sewapanel` },
                        { title: 'Unli', description: 'Unlimited Ram/Cpu', id: `.deposit` },
                        { title: '1Gb', description: 'RAM 1 GB | CPU 30 | DISK 1 GB', id: `.deposit` },
                        { title: '2Gb', description: 'RAM 2 GB | CPU 50 | DISK 2 GB', id: `.deposit` },
                        { title: '3Gb', description: 'RAM 3 GB | CPU 70 | DISK 3 GB', id: `.deposit` },
                        { title: '4Gb', description: 'RAM 4 GB | CPU 90 | DISK 4 GB', id: `.deposit` },
                        { title: '5Gb', description: 'RAM 5 GB | CPU 100 | DISK 5 GB', id: `.deposit` },
                        { title: '6Gb', description: 'RAM 6 GB | CPU 120 | DISK 6 GB', id: `.deposit` },
                        { title: '7Gb', description: 'RAM 7 GB | CPU 140 | DISK 7 GB', id: `.deposit` },
                        { title: '8Gb', description: 'RAM 8 GB | CPU 160 | DISK 7 GB', id: `.deposit` },
                        { title: '9Gb', description: 'RAM 9 GB | CPU 180 | DISK 7 GB', id: `.deposit` },
                        { title: '10Gb', description: 'RAM 10 GB | CPU 200 | DISK 8 GB', id: `.deposit` }
                    ]
                }];

                let listMessage = {
                    title: 'List Panel',
                    sections
                };

                let msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                contextInfo: {
                                    mentionedJid: [m.sender],
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: '120363204138641225@newsletter',
                                        newsletterName: 'Powered By Yori Chan',
                                        serverMessageId: -1
                                    },
                                    businessMessageForwardInfo: { businessOwnerJid: Yori.decodeJid(Yori.user.id) },
                                },
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: ownername
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: botname
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    title: `> Halo Kak ${pushname},

Selamat datang! Kami menawarkan berbagai pilihan server panel biasa yang dapat Kakak sesuaikan dengan kebutuhan.

Dan jangan lupa melakukan pembayaran terdahulu
agar di proses oleh creator saya
dan jangan lupa ketik *Prosess*

Temukan server yang paling cocok untuk Kakak dan nikmati kemudahan serta kontrol penuh. Jika ada pertanyaan atau butuh bantuan, jangan ragu untuk menghubungi owner kapan saja!`,
                                    subtitle: "",
                                    hasMediaAttachment: true,
                                    ...(await prepareWAMessageMedia({ image: fs.readFileSync('./data/image/menu.jpg') }, { upload: Yori.waUploadToServer }))
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [                                        
                                        {
                                            "name": "single_select",
                                            "buttonParamsJson": JSON.stringify(listMessage)
                                        },                 
                                    ]
                                })
                            })
                        }
                    }
                }, {});

                await Yori.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
            }
                break

            case 'saran': {
                let Yori_txt = args[0]
                if (!text) return Yorireply('🍃 *Mana Teksnya?*')
                Yorireply('🍃 *Saran Berhasil Terkirim, Terimakasih*')
                Yori.sendMessage(`${mess.owner2}@s.whatsapp.net`, { text: `📦 *Saran / Masukan*\n🎁 *Dari :* @${sender.split('@')[0]}\n📃 *Pesan :* ${q}\n\n 📣 *Saran Ini Dikirim Oleh Bot YoriChan*`, mentions: [sender] }, { quoted: m })
            }
                break

            case 'prosess': case 'proses': {
                Yorireply('*SIAP PESANAN ANDA AKAN KAMI PROSES JADI DI MOHON UNTUK MENUNGGU SEBENTAR YAH BANG*')
                Yori.sendMessage(`${mess.owner2}@s.whatsapp.net`, { text: `WAHAI PENCIPTA KU BANG EREREXID CHX ADA YANG MESEN NIH CEPETAN PROSES NANTI BUYER NGAMOK LO BANG\n ACC BANG PROSES DARI : @${sender.split('@')[0]}`, mentions: [sender] }, { quoted: m })
            }
                break

            case 'done': {
                if (!isCreator) return;
                let t = text.split(',');
                if (t.length < 2) return Yorireply(`*Format salah kak!*

Penggunaan:
${prefix + command} barang,nominal,sistem`);
                let barang = t[0];
                let nominal = t[1];
                let sistem = t[2];
                Yorireply(`*━━ TRANSAKSI BERHASIL BY EREREXID CHX ━━*

ALL TRX NO REFF

 _• *Barang:* ${barang}_
 _• *Nominal:* Rp${nominal}_
 _• *Sistem:* ${sistem}_
 _• *Nama store:* ${ownername}_
*TERIMA KASIH TELAH ORDER DI ${ownername}*\n*JANGAN LUPA ORDER LAGI YA*🙏`)
            }
                break

            case 'reportbug': {
                let Yori_txt = args[0]
                if (!text) return Yorireply('🍃 *Mana Teksnya?*')
                Yorireply('⚠️ *Report Berhasil Terkirim, Terimakasih*')
                Yori.sendMessage(`${mess.owner2}@s.whatsapp.net`, { text: `⚠️ *Report Bug*\n🎁 *Dari :* @${sender.split('@')[0]}\n📃 *Pesan :* ${q}\n\n 📣 *Laporan Ini Dikirim Oleh Bot YoriChan*`, mentions: [sender] }, { quoted: m })
            }
                break
            case 'uptime':
            case 'runtime': {
                m.reply(`ＲＵＮＴＩＭＥ ＢＯＴＺ : ${runtime(process.uptime())}
`)
            }
                break
            /*
            case 'bot': {
              {
                let eek = m.sender;
                Yori.sendMessage(m.chat, {
                  react: {
                    text: '✅', 
                    key: m.key
                  }
                });
                let pesan = `HAY KAK ${pushname} 👋
            
            𝘉𝘰𝘵 𝘕𝘢𝘮𝘦 = ${botname}
            𝘝𝘦𝘳𝘴𝘪𝘰𝘯 = 8.0
            𝘔𝘢𝘥𝘦 𝘐𝘯 = ${ownername}`;
                let msg = generateWAMessageFromContent(from, {
                  viewOnceMessage: {
                    message: {
                      messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 0x2
                      },
                      interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                          text: pesan
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                          text: "Yori Chan || 2023 - 2024\n"
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                          ...(await prepareWAMessageMedia({
                            image: fs.readFileSync('./data/image/yakak.jpg')
                          }, { upload: Yori.waUploadToServer })),
                          title: '',
                          gifPlayback: true,
                          subtitle: ownername,
                          hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                          buttons: [{
                            name: 'single_select',
                            buttonParamsJson: JSON.stringify({
                              title: "MENU",
                              sections: [{
                                title: "PILIH MENU YORI CHAN",
                                rows: [{
                                  header: "MENU",
                                  title: "Click Here!!",
                                  description: "Untuk Menampilkan Menu",
                                  id: ".menu", 
                                }, {
                                  header: "MENU SIMPLE",
                                  title: "Click Here!!",
                                  description: "Untuk Menampilkan Menu Simple",
                                  id: ".menulist", 
                                }, {
                                  header: "MENU ALL",
                                  title: "Click Here!!",
                                  description: "Untuk Menampilkan All menu",
                                  id: ".allmenu", 
                                }]
                              }]
                            })
                          }, {
                            name: 'quick_reply',
                            buttonParamsJson: JSON.stringify({
                              display_text: "HELP ⛔",
                              id: prefix + "panduan"
                            })
                          }, {
                            name: 'quick_reply',
                            buttonParamsJson: JSON.stringify({
                              display_text: "OWNER👥",
                              id: prefix + "owner"
                            })
                          }]
                        })
                      })
                    }
                  }
                }, {
                  userJid: from,
                  quoted: m
                });
                await Yori.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
              }
            }
            */
            /*
            case 'bot': {
                bot = fs.readFileSync('./mp3/helo.mp3')
                Yori.sendMessage(m.chat, { audio: fs.readFileSync('./mp3/helo.mp3'), mimetype: 'audio/mp4', ptt: true, fileLength: 88738 }, { quoted: len })
            }
            */
            case 'bot': {
    const botAudio = fs.readFileSync('./mp3/helo.mp3');
    const thumbnail = fs.readFileSync('./data/image/thumb.jpg');
    Yori.sendMessage(m.chat, {
        audio: botAudio,
        mimetype: 'audio/mp4',
        ptt: true, 
        fileLength: 88738,
        thumbnail: thumbnail,
        caption: 'Butuh bot Yori Chan?, Ketik *Menu*'
    }, { quoted: len });
}
                break

            case 'malas': case 'males': {
                if (!isCreator) return
                const t3xt = require(`./database/teks/${command}.json`)
                const r4andT3xt = t3xt[Math.floor(Math.random() * t3xt.length)]
                Yori.sendMessage(from, { text: r4andT3xt }, { quoted: m })
            }
                break

            case "assalamu'alaikum": case 'assalamualaikum': {
                Yorireply(`🍃 *Waalaikumussalam Kakakku >/<*`)
            }
                break

            case 'p': case 'pe': {
                Yorireply(`Kamu Pasti Kaum Satanic Ya kak xixixi ngeri >//<`)
            }
                break

            case 'hi': case 'hai': case 'halo': case 'hallo': case 'helo': case 'hello': case 'haii': case 'hii': case 'hlo': case 'haloo': case 'hiii': {
                Yorireply(`🍃 *Halo Juga*`)
            }
                break

            case 'anj': case 'taik': case 'anjeng': case 'anjing': case 'jing': case 'jir': case 'anjir': case 'kontol': case 'kentol': case 'kentod': case 'kontod': case 'ngentot': case 'ngontol': case 'kentod': case 'tolol': case 'bangsat': case 'bangsad': case 'emek':
            case 'kimek': case 'kimak': case 'pepek': case 'heuncut': case 'momok': case 'memek': case 'tailaso': {
                Yorireply(`Heh Ga Boleh Toxic Kak ${pushname} >/<`)
            }
                break

            case 'jedit': {
                Yorireply(`🍃 *Jasa Edit Script*\n🍃 *Malas Edit Sc? Chat Aja, 8k Udah Full Edit*\n🎁 *Chat Nomor : wa.me/923107058820*`)
            }
                break

            case '18+': {
                Yorireply(`🍃 *Haduhh Otak Mesum(¬_¬)*`)
            }
                break
            case 'yor': {
                if (!text) return Yorireply(`Ya Kak👋?, ${botname} 𝙊𝙉𝙇𝙄𝙉𝙀 𝙆𝘼𝙆\n𝙒𝙖𝙠𝙩𝙪 𝙊𝙣𝙡𝙞𝙣𝙚 : ${runtime(process.uptime())}`)
                const data1 = await fetchJson(`https://api.kiicodeit.me/ai/sindy?text=${encodeURIComponent(text)}&apikey=${global.kiiapi}`)
                const msgai = data1.result;
                reply(`${msgai}`)
            }
                break

            case 'youtube': {
                Yorireply(`*Hay Kak ${pushname}

Youtube :
https://youtube.com/@ererexidchx

Ini Adalah Link YouTube Pencipta Saya*`)
            }
                break

            case 'saluranwa': {
                Yorireply(`*Hay Kak ${pushname} 👋

Saluran WhatsApps :
https://whatsapp.com/channel/0029VaKoIaj9cDDgB6N9u232

Ini Adalah Link Saluran WhatsApps Pencipta Saya*`)
            }
                break

            case 'telegram': {
                let msgs = generateWAMessageFromContent(m.chat,
                    {
                        viewOnceMessage: {
                            message: {
                                "messageContextInfo": {
                                    "deviceListMetadata": {},
                                    "deviceListMetadataVersion": 2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: botname
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: botname
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        ...(await prepareWAMessageMedia({ image: fs.readFileSync('./data/image/menu.jpg') }, { upload: Yori.waUploadToServer })),
                                        title: `${ucapanWaktu} 👋Hay Kak ${pushname} Ini Adalah Telegram Owner saya \n Jangan lupa di Click Ya kak :) 
`,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            "name": "cta_url",
                                            "buttonParamsJson": "{\"display_text\":\"Telegram 📝\",\"url\":\"https://t.me/ErerexIDChx\",\"merchant_url\":\"https://www.google.com\"}"
                                        }],
                                    })
                                })
                            }
                        }
                    },
                    {});

                return Yori.relayMessage(m.chat,
                    msgs.message,
                    {
                        messageId: m.key.id
                    });
            }
                break

            case 'huft': {
                if (!isCreator) return
                const t3xt = require(`./database/teks/${command}.json`)
                const r4andT3xt = t3xt[Math.floor(Math.random() * t3xt.length)]
                Yori.sendMessage(from, { text: r4andT3xt }, { quoted: m })
            }
                break


            case 'rate': {
                if (!q) return Yorireply(`🍃 *Contoh: ${prefix + command} Penampilan Yori*`)
                const ra = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
                const te = ra[Math.floor(Math.random() * ra.length)]
                Yorireply(`🍃 *Rate : ${q}*\n🎁 *Jawaban : ${te}%*`)
            }
                break

            case 'apakah': {
                if (!q) return Yorireply(`🍃 *Contoh: ${prefix + command} Yori Marah*`)
                const apa = ['Iya', 'Tidak', 'Bisa Jadi', 'Betul']
                const kah = apa[Math.floor(Math.random() * apa.length)]
                Yorireply(`🍃 *Pertanyaan : Apakah ${q}*\n🎁 *Jawaban : ${kah}*`)
            }
                break

            case 'kapankah': {
                if (!q) return Yorireply(`🍃 *Contoh: ${prefix + command} Yori Marah*`)
                const kapan = ['5 Hari Lagi', '10 Hari Lagi', '15 Hari Lagi', '20 Hari Lagi', '25 Hari Lagi', '30 Hari Lagi', '35 Hari Lagi', '40 Hari Lagi', '45 Hari Lagi', '50 Hari Lagi', '55 Hari Lagi', '60 Hari Lagi', '65 Hari Lagi', '70 Hari Lagi', '75 Hari Lagi', '80 Hari Lagi', '85 Hari Lagi', '90 Hari Lagi', '95 Hari Lagi', '100 Hari Lagi', '5 Bulan Lagi', '10 Bulan Lagi', '15 Bulan Lagi', '20 Bulan Lagi', '25 Bulan Lagi', '30 Bulan Lagi', '35 Bulan Lagi', '40 Bulan Lagi', '45 Bulan Lagi', '50 Bulan Lagi', '55 Bulan Lagi', '60 Bulan Lagi', '65 Bulan Lagi', '70 Bulan Lagi', '75 Bulan Lagi', '80 Bulan Lagi', '85 Bulan Lagi', '90 Bulan Lagi', '95 Bulan Lagi', '100 Bulan Lagi', '1 Tahun Lagi', '2 Tahun Lagi', '3 Tahun Lagi', '4 Tahun Lagi', '5 Tahun Lagi', 'Besok', 'Lusa', `Abis Command Ini Juga Lu ${q}`]
                const kapankah = kapan[Math.floor(Math.random() * kapan.length)]
                Yorireply(`🍃 *Pertanyaan : Kapankah ${q}*\n🎁 *Jawaban : ${kapankah}*`)
            }
                break

            case 'bisakah': {
                if (!q) return Yorireply(`🍃 *Contoh: ${prefix + command} Yori Marah*`)
                const bisa = ['Bisa', 'Gak Bisa', 'Gak Bisa Awokawok', 'TENTU KAMU PASTI BISA!!!!']
                const ga = bisa[Math.floor(Math.random() * bisa.length)]
                Yorireply(`🍃 *Pertanyaan : Bisakah ${q}*\n🎁 *Jawaban : ${ga}*`)
            }
                break

            case 'bagaimanakah': {
                if (!q) return Yorireply(`🍃 *Contoh: ${prefix + command} Yori Marah*`)
                const gimana = ['Ya Begitulah', 'Gak Normal', 'Maaf Bot Tidak Bisa Menjawab', 'Coba Deh Cari Di Gugel', 'Kayaknya Lanjut Part 2', 'Kepo Kamu', 'Gimana Aja']
                const ya = gimana[Math.floor(Math.random() * gimana.length)]
                Yorireply(`🍃 *Pertanyaan : Bagaimanakah ${q}*\n🎁 *Jawaban : ${ya}*`)
            }
                break

            case 'gantengcek': case 'cekganteng': {
                if (!q) return Yorireply(`🍃 *Contoh: ${prefix + command} Yori*`)
                const gan = ['Normal', 'Ganteng Njir', 'Ganteng Amat Bang', 'Jaga Penampilan Ya', 'Kurang :c', 'Lumayan', 'Boleh Juga']
                const teng = gan[Math.floor(Math.random() * gan.length)]
                Yorireply(`🍃 *Nama ${q}*\n🎁 *Jawaban : ${teng}*`)
            }
                break

            case 'cantikcek': case 'cekcantik': {
                if (!q) return Yorireply(`🍃 *Contoh: ${prefix + command} Yori Cantik*`)
                const can = ['Normal', 'Cantik Njir', 'Cantik Amat Sih', 'Jaga Penampilan Ya', 'Kurang :c', 'Lumayan', 'Boleh Juga']
                const tik = can[Math.floor(Math.random() * can.length)]
                Yorireply(`🍃 *Nama ${q}*\n🎁 *Jawaban : ${tik}*`)
            }
                break

            case 'cekkontol': {
                if (!text) return Yorireply('Nama nya mana yang mau di cek kontol nya')
                function pickRandom(list) {
                    return list[Math.floor(Math.random() * list.length)]
                }


                Yorireply(`
╭━━━━°「 *Kontol ${text}* 」°
┃
┊• Nama : ${text}
┃• Kontol : ${pickRandom(['ih item', 'Belang wkwk', 'Muluss', 'Putih Mulus', 'Black Doff', 'Pink wow', 'Item Glossy'])}
┊• Tipe : ${pickRandom(['perjaka', 'ga perjaka', 'udah pernah dimasukin', 'masih ori', 'jumbo'])}
┃• jembut : ${pickRandom(['lebat', 'ada sedikit', 'gada jembut', 'tipis', 'muluss'])}
┃• ukuran : ${pickRandom(['1cm', '2cm', '3cm', '4cm', '5cm', '20cm', '45cm', '50cm', '90meter', '150meter', '5km', 'gak normal'])}
╰═┅═━––––––๑`)
            }
                break
            case 'cekkhodam': {
                if (!text) return Yorireply('Nama nya mana yang mau di cek khodam nya')
                function pickRandom(list) {
                    return list[Math.floor(Math.random() * list.length)]
                }
                Yorireply(`
╭━━━━°「 *Khodam ${text}* 」°
┃
┊• Nama : ${text}
┊• Khodam : ${pickRandom(['Macan Tutul', 'Gajah Sumatera', 'Orangutan', 'Harimau Putih', 'Badak Jawa', 'Pocong', 'Kuntilanak', 'Genderuwo', 'Wewe Gombel', 'Kuyang', 'Lembuswana', 'Anoa', 'Komodo', 'Elang Jawa', 'Burung Cendrawasih', 'Tuyul', 'Babi Ngepet', 'Sundel Bolong', 'Jenglot', 'Lele Sangkuriang', 'Kucing Hutan', 'Ayam Cemani', 'Cicak', 'Burung Merak', 'Kuda Lumping', 'Buaya Muara', 'Banteng Jawa', 'Monyet Ekor Panjang', 'Tarsius', 'Cenderawasih Biru', 'Setan Merah', 'Kolor Ijo', 'Palasik', 'Nyi Roro Kidul', 'Siluman Ular', 'Kelabang', 'Beruang Madu', 'Serigala', 'Hiu Karang', 'Rajawali', 'Lutung Kasarung', 'Kuda Sumba', 'Ikan Arwana', 'Jalak Bali', 'Kambing Etawa', 'Kelelawar', 'Burung Hantu', 'Ikan Cupang'])}
┊• Mendampingi dari : ${pickRandom(['1 tahun lalu', '2 tahun lalu', '3 tahun lalu', '4 tahun lalu', 'dari lahir'])}
┃• Expired : ${pickRandom(['2024', '2025', '2026', '2027', '2028', '2029', '2030', '2031', '2032', '2033', '2034', '2035'])}
╰═┅═━––––––๑`)
            }
                break

            case 'cekmemek': {
                if (!text) return Yorireply('Nama nya mana yang mau di cek memek nya')
                function pickRandom(list) {
                    return list[Math.floor(Math.random() * list.length)]
                }


                Yorireply(`
╭━━━━°「 *Memek ${text}* 」°
┃
┊• Nama : ${text}
┃• Memek : ${pickRandom(['ih item', 'Belang wkwk', 'Muluss', 'Putih Mulus', 'Pink Banget', 'Black Doff', 'Pink wow', 'Item Glossy'])}
┊• Tipe : ${pickRandom(['Perawan', 'ga perawan', 'udah pernah dimasukin', 'Tembem', 'masih ori', 'jumbo'])}
┃• jembut : ${pickRandom(['lebat', 'ada sedikit', 'gada jembut', 'tipis', 'muluss'])}
┃• Tipe ukuran : ${pickRandom(['Sempit', 'Lumayan Sempit', 'Longgar', 'Lumayan longgar', 'Bolong', 'Bolong gede anjir', 'Pucuknya Kendor', 'Kendor', 'Lumayan kendor', 'Sempurna Bejir', 'Lumayan Sempurna', 'Sempurna Bau Keperawanannya', 'gak normal'])}
╰═┅═━––––––๑`)
            }
                break

            case "kudeta": {
                if (!isGroup) return Yorireply(mess.group)
                if (!isAdmins) return Yorireply(mess.admin)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                Yorireply('*TERKUDETLAH GROUP INI HAHA🗿*')
                let data = participants.map((o) => o.id)
                for (let o of data) {
                    if (o !== botNumber && o !== groupOwner && o !== global.owner) {
                        Yori.groupParticipantsUpdate(m.chat, [o], "remove")
                    } else if (data.includes(groupOwner)) {
                        setTimeout(() => {
                            Yori.groupParticipantsUpdate(m.chat, [groupOwner], "remove")
                        }, 1)
                        Yori.groupParticipantsUpdate(m.chat, [groupOwner], "demote")
                    }
                }
            }
                break

            case 'sangecek': case 'ceksange': case 'gaycek': case 'cekgay': case 'lesbicek': case 'ceklesbi': {
                if (!q) return Yorireply(`🍃 *Contoh: ${prefix + command} Yori*`)
                const sangeh = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
                const sange = sangeh[Math.floor(Math.random() * sangeh.length)]
                Yorireply(`🍃 *Nama : ${q}*\n🎁 *Jawaban : ${sange}%*`)
            }
                break



            case 'createqr': {
                if (!isCreator) return Yorireply(mess.owner)
                YoriLD()
                const qrcode = require('qrcode')
                if (!text) return Yorireply(`Penggunaan Salah Harusnya ${prefix + command} Nakano`)
                const qyuer = await qrcode.toDataURL(text, { scale: 8 })
                let data = new Buffer.from(qyuer.replace('data:image/png;base64,', ''), 'base64')
                Yori.sendMessage(from, { image: data, caption: `Sukses Kak` }, { quoted: m })
            }
                break
            case 'detectqr': {
                if (!isCreator) return Yorireply(mess.owner)
                YoriLD()
                try {
                    mee = await Yori.downloadAndSaveMediaMessage(quoted)
                    mem = await uptotelegra(mee)
                    const res = await fetch(`http://api.qrserver.com/v1/read-qr-code/?fileurl=${mem}`)
                    const data = await res.json()
                    Yorireply(util.format(data[0]))
                } catch (err) {
                    Yorireply(`NakanoReply Image Yang Ada Qr Nya`)
                }
            }
                break

            case 'cekidgc': {
                if (!isCreator) return Yorireply(mess.owner)
                Yorireply('🍃 *Sabar Yaa*')
                let getGroups = await Yori.groupFetchAllParticipating()
                let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
                let anu = groups.map((v) => v.id)
                let teks = `🍃 *List Grup Yang Dimasuki Bot YoriChan*\n🎁 *Total Group : ${anu.length} Group*\n\n`
                for (let x of anu) {
                    let metadata2 = await Yori.groupMetadata(x)
                    teks += `🍃 *Nama Group : ${metadata2.subject}*\n🎁 *ID Group : ${metadata2.id}*\n📦 *Total Member Group : ${metadata2.participants.length}*\n\n────────────────────────\n\n`
                }
                Yorireply(teks + `🍃 *Cara Penggunaan : Pushkontak ID Group|Teks*\n🎁 *Contoh : Pushkontak ID Group|Save YoriChan*`)
            }
                break
            case 'push':
            case 'pushkontak': {
                if (!isCreator) return Yorireply(mess.owner)
                if (m.isGroup) return Yorireply(mess.private)
                if (!text) return Yorireply(`🍃 *Contoh : Pushkontak ID Group|Teks*\n🎁 *Untuk Mengetahui Id Group Ketik : Cekidgc*`)
                global.idgcns = text.split("|")[0]
                global.tekspushkon = text.split("|")[1]
                const groupMetadataa = !m.isGroup ? await Yori.groupMetadata(global.idgcns).catch(e => { }) : ""
                const participants = !m.isGroup ? await groupMetadataa.participants : ""
                const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
                if (isContacts) return
                for (let mem of halls) {
                    contacts.push(mem)
                    fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
                    if (/image/.test(mime)) {
                        media = await Yori.downloadAndSaveMediaMessage(quoted)
                        memk = await uptotelegra(media)
                        await Yori.sendMessage(mem, { image: { url: memk }, caption: global.tekspushkon })
                        await sleep(2000)
                    } else {
                        await Yori.sendMessage(mem, { text: global.tekspushkon })
                        await sleep(2000)
                    }
                }
                Yori.sendMessage("62895342022385@s.whatsapp.net", { text: `🍃 *Selesai*` })
            }
                break
            case 'push2':
            case 'pushkontak2': {
                if (!isCreator) return Yorireply(mess.owner)
                if (!m.isGroup) return Yorireply(mess.group)
                if (!text) return Yorireply(`🍃 *Contoh : Pushkontak2 ID Group|Teks*\n🎁 *Untuk Mengetahui Id Group Ketik : Cekidgc*`)
                global.tekspushkonv2 = text
                const groupMetadata = m.isGroup ? await Yori.groupMetadata(from).catch(e => { }) : ""
                const participantts = m.isGroup ? await groupMetadata.participants : ""
                const halsss = await participantts.filter(v => v.id.endsWith('.net')).map(v => v.id)
                if (isContacts) return
                for (let men of halsss) {
                    contacts.push(men)
                    fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
                    if (/image/.test(mime)) {
                        media = await Yori.downloadAndSaveMediaMessage(quoted)
                        mem = await uptotelegra(media)
                        await Yori.sendMessage(men, { image: { url: mem }, caption: global.tekspushkonv2 })
                        await sleep(3000)
                    } else {
                        await Yori.sendMessage(men, { text: global.tekspushkonv2 })
                        await sleep(3000)
                    }
                }
                Yori.sendMessage("62895342022385@s.whatsapp.net", { text: `🍃 *Selesai*` })
            }
                break
            case 'savekontak': {
                if (!isCreator) return Yorireply(mess.owner)
                Yorireply(mess.wait)
                try {
                    const uniqueContacts = [...new Set(contacts)];
                    const vcardContent = uniqueContacts.map((contact, index) => {
                        const vcard = [
                            "BEGIN:VCARD",
                            "VERSION:3.0",
                            `FN:WA [${index}] ${contact.split("@")[0]}`,
                            `TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
                            "END:VCARD",
                            "",].join("\n");
                        return vcard;
                    }).join("");
                    fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8");
                } catch (err) {
                    Yorireply(util.format(err))
                } finally {
                    await Yori.sendMessage(from, { document: fs.readFileSync("./database/contacts.vcf"), fileName: "contacts.vcf", caption: "🍃 *Selesai*", mimetype: "text/vcard", }, { quoted: m })
                    contacts.splice(0, contacts.length)
                    fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
                }
            }
                break
            case 'mode': {
                let msg = generateWAMessageFromContent(from, {
                    viewOnceMessage: {
                        message: {
                            "messageContextInfo": {
                                "deviceListMetadata": {},
                                "deviceListMetadataVersion": 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: botname
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: botname
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    ...(await prepareWAMessageMedia({ image: fs.readFileSync('./data/image/menu.jpg') }, { upload: Yori.waUploadToServer })),
                                    title: `Harap Di Pilih Tuan ${ownername}`,
                                    gifPlayback: true,
                                    subtitle: ownername,
                                    hasMediaAttachment: false
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"Publick","id":".public"}`
                                        },
                                        {
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"Self","id":".self"}`
                                        },
                                    ],
                                }),
                                contextInfo: {
                                    mentionedJid: [m.sender],
                                    forwardingScore: 999,
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: '120363204138641225@newsletter',
                                        newsletterName: botname,
                                        serverMessageId: 143
                                    }
                                }
                            })
                        }
                    }
                }, {})

                await Yori.relayMessage(msg.key.remoteJid, msg.message, {
                    messageId: msg.key.id
                })
            }
                break

            case 'public': {
                if (!isCreator) return Yorireply(mess.owner)
                Yori.public = true
                Yorireply('Sukses NgePublick Yori Chan')
            }
                break

            case 'self': {
                if (!isCreator) return Yorireply(mess.owner)
                Yori.public = false
                Yorireply('Sukses Hanya Owner Di aktifkan')
            }
                break

            case 'enc': {
                if (!isCreator) return Yorireply(mess.owner)
                if (!q) return Yorireply(`Contoh ${prefix + command} const adrian = require('adrian-api')`)
                let meg = await obfus(q)
                Yorireply(`${meg.result}`)
            }
                break

            case 'addprem':
                if (!isCreator) return
                if (!args[0]) return Yorireply(`🍃 *mana Nomornya?`)
                bnnd = text.split("|")[0].replace(/[^0-9]/g, '')
                let ceknye = await Yori.onWhatsApp(bnnd + `@s.whatsapp.net`)
                if (ceknye.length == 0) return Yorireply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
                owner.push(bnnd)
                fs.writeFileSync('./premium.json', JSON.stringify(owner))
                Yorireply(`Nomor ${bnnd} Menjadi Premium!!!`)
                break

            case 'done1': {
                if (!isCreator) return;
                if (!text) return Yorireply(example("barang,harga\n\n*Contoh :* Nomor Kosong Country Zimbabwe,2"));
                const [barang, harga] = text.split(",");
                if (!barang || !harga) return Yorireply(example("barang,harga\n\n*Contoh :* Nomor Kosong Country Zimbabwe,2"));
                if (isNaN(harga)) return Yorireply("Format Harga Tidak Valid");

                var total = `${harga}000000`;
                var total2 = Number(`${harga}000`);
                const formattedHarga = total2.toLocaleString('id-ID', { style: 'currency', currency: 'IDR' });

                const teks = `*TRANSAKSI DONE BY ${ownername} ✅*

*📦 Barang :* ${barang}
*💸 Nominal :* ${formattedHarga}
*⏰ Waktu :* ${new Date().toLocaleTimeString()}

_*Terimakasih Sudah Mempercayai & Menggunakan Jasa ${botname}, Jika 5 Menit Tidak Bilang Done, Maka Akan Kami Anggap Done 😊*_`;

                Yori.relayMessage(m.chat, {
                    requestPaymentMessage: {
                        currencyCodeIso4217: 'IDR',
                        amount1000: Number(total),
                        requestFrom: m.sender,
                        noteMessage: {
                            extendedTextMessage: {
                                text: `${teks}`,
                                contextInfo: { externalAdReply: { showAdAttribution: true } }
                            }
                        }
                    }
                }, {});
            }
                break

            case 'delprem':
                if (!isCreator) return
                if (!args[0]) return Yorireply(`Penggunaan ${prefix + command} nomor\nContoh ${prefix + command} 923107058820`)
                yaki = text.split("|")[0].replace(/[^0-9]/g, '')
                unp = owner.indexOf(yaki)
                owner.splice(unp, 1)
                fs.writeFileSync('./premium.json', JSON.stringify(owner))
                Yorireply(`Nomor ${yaki} Telah Di Hapus Dari Premium!!!`)
                break

            case 'listprem':
                teksooo = '📦 *List Premium*\n'
                for (let i of owner) {
                    teksooo += `✉️ ${i}\n`
                }
                teksooo += `\n📑 *Total : ${owner.length}*`
                Yori.sendMessage(from, { text: teksooo.trim() }, 'extendedTextMessage', { quoted: m, contextInfo: { "mentionedJid": owner } })
                break

            case 'ban': {
                if (!isCreator) return Yorireply(mess.owner)
                if (!args[0]) return Yorireply(`*Contoh : ${command} add 923107058820*`)
                if (args[1]) {
                    orgnye = args[1] + "@s.whatsapp.net"
                } else if (m.quoted) {
                    orgnye = m.quoted.sender
                }
                const isBane = banned.includes(orgnye)
                if (args[0] === "add") {
                    if (isBane) return Yorireply('*Pengguna Ini telah Di Ban*')
                    banned.push(orgnye)
                    Yorireply(`Succes ban Pengguna Ini`)
                } else if (args[0] === "del") {
                    if (!isBane) return Yorireply('*Pengguna Ini Telah Di hapus Dari Ban*')
                    let delbans = banned.indexOf(orgnye)
                    banned.splice(delbans, 1)
                    Yorireply(`*Berhasil Menghapus Pengguna yang Di Ban*`)
                } else {
                    Yorireply("Error")
                }
            }
                break

            case 'listban':
                if (isBan) return Yorireply('*Lu Di Ban Owner*')
                teksooop = `📦 *List Ban*\n`
                for (let ii of banned) {
                    teksooop += `   ⨠  ${ii}\n`
                }
                Yorireply(teksooop)
                break
/*
            case 'owner': case 'creator': case 'pencipta': {
                await Yori.sendContact(m.chat, author.map(i => i.split("@")[0]), m)
                await Yori.sendMessage(m.chat, { audio: fs.readFileSync('./mp3/owner.mp3'), mimetype: 'audio/mp4', ptt: true, fileLength: 88738 }, { quoted: len })
            }
            */
            case 'owner': 
             case 'creator': 
              case 'pencipta': {
    const thumbnailUrl = 'https://widipe.com/file/0HQZhLl1BfCf.jpg'; 
    // Tampilkan kontak owner dengan informasi yang keren
    await Yori.sendContact(m.chat, author.map(i => i.split("@")[0]), m)
    await Yori.sendMessage(m.chat, { 
        text: `Konniciwa @${m.sender.split("@")[0]}! Berikut adalah kontak dari pencipta bot ini:

┏━━━❐  𝑶𝒘𝒏𝒆𝒓  ❐━━━┓
┃⭔ *Nama:* ${ownername}
┃⭔ *Nomor:* wa.me/${author[0].split('@')[0]}
┃⭔ *Status:* ⚙️ Developer Bot
┗━━━━━━━━━━━━━━━━━┛

Silakan hubungi owner untuk pertanyaan lebih lanjut atau kerjasama.`,
        contextInfo: {
            externalAdReply: {
                title: 'Creator Bot',
                body: `${ownername} - Developer Bot`,
                thumbnailUrl: thumbnailUrl,
                sourceUrl: 'https://wa.me/923107058820' + author[0].split('@')[0], // Link menuju chat langsung dengan owner
                showAdAttribution: true,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
    await Yori.sendMessage(m.chat, { 
        audio: fs.readFileSync('./mp3/owner.mp3'), 
        mimetype: 'audio/mp4', 
        ptt: true, 
        fileLength: 88738 
    }, { quoted: m });
}
                break

            case 'verif@': case 'kenon': {
                if (!isCreator) return
                if (m.quoted || q) {
                    var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                    if (tosend === global.owner) return Yorireply(`Tidak bisa verif My Creator!`)
                    var targetnya = tosend.split('@')[0]

                    try {
                        var axioss = require('axios')
                        let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
                        let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
                        let cookie = ntah.headers["set-cookie"].join("; ")
                        const cheerio = require('cheerio');
                        let $ = cheerio.load(ntah.data)
                        let $form = $("form");
                        let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
                        let form = new URLSearchParams()
                        form.append("jazoest", $form.find("input[name=jazoest]").val())
                        form.append("lsd", $form.find("input[name=lsd]").val())
                        form.append("step", "submit")
                        form.append("country_selector", "+")
                        form.append("phone_number", `+${targetnya}`,)
                        form.append("email", email.data[0])
                        form.append("email_confirm", email.data[0])
                        form.append("platform", "ANDROID")
                        form.append("your_message", `Perdido/roubado: desative minha conta`)
                        form.append("__user", "0")
                        form.append("__a", "1")
                        form.append("__csr", "")
                        form.append("__req", "8")
                        form.append("__hs", "19574.BP:whatsapp_www_pkg.2.0.0.0.0")
                        form.append("dpr", "1")
                        form.append("__ccg", "UNKNOWN")
                        form.append("__rev", "1007982238")
                        form.append("__comment_req", "0")

                        let res = await axioss({
                            url,
                            method: "POST",
                            data: form,
                            headers: {
                                cookie
                            }

                        })
                        let payload = String(res.data)
                        if (payload.includes(`"payload":true`)) {
                            Yorireply(`##- WhatsApp Support -##

Hai,

 Terima kasih atas pesan Anda.

 Kami telah menonaktifkan akun WhatsApp Anda.  Ini berarti akun Anda telah di keluarkan maka untuk sementara dinonaktifkan dan akan dihapus secara otomatis dalam 30 hari jika Anda tidak mendaftarkan ulang akun tersebut.  Harap dicatat: Tim Dukungan Pelanggan WhatsApp tidak dapat menghapus akun Anda secara manual.

 Selama periode penonaktifan:

 • Kontak Anda di WhatsApp mungkin masih melihat nama dan gambar profil Anda.
 • Setiap pesan yang mungkin dikirim oleh kontak Anda ke

 akun akan tetap dalam status tertunda hingga 30 hari.

 Jika Anda ingin mendapatkan kembali akun Anda, daftarkan ulang akun Anda sebagai

 secepatnya.  Daftar ulang akun Anda dengan memasukkan 6 digit

 kode yang Anda terima melalui SMS atau panggilan telepon.  Jika Anda mendaftar ulang

 pulihkan riwayat obrolan Anda di: Android |  iPhone.

 file, cadangan, atau riwayat panggilan dari akun yang dihapus.

 akun sebelum dihapus, Anda akan tetap berada di semua obrolan grup.  Anda akan memiliki opsi untuk memulihkan data Anda.  Pelajari caranya Jika Anda tidak mendaftarkan ulang akun Anda, akun tersebut mungkin akan dihapus dan proses ini tidak dapat dibatalkan.  Sayangnya, WhatsApp tidak dapat membantu Anda memulihkan obrolan, dokumen, media

 Catatan: Jika perangkat Anda hilang atau dicuri, sebaiknya hubungi penyedia seluler Anda untuk memblokir kartu SIM Anda sesegera mungkin.  Memblokir kartu SIM Anda mencegah orang lain mendaftar dan mengakses akun yang terkait dengan kartu SIM.

 Sumber daya terkait:

 ⚫ Untuk informasi lebih lanjut tentang penonaktifan akun pada ponsel yang hilang dan dicuri, silakan baca artikel ini.

 ⚫ Pelajari tentang akun yang dicuri di artikel ini.

 Jika Anda memiliki pertanyaan atau masalah lain, jangan ragu untuk menghubungi kami.  Kami akan dengan senang hati membantu!`)
                        } else if (payload.includes(`"payload":false`)) {
                            Yorireply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
                        } else Yorireply(util.format(res.data))
                    } catch (err) { Yorireply(`${err}`) }
                } else Yorireply('Masukkan nomor target!')
            }
                break

            case 'banned': {
                if (!isCreator) return
                if (m.quoted || q) {
                    var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                    if (tosend === global.owner) return Yorireply(`Tidak bisa verif My Creator!`)
                    var targetnya = tosend.split('@')[0]

                    try {
                        var axioss = require('axios')
                        let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
                        let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
                        let cookie = ntah.headers["set-cookie"].join("; ")
                        const cheerio = require('cheerio');
                        let $ = cheerio.load(ntah.data)
                        let $form = $("form");
                        let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
                        let form = new URLSearchParams()
                        form.append("jazoest", $form.find("input[name=jazoest]").val())
                        form.append("lsd", $form.find("input[name=lsd]").val())
                        form.append("step", "submit")
                        form.append("country_selector", "+")
                        form.append("phone_number", `+${targetnya}`,)
                        form.append("email", email.data[0])
                        form.append("email_confirm", email.data[0])
                        form.append("platform", "ANDROID")
                        form.append("your_message", `I noticed that a user was using modified whatsapp, so i ask support to ban this account for violating terms of service, and the account uses a WhatsApp bot that can send malicious messages so that other users' WhatsApp cannot work
Number : +${targetnya}`)
                        form.append("__user", "0")
                        form.append("__a", "1")
                        form.append("__csr", "")
                        form.append("__req", "8")
                        form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
                        form.append("dpr", "1")
                        form.append("__ccg", "UNKNOWN")
                        form.append("__rev", "1007965968")
                        form.append("__comment_req", "0")

                        let res = await axioss({
                            url,
                            method: "POST",
                            data: form,
                            headers: {
                                cookie
                            }

                        })
                        Yorireply(`Wait 1-24 Jam an untuk proses banned dari bot dan tunggu ±30 Detik an untuk melihat balasan email dari WhatsApp :3`)
                        await YoriLD(180000)
                        let payload = String(res.data)
                        if (payload.includes(`"payload":true`)) {
                            Yorireply(`##- WhatsApp Support -##

Sepertinya Anda menggunakan atau mengajukan pertanyaan mengenai versi WhatsApp yang tidak resmi.

Untuk memastikan Anda memiliki akses ke WhatsApp, verifikasi ulang nomor telepon Anda menggunakan aplikasi resmi kami yang dapat diunduh dari situs web kami: www.whatsapp.com/download

Aplikasi tidak resmi membahayakan keamanan dan keselamatan Anda, dan kami tidak mendukungnya.

Berikut yang mungkin terjadi jika Anda menggunakannya:

Tidak ada jaminan bahwa pesan atau data Anda seperti lokasi Anda atau file yang Anda bagikan akan bersifat privat dan aman.

Akun mungkin akan diblokir karena penggunaan aplikasi WhatsApp yang tidak resmi bertentangan dengan Ketentuan Layanan kami.

Berikut adalah ketentuan layanan WhatsApp:

Ketentuan Layanan WhatsApp

1. Penggunaan Aplikasi

Anda setuju untuk menggunakan aplikasi WhatsApp ("Aplikasi") hanya untuk tujuan yang sah dan sesuai dengan hukum yang berlaku. Anda tidak diizinkan untuk menggunakan Aplikasi untuk tujuan ilegal atau melanggar hak-hak pihak ketiga. Anda juga setuju untuk tidak menggunakan Aplikasi untuk mengirimkan, menerima, atau menyimpan informasi yang melanggar hukum atau melanggar hak-hak pihak ketiga.

2. Hak Cipta dan Merek Dagang

Anda setuju bahwa semua hak cipta, merek dagang, dan hak milik lainnya yang terkait dengan Aplikasi adalah milik WhatsApp, Inc. dan/atau afiliasinya. Anda tidak diizinkan untuk menggunakan atau memodifikasi hak cipta, merek dagang, atau hak milik lainnya tanpa izin tertulis dari WhatsApp, Inc. atau afiliasinya.

3. Privasi dan Keamanan Data
WhatsApp berjanji untuk melindungi privasi dan keamanan data Anda. Kami akan memproses data Anda sesuai dengan Kebijakan Privasi kami yang dapat diakses di https://www.whatsapp.com/legal/#privacy-policy. Dengan menggunakan Aplikasi, Anda setuju dengan Kebijakan Privasi kami dan memberikan persetujuan Anda untuk memproses data Anda sesuai dengan Kebijakan Privasi kami. 

4. Pembatasan Tanggung Jawab 
WhatsApp tidak bertanggung jawab atas kerugian apapun yang disebabkan oleh penggunaan Aplikasi oleh Anda atau pihak ketiga lainnya, termasuk namun tidak terbatas pada kerugian yang disebabkan oleh kegagalan teknis atau kerusakan peralatan, kehilangan data, kerusakan properti, atau kerugian finansial lainnya. 

5. Perubahan Ketentuan Layanan 
WhatsApp berhak untuk mengubah Ketentuan Layanan ini sewaktu-waktu tanpa pemberitahuan sebelumnya. Dengan melanjutkan penggunaan Aplikasi setelah perubahan Ketentuan Layanan ini berlaku, Anda setuju untuk terikat oleh versi terbaru dari Ketentuan Layanan ini.`)
                        } else if (payload.includes(`"payload":false`)) {
                            Yorireply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
                        } else Yorireply(util.format(res.data))
                    } catch (err) { Yorireply(`${err}`) }
                } else Yorireply('Masukkan nomor target!')
            }
                break

            case 'unbanned': {
                if (!isCreator) return
                if (m.quoted || q) {
                    var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                    if (tosend === global.owner) return Yorireply(`Tidak bisa verif My Creator!`)
                    var targetnya = tosend.split('@')[0]

                    try {
                        var axioss = require('axios')
                        let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
                        let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
                        let cookie = ntah.headers["set-cookie"].join("; ")
                        const cheerio = require('cheerio');
                        let $ = cheerio.load(ntah.data)
                        let $form = $("form");
                        let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
                        let form = new URLSearchParams()
                        form.append("jazoest", $form.find("input[name=jazoest]").val())
                        form.append("lsd", $form.find("input[name=lsd]").val())
                        form.append("step", "submit")
                        form.append("country_selector", "+")
                        form.append("phone_number", `+${targetnya}`,)
                        form.append("email", email.data[0])
                        form.append("email_confirm", email.data[0])
                        form.append("platform", "ANDROID")
                        form.append("your_message", `Aku Tidak Tau Mengapa Nomor Saya Tiba Tiba Di Larang Dari Menggunakan WhatsApp Aku Hanya Membalas Pesan Customer Saya Mohon Buka Larangan Akun WhatsApp Saya: [+${targetnya}]
Terimakasih`)
                        form.append("__user", "0")
                        form.append("__a", "1")
                        form.append("__csr", "")
                        form.append("__req", "8")
                        form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
                        form.append("dpr", "1")
                        form.append("__ccg", "UNKNOWN")
                        form.append("__rev", "1007965968")
                        form.append("__comment_req", "0")

                        let res = await axioss({
                            url,
                            method: "POST",
                            data: form,
                            headers: {
                                cookie
                            }

                        })
                        Yorireply(`Wait 1-24 Jam an untuk proses unbanned dari bot dan tunggu ±30 Detik an untuk melihat balasan email dari WhatsApp :3`)
                        await YoriLD(90000)
                        let payload = String(res.data)
                        if (payload.includes(`"payload":true`)) {
                            Yorireply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
                        } else if (payload.includes(`"payload":false`)) {
                            Yorireply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
                        } else Yorireply(util.format(res.data))
                    } catch (err) { Yorireply(`${err}`) }
                } else Yorireply('Masukkan nomor target!')
            }
                break

            case 'unbannedv2': {
                if (!isCreator) return
                if (m.quoted || q) {
                    var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                    if (tosend === global.owner) return Yorireply(`Tidak bisa verif My Creator!`)
                    var targetnya = tosend.split('@')[0]

                    try {
                        var axioss = require('axios')
                        let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
                        let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
                        let cookie = ntah.headers["set-cookie"].join("; ")
                        const cheerio = require('cheerio');
                        let $ = cheerio.load(ntah.data)
                        let $form = $("form");
                        let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
                        let form = new URLSearchParams()
                        form.append("jazoest", $form.find("input[name=jazoest]").val())
                        form.append("lsd", $form.find("input[name=lsd]").val())
                        form.append("step", "submit")
                        form.append("country_selector", "+")
                        form.append("phone_number", `+${targetnya}`,)
                        form.append("email", email.data[0])
                        form.append("email_confirm", email.data[0])
                        form.append("platform", "ANDROID")
                        form.append("your_message", `Pihak WhatsApp yang terhormat mohon bantuan anda segera
[${targetnya}]
Saya telah mengirim beberapa email dan laporan ke pihak WhatsApp untuk mengajukan banding agar nomor saya cepat di buka dari daftar blokir, saya sangat membutuhkan untuk keperluan pribadi berkomunikasi dengan keluarga jika saya melakukan pelanggaran sebelumnya maka saya akan menggunakan nomor saya tersebut dengan lebih hati-hati dan lebih baik lagi dari sebelumnya dan saya sekarang telah menuruti apa yang pihak WhatsApp sarankan, dan saya sangat berharap sekarang juga nomor saya dapat di gunakan kembali. Terimakasih`)
                        form.append("__user", "0")
                        form.append("__a", "1")
                        form.append("__csr", "")
                        form.append("__req", "8")
                        form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
                        form.append("dpr", "1")
                        form.append("__ccg", "UNKNOWN")
                        form.append("__rev", "1007965968")
                        form.append("__comment_req", "0")

                        let res = await axioss({
                            url,
                            method: "POST",
                            data: form,
                            headers: {
                                cookie
                            }

                        })
                        Yorireply(`Wait 1-24 Jam an untuk proses unbanned dari bot dan tunggu ±30 Detik an untuk melihat balasan email dari WhatsApp :3`)
                        await YoriLD(90000)
                        let payload = String(res.data)
                        if (payload.includes(`"payload":true`)) {
                            Yorireply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
                        } else if (payload.includes(`"payload":false`)) {
                            Yorireply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
                        } else Yorireply(util.format(res.data))
                    } catch (err) { Yorireply(`${err}`) }
                } else Yorireply('Masukkan nomor target!')
            }
                break

            case 'unbannedv3': {
                if (!isCreator) return
                if (m.quoted || q) {
                    var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                    if (tosend === global.owner) return Yorireply(`Tidak bisa verif My Creator!`)
                    var targetnya = tosend.split('@')[0]

                    try {
                        var axioss = require('axios')
                        let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
                        let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
                        let cookie = ntah.headers["set-cookie"].join("; ")
                        const cheerio = require('cheerio');
                        let $ = cheerio.load(ntah.data)
                        let $form = $("form");
                        let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
                        let form = new URLSearchParams()
                        form.append("jazoest", $form.find("input[name=jazoest]").val())
                        form.append("lsd", $form.find("input[name=lsd]").val())
                        form.append("step", "submit")
                        form.append("country_selector", "+")
                        form.append("phone_number", `+${targetnya}`,)
                        form.append("email", email.data[0])
                        form.append("email_confirm", email.data[0])
                        form.append("platform", "ANDROID")
                        form.append("your_message", `Hola WhatsApp
Actualmente, algunas personas tienen muchas formas efectivas de bloquear números de usuario e informarlos sin ningún motivo, de hecho, conozco bien los términos de servicio y los cumplí, pero algunos piratas informáticos me hicieron un informe falso y mi número fue bloqueado, desbloquee el número ${targetnya}`)
                        form.append("__user", "0")
                        form.append("__a", "1")
                        form.append("__csr", "")
                        form.append("__req", "8")
                        form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
                        form.append("dpr", "1")
                        form.append("__ccg", "UNKNOWN")
                        form.append("__rev", "1007965968")
                        form.append("__comment_req", "0")

                        let res = await axioss({
                            url,
                            method: "POST",
                            data: form,
                            headers: {
                                cookie
                            }

                        })
                        Yorireply(`Wait 1-24 Jam an untuk proses unbanned dari bot dan tunggu ±30 Detik an untuk melihat balasan email dari WhatsApp :3`)
                        await YoriLD(90000)
                        let payload = String(res.data)
                        if (payload.includes(`"payload":true`)) {
                            Yorireply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
                        } else if (payload.includes(`"payload":false`)) {
                            Yorireply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
                        } else Yorireply(util.format(res.data))
                    } catch (err) { Yorireply(`${err}`) }
                } else Yorireply('Masukkan nomor target!')
            }
                break

            case 'unbannedv4': {
                if (!isCreator) return
                if (m.quoted || q) {
                    var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                    if (tosend === global.owner) return Yorireply(`Tidak bisa verif My Creator!`)
                    var targetnya = tosend.split('@')[0]

                    try {
                        var axioss = require('axios')
                        let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
                        let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
                        let cookie = ntah.headers["set-cookie"].join("; ")
                        const cheerio = require('cheerio');
                        let $ = cheerio.load(ntah.data)
                        let $form = $("form");
                        let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
                        let form = new URLSearchParams()
                        form.append("jazoest", $form.find("input[name=jazoest]").val())
                        form.append("lsd", $form.find("input[name=lsd]").val())
                        form.append("step", "submit")
                        form.append("country_selector", "+")
                        form.append("phone_number", `+${targetnya}`,)
                        form.append("email", email.data[0])
                        form.append("email_confirm", email.data[0])
                        form.append("platform", "ANDROID")
                        form.append("your_message", `Good day whatsApp team. My whatApp account has been burned permanently, please i plead with you unblock it, i cannot use another number again. I don’t know why it is burned but my friends re suggesting its because i use GB whatsApp, which i didn’t know it was wrong. My number is [ ${targetnya} ]. Please whatsApp team, help me unblock my account. please i cannot use a new number as my current number is connected to slot of important things like vacancies.
Thank you`)
                        form.append("__user", "0")
                        form.append("__a", "1")
                        form.append("__csr", "")
                        form.append("__req", "8")
                        form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
                        form.append("dpr", "1")
                        form.append("__ccg", "UNKNOWN")
                        form.append("__rev", "1007965968")
                        form.append("__comment_req", "0")

                        let res = await axioss({
                            url,
                            method: "POST",
                            data: form,
                            headers: {
                                cookie
                            }

                        })
                        Yorireply(`Wait 1-24 Jam an untuk proses unbanned dari bot dan tunggu ±30 Detik an untuk melihat balasan email dari WhatsApp :3`)
                        await YoriLD(90000)
                        let payload = String(res.data)
                        if (payload.includes(`"payload":true`)) {
                            Yorireply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
                        } else if (payload.includes(`"payload":false`)) {
                            Yorireply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
                        } else Yorireply(util.format(res.data))
                    } catch (err) { Yorireply(`${err}`) }
                } else Yorireply('Masukkan nomor target!')
            }
                break

            case 'unbannedv5': {
                if (!isCreator) return
                if (m.quoted || q) {
                    var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                    if (tosend === global.owner) return Yorireply(`Tidak bisa verif My Creator!`)
                    var targetnya = tosend.split('@')[0]

                    try {
                        var axioss = require('axios')
                        let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
                        let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
                        let cookie = ntah.headers["set-cookie"].join("; ")
                        const cheerio = require('cheerio');
                        let $ = cheerio.load(ntah.data)
                        let $form = $("form");
                        let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
                        let form = new URLSearchParams()
                        form.append("jazoest", $form.find("input[name=jazoest]").val())
                        form.append("lsd", $form.find("input[name=lsd]").val())
                        form.append("step", "submit")
                        form.append("country_selector", "+")
                        form.append("phone_number", `+${targetnya}`,)
                        form.append("email", email.data[0])
                        form.append("email_confirm", email.data[0])
                        form.append("platform", "ANDROID")
                        form.append("your_message", `Aloha WhatsApp, ua ʻaihue ʻia kaʻu helu e ka mea hacker, e ʻoluʻolu e wehe hou iā ia [${targetnya}]`)
                        form.append("__user", "0")
                        form.append("__a", "1")
                        form.append("__csr", "")
                        form.append("__req", "8")
                        form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
                        form.append("dpr", "1")
                        form.append("__ccg", "UNKNOWN")
                        form.append("__rev", "1007965968")
                        form.append("__comment_req", "0")

                        let res = await axioss({
                            url,
                            method: "POST",
                            data: form,
                            headers: {
                                cookie
                            }

                        })
                        Yorireply(`Wait 1-24 Jam an untuk proses unbanned dari bot dan tunggu ±30 Detik an untuk melihat balasan email dari WhatsApp :3`)
                        await YoriLD(90000)
                        let payload = String(res.data)
                        if (payload.includes(`"payload":true`)) {
                            Yorireply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
                        } else if (payload.includes(`"payload":false`)) {
                            Yorireply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
                        } else Yorireply(util.format(res.data))
                    } catch (err) { Yorireply(`${err}`) }
                } else Yorireply('Masukkan nomor target!')
            }
                break

                        case 'limit': {
                Yorireply('*Sisa Limit Kamu :* ' + (db.data.users[m.sender].limit))
            }
break

case 'resetlimit': {
if (!isCreator) return Yorireply(mess.owner)
let list = Object.entries(global.db.data.users)
	let lim = !args || !args[0] ? 50 : isNumber(args[0]) ? parseInt(args[0]) : 50
	lim = Math.max(1, lim)
	list.map(([user, data], i) => (Number(data.limit = lim)))
		Yori.sendMessage(m.chat, {text: `📑 *Limit Setiap User Berhasil Direset*`}, { quoted: len })
		}
break

case 'addlimit': {
if (!isCreator) return Yorireply(mess.owner)
if (!text) return Yorireply('*Masukkan Jumlah Limit Yang Akan Diberi*')
    let who
    if (m.isGroup) who = m.mentionedJid[0]
    else who = m.chat
    if (!who) throw '*Tag Orangnya*'
    let txt = text.replace('@' + who.split`@`[0], '').trim()
    if (isNaN(txt)) throw '*Hanya Angka*'
    let poin = parseInt(txt)
    let limit = poin
    if (limit < 1) throw '*Minimal 1*'
    let user = global.db.data.users
    user[who].limit += poin
    if (limit > 9999999) return lenwyreply('*Kebanyakan*') 
    Yori.sendMessage(m.chat, {text: `🎁 *Sukses Menambahkan +${poin} Limit!*`}, {quoted:m})
    }
break

case 'dellimit': {
if (!isCreator) return Yorireply(mess.owner)
if (!text) return Yorireply('☘️ *Masukkan Jumlah Limit Yang Akan Dihapus*')
    let who
    if (m.isGroup) who = m.mentionedJid[0]
    else who = m.chat
    if (!who) throw '☘️ *Tag Orangnya*'
    let txt = text.replace('@' + who.split`@`[0], '').trim()
    if (isNaN(txt)) throw '☘️ *Hanya Angka*'
    let poin = parseInt(txt)
    let limit = poin
    if (limit < 1) throw '☘️ *Minimal 1*'
    let user = global.db.data.users
    user[who].limit -= poin
    if (limit > 9999999) return Yorireply('☘️ *Kebanyakan*') 
    Yori.sendMessage(m.chat, {text: `📑 *Sukses Menghapus -${poin} Limit!*`}, {quoted:m})
    }
                break

            case 'hd': case 'hdr': case 'remini': {
                if (!quoted) return Yorireply(`Fotonya Mana?`)
                if (!/image/.test(mime)) return Yorireply(`🍃 *Fotonya Mana?*`)
                if (global.db.data.users[m.sender].limit < 1) return Yorireply('⚠️ *Limit Kamu Habis*')
                db.data.users[m.sender].limit -= 5
                Yorireply('🍃 *5 Limit Digunakan*')
                let media = await quoted.download()
                let proses = await remini(media, "enhance");
                Yori.sendMessage(m.chat, { image: proses, caption: '🍃 *Selesai Kak >//<*' }, { quoted: m })
            }
           
/*           
case 'hdr': case 'hd': case 'remin':
  if (isBan) return Yorireply(mess.ban)
  if (!quoted) return Yorireply(`*PERMINTAAN ERROR!! PESAN :*\n> *Kirim/Reply Gambar Dengan Caption .hd*`)
  if (!/image/.test(mime)) return Yorireply(`*PERMINTAAN ERROR!! PESAN :*\n> *Kirim/Reply Gambar Dengan Caption .hd*`)
  let media = await Yori.downloadAndSaveMediaMessage(quoted);
  let yor = await yoricdn(media);
  let cdn = yor.result.url;
  let proses = await (await fetch('https://api.shannmoderz.xyz/tools/enhace?url=' + cdn)).json();
  let imge = proses.result.data;
  Yori.sendMessage(m.chat, { image: { url: imge.downloadUrls[0] }, caption: '*Nih Kak Image Hadenya >–<*'}, { quoted: m})
  */
                break
case 'hdvid': {
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || "";
    if (!m.quoted || !/video/.test(mime)) {
      await Yori.sendMessage(
        m.chat,
        { text: "Tolong kirimkan video yang ingin diubah." },
        { quoted: m },
      );
      return;
    }

    m.reply("Waiting..");

    try {
      const { VideoHD } = require("./scrape/hdvid.js");
      const media = await m.quoted.download();
      const videoPath = path.join(__dirname, "video.mp4");
      const outputPath = path.join(__dirname, "output.mp4");

      fs.writeFileSync(videoPath, media);

      await VideoHD(videoPath, outputPath, async (err, videoPath) => {
        if (err) {
          await Yori.sendMessage(
            m.chat,
            { text: "Terjadi kesalahan saat mengubah video." },
            { quoted: m },
          );
          return;
        }

        await Yori.sendMessage(
          m.chat,
          {
            video: { url: videoPath },
            caption: "Ini adalah video yang telah diubah menjadi HD.",
          },
          { quoted: m },
        );

        fs.unlink(videoPath, (err) => {
          if (err) {
            console.error(
              "Terjadi kesalahan saat menghapus video input:",
              err.message,
            );
          } else {
            console.log("File video input berhasil dihapus.");
          }
        });
        fs.unlink(outputPath, (err) => {
          if (err) {
            console.error(
              "Terjadi kesalahan saat menghapus video output:",
              err.message,
            );
          } else {
            console.log("File output berhasil dihapus.");
          }
        });
      });
    } catch (error) {
      console.error("Terjadi kesalahan saat mengunduh video:", error.message);
      await Yori.sendMessage(
        m.chat,
        { text: "Terjadi kesalahan saat mengunduh video." },
        { quoted: m },
      );
    }
}
                break

            case 'removebg': case 'nobg':{
if (!quoted) return Yorireply(`Fotonya Mana?`)
if (!/image/.test(mime)) return Yorireply(`☘️ *Mana Fotonya?*`)
if (global.db.data.users[m.sender].limit < 1) return Yorireply('⚠️ *Limit Kamu Habis*')
Yorireply('☘️ *5 Limit Digunakan*')
let media = await quoted.download()
let url = await uploadImage(media)
let anu = await fetch(`https://widipe.com/removebg?url=${url}`)
let data = await anu.json()
await Yori.sendFile(m.chat, data.url.result, 'Yori.jpg', '🎁 *Removebg Selesai*', { quoted: m})
}
if (!isPrem) return db.data.users[m.sender].limit -= 5
                break
            case "jadinyata": case "toreal": case 'toanime': case 'jadianime': {
                if (!isPrem) return Yorireply(mess.prem)
                if (!quoted) return Yorireply(`Fotonya Mana?`)
                if (!/image/.test(mime)) return Yorireply(`Send/Reply Foto Dengan Caption ${prefix + command}`)
                let { key } = await Yori.sendMessage(m.chat, { text: mess.wait }, { quoted: m })
                let type = "anime2d"
                if (["jadinyata", "toreal"].includes(command)) {
                    type = "anime2real"
                }
                let tryng = 0
                const media = await Yori.downloadAndSaveMediaMessage(quoted)
                let tph = await TelegraPh(media)
                try {
                    let ai = await fetch(api.xterm.url + "/api/img2img/filters?action=" + type + "&url=" + tph + "&key=" + api.xterm.key).then(a => a.json())
                    console.log(ai)
                    if (!ai.status) return Yorireply(ai?.msg || "Error!")
                    while (tryng < 55) {
                        let s = await fetch(api.xterm.url + "/api/img2img/filters/batchProgress?id=" + ai.id).then(a => a.json())
                        await Yori.sendMessage(m.chat, { text: s?.progress || "Prepare... ", edit: key }, { quoted: m })
                        if (s.status == 3) {
                            return Yori.sendMessage(m.chat, { image: { url: s.url } }, { quoted: m })
                        }
                        if (s.status == 4) {
                            return Yorireply("Maaf terjadi kesalhan. coba gunakan gambar lain!")
                        }
                        await new Promise(resolve => setTimeout(resolve, 5000))
                    }
                } catch (e) {
                    console.error(e)
                    Yorireply(`Type-Err! :\n${e}`)
                }
            }
                break



            /*
            case 'qc': {
            if (!q) return Yorireply(`☘️ *Contoh : Qc White Yori*\n🎁 *Kode Warna Ketik : Qckode*`)
            if (text.length > 80) return Yorireply(`☘️ *Maksimal 80 Karakter*`)
            const isToxic = /(ewe|bangsad|mmk|koncol|kontol|k0ntl|k0ntol|kont0l|k0nt0l|kontoI|puki|kojtol|kintil|momok|nigga|ajg|ewean|yatim|anjing|kontol|memek|bangsat|babi|gblk|goblok|goblog|kntl|pepek|ppk|ngentod|ngentd|ngntd|kentod|kntd|bgst|anjg|anj|fuck|hitam|ireng|jawir|gay|asw|ktl|ngentot|ngewe|bokep|bkp|lonte|lont|bh|perawan|prawan|tolol|tlol|itil|tobrut|tobrud|tbrut|tbrud)/i;
            const Yoriguard = isToxic.exec(m.text)
            if (Yoriguard) return Yorireply('⚠ Yori Melarang Anda Menggunakan Bahasa Kotor Pada Fitur Qc*')     
            let [color, ...message] = text.split(' ');
            message = message.join(' ');
            let backgroundColor;
            switch(color) {
            case 'pink':
            backgroundColor = '#f68ac9';
            break;
            case 'blue':
            backgroundColor = '#6cace4';
            break;
            case 'red':
            backgroundColor = '#f44336';
            break;
            case 'green':
            backgroundColor = '#4caf50';
            break;
            case 'yellow':
            backgroundColor = '#ffeb3b';
            break;
            case 'purple':
            backgroundColor = '#9c27b0';
            break;
            case 'darkblue':
            backgroundColor = '#0d47a1';
            break;
            case 'lightblue':
            backgroundColor = '#03a9f4'; 
            break;
            case 'ash':
            backgroundColor = '#9e9e9e';
            break;
            case 'orange':
            backgroundColor = '#ff9800';
            break;
            case 'black':
            backgroundColor = '#000000';
            break;
            case 'white':
            backgroundColor = '#ffffff';
            break;
            case 'teal':
            backgroundColor = '#008080';
            break;
            case 'lightpink':
            backgroundColor = '#FFC0CB';
            break;
            case 'chocolate':
            backgroundColor = '#A52A2A';
            case 'salmon':
            backgroundColor = '#FFA07A'; 
            break; 
            case 'magenta':
            backgroundColor = '#FF00FF'; 
            break; 
            case 'tan':
            backgroundColor = '#D2B48C'; 
            break;
            case 'wheat':
            backgroundColor = '#F5DEB3'; 
            break;
            case 'deeppink':
            backgroundColor = '#FF1493'; 
            break; 
            case 'fire':
            backgroundColor = '#B22222';
            break;
            case 'skyblue':
            backgroundColor = '#00BFFF';
            break; 
            case 'orange':
            backgroundColor = '#FF7F50';
            break;
            case 'brightskyblue':
            backgroundColor = '#1E90FF'; 
            break; 
            case 'hotpink':
            backgroundColor = '#FF69B4'; 
            break; 
            case 'lightskyblue':
            backgroundColor = '#87CEEB'; 
            break; 
            case 'seagreen':
            backgroundColor = '#20B2AA'; 
            break; 
            case 'darkred':
            backgroundColor = '#8B0000'; 
            break; 
            case 'orangered':
            backgroundColor = '#FF4500'; 
            break; 
            case 'cyan':
            backgroundColor = '#48D1CC'; 
            break; 
            case 'violet':
            backgroundColor = '#BA55D3'; 
            break; 
            case 'mossgreen':
            backgroundColor = '#00FF7F'; 
            break; 
            case 'darkgreen':
            backgroundColor = '#008000'; 
            break; 
            case 'navyblue':
            backgroundColor = '#191970'; 
            break; 
            case 'darkorange':
            backgroundColor = '#FF8C00'; 
            break; 
            case 'darkpurple':
            backgroundColor = '#9400D3'; 
            break; 
            case 'fuchsia':
            backgroundColor = '#FF00FF'; 
            break; 
            case 'darkmagenta':
            backgroundColor = '#8B008B'; 
            break;
            case 'darkgray':
            backgroundColor = '#2F4F4F'; 
            break;
            case 'peachpuff':
            backgroundColor = '#FFDAB9'; 
            break;
            case 'darkishgreen':
            backgroundColor = '#BDB76B'; 
            break;
            case 'darkishred':
            backgroundColor = '#DC143C'; 
            break;
            case 'goldenrod':
            backgroundColor = '#DAA520'; 
            break;
            case 'darkishgray':
            backgroundColor = '#696969'; 
            break;
            case 'darkishpurple':
            backgroundColor = '#483D8B'; 
            break;
            case 'gold':
            backgroundColor = '#FFD700'; 
            break;
            case 'silver':
            backgroundColor = '#C0C0C0'; 
            break;
            default:
            return Yorireply('☘️ *Kode Warna Tidak Ditemukan*\n🎁 *Contoh : Qc White Yori Chantik*\n⚠️ *Tolong Gunakan Huruf Kecil Pada Kode Warna*')
            }
            let obj = {
            type: 'quote',
            format: 'png',
            backgroundColor,
            width: 512,
            height: 768,
            scale: 2,
            messages: [
            {
            entities: [],
            avatar: true,
            from: {
            id: 1,
            name: pushname,
            photo: { 
            url: await Yori.profilePictureUrl(m.sender, "image").catch(() => 'https://telegra.ph/file/6880771a42bad09dd6087.jpg'),
            }
            },
            text: message,
            replyMessage: {},
            },
            ],
            };
            let response = await axios.post('https://bot.lyo.su/quote/generate', obj, {
            headers: {
            'Content-Type': 'application/json',
            },
            });
            let buffer = Buffer.from(response.data.result.image, 'base64');
            Yori.sendImageAsSticker(m.chat, buffer, m, { packname: `${global.packname}`, author: `${global.author}`})
            }
            */

            case 'qc': case 'xxqc': {
                if (!q) return Yorireply(`📌Example: ${prefix + command} pink hallo\n\n꒰ 🖌️ Color List ꒱ ೄྀ࿐ ˊˎ-\n━━━━━━⊱⋆⊰━━━━━━\npink\nblue\nred\ngreen\nyellow\npurple\ndarkblue\nlightblue\nash\norange\nblack\nwhite\nteal\nlightpink\nchocolate\nsalmon\nmagenta\ntan\nwheat\ndeeppink\nfire\nskyblue\nsafron\nbrightskyblue\nhotpink\nlightskyblue\nseagreen\ndarkred\norangered\ncyan\nviolet\nmossgreen\ndarkgreen\nnavyblue\ndarkorange\ndarkpurple\nfuchsia\ndarkmagenta\ndarkgray\npeachpuff\nblackishgreen\ndarkishred\ngoldenrod\ndarkishgray\ndarkishpurple\ngold\nsilver`)
                if (text.length > 100) return Yorireply(`Max 100 character.`)
                let [color, ...message] = text.split(' ');
                message = message.join(' ');
                let backgroundColor;
                switch (color) {
                    case 'pink':
                        backgroundColor = '#f68ac9';
                        break;
                    case 'blue':
                        backgroundColor = '#6cace4';
                        break;
                    case 'red':
                        backgroundColor = '#f44336';
                        break;
                    case 'green':
                        backgroundColor = '#4caf50';
                        break;
                    case 'yellow':
                        backgroundColor = '#ffeb3b';
                        break;
                    case 'purple':
                        backgroundColor = '#9c27b0';
                        break;
                    case 'darkblue':
                        backgroundColor = '#0d47a1';
                        break;
                    case 'lightblue':
                        backgroundColor = '#03a9f4';
                        break;
                    case 'ash':
                        backgroundColor = '#9e9e9e';
                        break;
                    case 'orange':
                        backgroundColor = '#ff9800';
                        break;
                    case 'black':
                        backgroundColor = '#000000';
                        break;
                    case 'white':
                        backgroundColor = '#ffffff';
                        break;
                    case 'teal':
                        backgroundColor = '#008080';
                        break;
                    case 'lightpink':
                        backgroundColor = '#FFC0CB';
                        break;
                    case 'chocolate':
                        backgroundColor = '#A52A2A';
                    case 'salmon':
                        backgroundColor = '#FFA07A';
                        break;
                    case 'magenta':
                        backgroundColor = '#FF00FF';
                        break;
                    case 'tan':
                        backgroundColor = '#D2B48C';
                        break;
                    case 'wheat':
                        backgroundColor = '#F5DEB3';
                        break;
                    case 'deeppink':
                        backgroundColor = '#FF1493';
                        break;
                    case 'fire':
                        backgroundColor = '#B22222';
                        break;
                    case 'skyblue':
                        backgroundColor = '#00BFFF';
                        break;
                    case 'orange':
                        backgroundColor = '#FF7F50';
                        break;
                    case 'brightskyblue':
                        backgroundColor = '#1E90FF';
                        break;
                    case 'hotpink':
                        backgroundColor = '#FF69B4';
                        break;
                    case 'lightskyblue':
                        backgroundColor = '#87CEEB';
                        break;
                    case 'seagreen':
                        backgroundColor = '#20B2AA';
                        break;
                    case 'darkred':
                        backgroundColor = '#8B0000';
                        break;
                    case 'orangered':
                        backgroundColor = '#FF4500';
                        break;
                    case 'cyan':
                        backgroundColor = '#48D1CC';
                        break;
                    case 'violet':
                        backgroundColor = '#BA55D3';
                        break;
                    case 'mossgreen':
                        backgroundColor = '#00FF7F';
                        break;
                    case 'darkgreen':
                        backgroundColor = '#008000';
                        break;
                    case 'navyblue':
                        backgroundColor = '#191970';
                        break;
                    case 'darkorange':
                        backgroundColor = '#FF8C00';
                        break;
                    case 'darkpurple':
                        backgroundColor = '#9400D3';
                        break;
                    case 'fuchsia':
                        backgroundColor = '#FF00FF';
                        break;
                    case 'darkmagenta':
                        backgroundColor = '#8B008B';
                        break;
                    case 'darkgray':
                        backgroundColor = '#2F4F4F';
                        break;
                    case 'peachpuff':
                        backgroundColor = '#FFDAB9';
                        break;
                    case 'darkishgreen':
                        backgroundColor = '#BDB76B';
                        break;
                    case 'darkishred':
                        backgroundColor = '#DC143C';
                        break;
                    case 'goldenrod':
                        backgroundColor = '#DAA520';
                        break;
                    case 'darkishgray':
                        backgroundColor = '#696969';
                        break;
                    case 'darkishpurple':
                        backgroundColor = '#483D8B';
                        break;
                    case 'gold':
                        backgroundColor = '#FFD700';
                        break;
                    case 'silver':
                        backgroundColor = '#C0C0C0';
                        break;
                    default:
                        return Yorireply('Warna Yang di Pilih tidak Tersedia Kak.')
                }
                let obj = {
                    type: 'quote',
                    format: 'png',
                    backgroundColor,
                    width: 512,
                    height: 768,
                    scale: 2,
                    messages: [
                        {
                            entities: [],
                            avatar: true,
                            from: {
                                id: 1,
                                name: pushname,
                                photo: {
                                    url: await Yori.profilePictureUrl(m.sender, "image").catch(() => 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'),
                                }
                            },
                            text: message,
                            replyMessage: {},
                        },
                    ],
                };
                let response = await axios.post('https://bot.lyo.su/quote/generate', obj, {
                    headers: {
                        'Content-Type': 'application/json',
                    },
                });
                let buffer = Buffer.from(response.data.result.image, 'base64');
                Yori.sendImageAsSticker(m.chat, buffer, m, { packname: `${global.packname}`, author: `${global.author}` })
            }
                break

            case 'qckode': {
                Yorireply(`📦 *Kode Warna Qc*
 *⨠ Pink*
 *⨠ Blue*
 *⨠ Red*
 *⨠ Green*
 *⨠ Yellow*
 *⨠ Purple*
 *⨠ Darkblue*
 *⨠ Lightblue*
 *⨠ Ash*
 *⨠ Orange*
 *⨠ Black*
 *⨠ White*
 *⨠ Teal*
 *⨠ Lightpink*
 *⨠ Chocolate*
 *⨠ Salmon*
 *⨠ Magenta*
 *⨠ Tan*
 *⨠ Wheat*
 *⨠ Deeppink*
 *⨠ Fire*
 *⨠ Skyblue*
 *⨠ Safron*
 *⨠ Brightskyblue*
 *⨠ Hotpink*
 *⨠ Lightskyblue*
 *⨠ Seagreen*
 *⨠ Darkred*
 *⨠ Orangered*
 *⨠ Cyan*
 *⨠ Violet*
 *⨠ Mossgreen*
 *⨠ Darkgreen*
 *⨠ Navyblue*
 *⨠ Darkorange*
 *⨠ Darkpurple*
 *⨠ Fuchsia*
 *⨠ Darkmagenta*
 *⨠ Darkgray*
 *⨠ Peachpuff*
 *⨠ Blackishgreen*
 *⨠ Darkishred*
 *⨠ Goldenrod*
 *⨠ Darkishgray*
 *⨠ Darkishpurple*
 *⨠ Gold*
 *⨠ Silver*

⚠️ *Kalo Ada Error Bisa Chat Owner Ya*
`)
            }
                break

            case 'totalfitur':
            case 'totalfeature': {
                Yorireply(`
TOTAL FEATURE YORI CHAN

Total Feature Pada Yori Chan Berjumalah ${totalFitur()} Feature`)
            }
                break
/*
            case 'ai': {
                if (!q) return Yorireply(`🍃 *Mau Nanya Apa Sama AI?*`)

                async function gpt(text) {
                    let body = {
                        messages: [{
                            role: "user",
                            content: text
                        }]
                    }
                    let res = await fetch(`${api.xterm.url}/api/chat/gpt?key=${api.xterm.key}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(body)
                    })
                    res = await res.json()
                    return res.response
                }
                Yorireply('🍃 *Sabar Yaa*')
                var lenai = await gpt(q)
                await Yorireply(lenai)
            }
                break
*/
/*
            case 'ai': case 'openai': case 'open-ai': {
                if (!text) return Yorireply(`*• Example:* ${prefix + command} Siapakah orang yang telah menemukan Komputer di jaman Majapahit`);
                try {
                    let gpt = await (await fetch(`https://widipe.com/openai?text=${text}`)).json()
                    let msgs = generateWAMessageFromContent(m.chat, {
                        viewOnceMessage: {
                            message: {
                                "messageContextInfo": {
                                    "deviceListMetadata": {},
                                    "deviceListMetadataVersion": 2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: '> Open AI\n\n' + gpt.result
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: botname
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        hasMediaAttachment: false,
                                        ...await prepareWAMessageMedia({ image: fs.readFileSync('./data/image/openai.jpg') }, { upload: Yori.waUploadToServer })
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"Nice Open Ai ✨","id":".mangap"}`
                                        }],
                                    }),
                                    contextInfo: {
                                        mentionedJid: [m.sender],
                                        forwardingScore: 999,
                                        isForwarded: true,
                                        forwardedNewsletterMessageInfo: {
                                            newsletterJid: '120363204138641225@newsletter',
                                            newsletterName: ownername,
                                            serverMessageId: 143
                                        }
                                    }
                                })
                            }
                        }
                    }, { quoted: m })
                    await Yori.relayMessage(m.chat, msgs.message, {})
                } catch (e) {
                    return Yorireply("`*Error Kak :(*`")
                }
            }
            */
            case 'ai': 
case 'openai': 
case 'open-ai': {
    if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
    if (!text) return Yorireply(`*• Contoh penggunaan:* ${prefix + command} Siapakah orang yang menemukan Komputer di jaman Majapahit`);    
    try {
        // Fetch jawaban dari API OpenAI
        let gpt = await (await fetch(`https://widipe.com/openai?text=${text}`)).json();
        let message = `${gpt.result}`;
        let response = {
            text: message,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: "OpenAI",
                    body: botname,
                    thumbnailUrl: 'https://tmpfiles.org/dl/13411493/1727352390796.jpg', // Ganti dengan URL gambar thumbnail Anda
                    sourceUrl: '',
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        };
        // Mengirim pesan
        await Yori.sendMessage(m.chat, response, { quoted: m });        
    } catch (e) {
        // Menangani error jika fetch gagal
        return Yorireply("`*Terjadi kesalahan saat memproses permintaan.*`");
    }
}
                break
            
            case 'llama3': {
  if (!text) return Yorireply('masukkan pertanyaanmu kak!')
  Yorireply(mess.wait) 
  try {
    let response = await fetch(`https://endpoint.web.id/ai/llama3?key=Yori&query=${text}`)
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    let llama = await response.json()
    let Yori = llama.result
    Yorireply(Yori)
  } catch (err) {
    console.error(err)  // Logging kesalahan ke konsol
    Yorireply('Terjadi Kesalahan Dalam Pencarian')
  }
}

break            
            /*
            case 'luminai': case 'lumin-ai': case 'lumin': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (!text) return Yorireply(`*• Example:* ${prefix + command} Bot Adalah`);
                try {
                    let gpt = await (await fetch(`https://widipe.com/openai?text=${text}`)).json()
                    let msgs = generateWAMessageFromContent(m.chat, {
                        viewOnceMessage: {
                            message: {
                                "messageContextInfo": {
                                    "deviceListMetadata": {},
                                    "deviceListMetadataVersion": 2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: '> Lumin AI\n\n' + gpt.result
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: botname
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        hasMediaAttachment: false,
                                        ...await prepareWAMessageMedia({ image: fs.readFileSync('./data/image/lumin.jpg') }, { upload: Yori.waUploadToServer })
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"Nice LuminAi ✨","id":".mangap"}`
                                        }],
                                    }),
                                    contextInfo: {
                                        mentionedJid: [m.sender],
                                        forwardingScore: 999,
                                        isForwarded: true,
                                        forwardedNewsletterMessageInfo: {
                                            newsletterJid: '120363204138641225@newsletter',
                                            newsletterName: botname,
                                            serverMessageId: 143
                                        }
                                    }
                                })
                            }
                        }
                    }, { quoted: m })
                    await Yori.relayMessage(m.chat, msgs.message, {})
                } catch (e) {
                    return Yorireply("`*[ Terjadi Kesalahan ]*`")
                }
            }
            */
            case "luminai": {
Yori.sendMessage(from, {react: {text: "🧐", key: m.key}})
  if (!text) {
    return Yorireply(`Contoh: ${prefix + command} hai luminai`);
  }
  const prompt = `Anda adalah luminai, kamu memiliki kecerdasan ai yang luar biasa, kamu senang membantu orang lain, dan gaya bicara mu sangatlah sopan`
  const requestData = { content: text, user: m.sender, prompt: prompt };
  const quoted = m && (m.quoted || m);

  try {
    let response;
    const mimetype = quoted?.mimetype || quoted?.msg?.mimetype;

    if (mimetype && /image/.test(mimetype)) {
      requestData.imageBuffer = await quoted.download();
    }

    response = (await axios.post('https://luminai.my.id', requestData)).data.result;
    m.reply(response);
  } catch (err) {
    m.reply(err.toString());
  }
}
                break
            /*
            case 'lepton': {
              if (!text) return Yorireply('masukkan pertanyaanmu kak!')
              Yorireply('📶 *Sabar Yaa Kak*') 
              try {
                let lepton = await (await fetch(`https://api.shannmoderz.xyz/ai/lepton?query=${text}`)).json()
                let Yori = lepton.result
                Yorireply(Yori)
              } catch (err) {
                  Yorireply('Terjadi Kesalahan Dalam Pencarian')
                }
            }
            */

            case 'lepton': case 'leptonai': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (!text) return Yorireply(`*• Example:* ${prefix + command} Siapakah orang yang telah menemukan Komputer di jaman Majapahit`);
                try {
                    let gpt = await (await fetch(`https://widipe.com/openai?text=${text}`)).json()
                    let msgs = generateWAMessageFromContent(m.chat, {
                        viewOnceMessage: {
                            message: {
                                "messageContextInfo": {
                                    "deviceListMetadata": {},
                                    "deviceListMetadataVersion": 2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: '> Lepton AI\n\n' + gpt.result
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: botname
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        hasMediaAttachment: false,
                                        ...await prepareWAMessageMedia({ image: fs.readFileSync('./data/image/lepton.jpg') }, { upload: Yori.waUploadToServer })
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"Nice Lepton Ai ✨","id":".mangap"}`
                                        }],
                                    }),
                                    contextInfo: {
                                        mentionedJid: [m.sender],
                                        forwardingScore: 999,
                                        isForwarded: true,
                                        forwardedNewsletterMessageInfo: {
                                            newsletterJid: '120363204138641225@newsletter',
                                            newsletterName: botname,
                                            serverMessageId: 143
                                        }
                                    }
                                })
                            }
                        }
                    }, { quoted: m })
                    await Yori.relayMessage(m.chat, msgs.message, {})
                } catch (e) {
                    return Yorireply("`*Error Kak :(*`")
                }
            }
                break
            /*
            case 'toanime':{
            if (!quoted) return Yorireply(`Send/Reply Foto Dengan Caption ${prefix + command}`)
            if (!/image/.test(mime)) return Yorireply(`Send/Reply Foto Dengan Caption ${prefix + command}`)
            let q = m.quoted ? m.quoted : m
            let media = await q.download()
            let url = await uploadImage(media)
            let gpt = await (await fetch(`https://widipe.com/toanime?url=${url}`)).json()
            let msgs = generateWAMessageFromContent(m.chat, {
              viewOnceMessage: {
                message: {
                    "messageContextInfo": {
                      "deviceListMetadata": {},
                      "deviceListMetadataVersion": 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                      body: proto.Message.InteractiveMessage.Body.create({
                        text: `Nih Sudah Selesai Kak >\\<`
                      }),
                      footer: proto.Message.InteractiveMessage.Footer.create({
                        text: botname
                      }),
                      header: proto.Message.InteractiveMessage.Header.create({
                      hasMediaAttachment: false,
                      ...await prepareWAMessageMedia({ image: {url:gpt.result}}, { upload: Yori.waUploadToServer })
                      }),
                      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [{
                        "name": "quick_reply",
                          "buttonParamsJson": `{\"display_text\":\"Good Yori Chan ✨\",\"id\":\""}`
                        }],
                      }), 
                      contextInfo: {
                              mentionedJid: [m.sender], 
                              forwardingScore: 999,
                              isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                              newsletterJid: '12036322239567560@newsletter',
                              newsletterName: ownername,
                              serverMessageId: 143
                            }
                            }
                   })
                }
              }
            }, { quoted: m })
            return await Yori.relayMessage(m.chat, msgs.message, {})
            }
            break
            */
            case 'guru-ai': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (!text) return Yorireply(`*• Example:* ${prefix + command} Siapakah orang yang telah menemukan Komputer di jaman Majapahit`);
                try {
                    let gpt = await (await fetch(`https://itzpire.com/ai/degreeGuru?q=${text}`)).json()
                    let msgs = generateWAMessageFromContent(m.chat, {
                        viewOnceMessage: {
                            message: {
                                "messageContextInfo": {
                                    "deviceListMetadata": {},
                                    "deviceListMetadataVersion": 2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: '> Guru AI\n\n' + gpt.result
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: botname
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        hasMediaAttachment: false,
                                        ...await prepareWAMessageMedia({ image: fs.readFileSync('./data/image/guru.jpg') }, { upload: Yori.waUploadToServer })
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{\"display_text\":\"Nice Yori Chan ✨\",\".mangap\":\"\"}`
                                        }],
                                    }),
                                    contextInfo: {
                                        mentionedJid: [m.sender],
                                        forwardingScore: 999,
                                        isForwarded: true,
                                        forwardedNewsletterMessageInfo: {
                                            newsletterJid: '120363204138641225@newsletter',
                                            newsletterName: ownername,
                                            serverMessageId: 143
                                        }
                                    }
                                })
                            }
                        }
                    }, { quoted: m })
                    await Yori.relayMessage(m.chat, msgs.message, {})
                } catch (e) {
                    return Yorireply("`*Error Kak :(*`")
                }
            }
                break

            case 'mangap': {
                Yorireply(`Makasi Kakak Atas Pujian dari kak ${pushname}`)
            }
                break
              case 'yousearch': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (!text) return Yorireply('masukkan pertanyaanmu!')
                Yorireply(mess.wait) 
                try {
                    let yousearch = await (await fetch(`https://endpoint.web.id/ai/yousearch?key=Yori&query=${text}`)).json()
                    let Yori = yousearch.result
                    Yorireply(Yori)
                } catch (err) {
                    Yorireply('Terjadi Kesalahan Saat Searching')
                }
            }
                break

case 'yoriai': case 'yori-ai': {
    if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
    if (!text) return Yorireply(`*• Contoh penggunaan:* ${prefix + command} Siapakah orang yang menemukan Komputer di jaman Majapahit`);    
    try {
        // Fetch jawaban dari API OpenAI
        let gpt = await (await fetch(`https://widipe.com/v2/gpt4?text=${text}`)).json();
        let message = `${gpt.result}`;
        let response = {
            text: message,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: "Yori Ai Simple Botz",
                    body: botname,
                    thumbnailUrl: 'https://tmpfiles.org/dl/13411500/1727352399199.jpg', // Ganti dengan URL gambar thumbnail Anda
                    sourceUrl: '',
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        };
        // Mengirim pesan
        await Yori.sendMessage(m.chat, response, { quoted: m });        
    } catch (e) {
        // Menangani error jika fetch gagal
        return Yorireply("`*Terjadi kesalahan saat memproses permintaan.*`");
    }
}
                break                

case 'ask': case 'askai': case 'ask-ai': {
    if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
    if (!text) return Yorireply(`*• Contoh penggunaan:* ${prefix + command} Siapakah orang yang menemukan Komputer di jaman Majapahit`);    
    try {
        // Fetch jawaban dari API OpenAI
        let gpt = await (await fetch(`https://widipe.com/gpt4?text=${text}`)).json();
        let message = `${gpt.result}`;
        let response = {
            text: message,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: "Ask Ai Simple Botz",
                    body: botname,
                    thumbnailUrl: 'https://tmpfiles.org/dl/13411988/1727352764384.jpg', // Ganti dengan URL gambar thumbnail Anda
                    sourceUrl: '',
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        };
        // Mengirim pesan
        await Yori.sendMessage(m.chat, response, { quoted: m });        
    } catch (e) {
        // Menangani error jika fetch gagal
        return Yorireply("`*Terjadi kesalahan saat memproses permintaan.*`");
    }
}
                break
                
            /*
            case 'gpt4': {
            if (!text) return Yorireply(`🍃 *Mau Nanya Apa Sama GPT4?*`)
            Yorireply('🍃 *Sabar Yaa*')
            var Yoriai = await fetchJson(`https://widipe.com/gpt4?text=${text}`)
             var lenai = Yoriai.result
            await Yorireply(lenai)
            }
            */
case 'gpt-4': case 'gpt4': {
    if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
    if (!text) return Yorireply(`*• Contoh penggunaan:* ${prefix + command} Siapakah orang yang menemukan Komputer di jaman Majapahit`);    
    try {
        let gpt = await (await fetch(`https://widipe.com/gpt4?text=${text}`)).json();
        let message = `${gpt.result}`;
        let response = {
            text: message,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: "ChatGpt-4 Simple Botz",
                    body: botname,
                    thumbnailUrl: 'https://tmpfiles.org/dl/13411498/1727352395066.jpg', // Ganti dengan URL gambar thumbnail Anda
                    sourceUrl: '',
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        };
        await Yori.sendMessage(m.chat, response, { quoted: m });        
    } catch (e) {
        // Menangani error jika fetch gagal
        return Yorireply("`*Terjadi kesalahan saat memproses permintaan.*`");
    }
}
                break
/*
            case 'gpt4_2': {
                if (!text) return Yorireply(`🍃 *Mau Nanya Apa Sama GPT4v2?*`)
                Yorireply('🍃 *Sabar Yaa*')
                var Yoriai = await fetchJson(`https://widipe.com/v2/gpt4?text=${text}`)
                var lenai = Yoriai.result
                await Yorireply(lenai)
            }
            */
            case 'gpt4_2': {
    if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
    if (!text) return Yorireply(`*• Contoh penggunaan:* ${prefix + command} Siapakah orang yang menemukan Komputer di jaman Majapahit`);    
    try {
        // Fetch jawaban dari API OpenAI
        let gpt = await (await fetch(`https://widipe.com/v2/gpt4?text=${text}`)).json();
        let message = `${gpt.result}`;
        let response = {
            text: message,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: "Gpt4_2 Statistics Simple",
                    body: botname,
                    thumbnailUrl: 'https://tmpfiles.org/dl/13411485/1727352385120.jpg', // Ganti dengan URL gambar thumbnail Anda
                    sourceUrl: '',
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        };
        // Mengirim pesan
        await Yori.sendMessage(m.chat, response, { quoted: m });        
    } catch (e) {
        // Menangani error jika fetch gagal
        return Yorireply("`*Terjadi kesalahan saat memproses permintaan.*`");
    }
}
                break
                case 'gpt': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (!text) return Yorireply(`*Mau Nanya Apa Sama GPT?*`)
                var Yoriai = await fetchJson(`https://widipe.com/prompt/gpt?prompt=Aku%20adalah%20sesosok%20AI%20GPT%20aku%20di%20rancang%20untuk%20membantu%20user%20dalam%20menerima%20pertanyaan%20para%20user%20dan%20aku%20di%20ciptakan%20oleh%20ErerexID%20Chx%20yang%20gemoy&text=${text}`)
                var lenai = Yoriai.result
                await Yorireply(lenai)
            }
                break
         case 'bing': case 'bingai': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (!text) return Yorireply(`*Mau Nanya Apa Sama BingAi?*`)
                Yorireply(mess.wait)
                var Yoriai = await fetchJson(`https://widipe.com/bingai?text=${text}`)
                var lenai = Yoriai.result
                await Yorireply(lenai)
                }
                break
                case 'blackbox': case 'bxai': {
                if (!text) return Yorireply(`*Mau Nanya Apa Sama BingAi?*`)
                Yorireply(mess.wait)
                var Yoriai = await fetchJson(`https://widipe.com/blackbox?text=${text}`)
                var lenai = Yoriai.result
                await Yorireply(lenai)
                }
                break
         case 'turbo': case 'turboai': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (!text) return Yorireply(`*Mau Nanya Apa Sama TurboAi?*`)
                Yorireply(mess.wait)
                var Yoriai = await fetchJson(`https://widipe.com/v2/turbo?text=${text}`)
                var lenai = Yoriai.result
                await Yorireply(lenai)
                }
                break

            case 'gptpicture': {
                if (!text) return Yorireply('masukkan prompt mu!')
                try {
                    let gprompt = await (await fetch(`https://api.shannmoderz.xyz/ai/gptpicture?prompt=${text}`)).json()
                    let Yori = gprompt.result.data.imgs[0]
                    Yori.sendMessage(m.chat, { image: { url: yori }, caption: text }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan query lainnya atau coba lagi nanti')
                }
            }
                break

            case 'gptgo': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (!text) return Yorireply(`*Mau Nanya Apa Sama BingAi?*`)
                Yorireply(mess.wait)
                var Yoriai = await fetchJson(`https://widipe.com/gptgo?text=${text}`)
                var lenai = Yoriai.result
                await Yorireply(lenai)
                }
                break
                
                case "autoai":
    {
      if (!text) {
        let sections = [];
        let list = {
          title: `Yori Chan Asistant Ai`,
          rows: [],
        };
        list.rows.push(
          {
            title: `Enable✅`,
            description: `Turn On Asistant`,
            id: `.autoai on`,
          },
          {
            title: `Disable❌`,
            description: `Turn Off Asistant`,
            id: `.autoai off`,
          }
        );
        sections.push(list);

        let listMsg = {
          title: "Yori Chan Asistant Ai",
          sections,
        };
        Yori.sendList(
          from,
          `Hi Kak ${pushname}`,
          "Yori Asistant Settings",
          listMsg
        );
      } else if (["on", "enable", "1"].includes(args[0])) {
        if (db.data.chats[from].autoai == true)
          return Yorireply(`Udh On Daritadi`);
        Yorireply("Asisten Yori Sekarang Aktif☺");
        db.data.chats[from].autoai = true;
      } else if (["off", "disable", "0"].includes(args[0])) {
        if (db.data.chats[from].autoai == false)
          return Yorireply(`Udh Off Daritadi`);
        Yorireply("Bye👋, Kalo Butuh Teman panggil Yori lagi ya");
        db.data.chats[from].autoai = false;
      }
    }
                break
/*
            case 'bing': {
                if (!q) return Yorireply(`🍃 *Mau Nanya Apa Sama Bing?*`)
                Yorireply('🍃 *Sabar Yaa*')
                var Yoriai = await fetchJson(`https://widipe.com/bingai?text=${q}`)
                var lenai = Yoriai.result
                await Yorireply(lenai)
            }
                break
                */
/*
            case 'gemini': {
                if (!q) return Yorireply(`🍃 *Mau Nanya Apa Sama Gemini?*`)
                Yorireply('🍃 *Sabar Yaa*')
                var Yoriai = await fetchJson(`https://aemt.me/gemini?text=${q}`)
                var lenai = Yoriai.result
                await Yorireply(lenai)
            }
                break
 */               

            case 'img2txt':
                if (!/image/.test(mime)) return Yorireply(`☘️ *Gambarnya Mana?*`)
                if (/image/.test(mime)) {
                    Yorireply(mess.wait)
                    let mee = await Yori.downloadAndSaveMediaMessage(quoted)
                    let mem = await TelegraPh(mee)
                    let len = await (await fetch(`https://itzpire.com/tools/img2text?url=${mem}`)).json()
                    let result = len.result
                    Yori.sendMessage(m.chat, { image: { url: mem }, caption: `${result}` }, { quoted: m })
                }
                break

            case 'img2promt':
                if (!/image/.test(mime)) return Yorireply(`☘️ *Gambarnya Mana?*`)
                if (/image/.test(mime)) {
                    Yorireply(mess.wait)
                    let mee = await Yori.downloadAndSaveMediaMessage(quoted)
                    let mem = await TelegraPh(mee)
                    let len = await (await fetch(`https://itzpire.com/tools/img2prompt?url=${mem}`)).json()
                    let result = len.result
                    Yori.sendMessage(m.chat, { image: { url: mem }, caption: `${result}` }, { quoted: m })
                }
                break

            case 'gemini-img': {
                if (!quoted) return Yorireply('🍃 *Mana Gambarnya?*')
                Yorireply('🍃 *Sabar Yaa*')
                if (!/image/.test(mime)) return Yorireply("⚠️ *Hanya Support Gambar*")
                let media = await Yori.downloadAndSaveMediaMessage(quoted)
                let anu = await TelegraPh(media)
                let { data } = await axios.get("https://gmni.vercel.app/api/img?imageUrl=" + anu + "&prompt=" + text)
                Yorireply(data.text)
            }
                break

            case 'linkgroup': case 'linkgc': {
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                let response = await Yori.groupInviteCode(from)
                Yori.sendText(from, `🍃 *Name Group : ${groupMetadata.subject}*\n\n🎁 *Link Group : https://chat.whatsapp.com/${response}*`, m, { detectLink: true })
            }
                break

            case 'resetlinkgc':
                if (!isAdmins) return Yorireply(mess.admin)
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                Yori.groupRevokeInvite(from)
                break

            case 'sendlinkgc': {
                if (!isCreator) return Yorireply(mess.owner)
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                if (!args[0]) return Yorireply(`Penggunaan ${prefix + command} nomor\nContoh ${prefix + command} 6281363167747`)
                bnnd = text.split("|")[0] + '@s.whatsapp.net'
                let response = await Yori.groupInviteCode(from)
                Yori.sendText(bnnd, `https://chat.whatsapp.com/${response}\n\nLink Group : ${groupMetadata.subject}`, len, { detectLink: true })

            }
                break

            case 'dor':
            case 'kick':
            case 'cilukba': {
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                if (!isAdmins) return Yorireply(mess.admin)
                let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                await Yori.groupParticipantsUpdate(from, [users], 'remove')
            }
                break

            case 'add': {
                if (!isCreator) return Yorireply(mess.owner)
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                if (!isAdmins) return Yorireply(mess.admin)
                let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                await Yori.groupParticipantsUpdate(from, [users], 'add')
            }
                break

            case 'promote': {
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                if (!isAdmins) return Yorireply(mess.admin)
                let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                await Yori.groupParticipantsUpdate(from, [users], 'promote')
            }
                break

            case 'demote': {
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                if (!isAdmins) return Yorireply(mess.admin)
                let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                await Yori.groupParticipantsUpdate(from, [botNumber], 'demote')
            }
                break

            case 'yorr': case 'hidetag': {
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins) return Yorireply(mess.admin)
                Yori.sendMessage(from, { text: q ? q : '', mentions: participants.map(a => a.id) }, { quoted: len })
            }
                break

            case 'mgrup':
            case 'mgroup': {
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins) return Yorireply(mess.admin)
                if (args[0] === 'close') {
                    await Yori.groupSettingUpdate(from, 'announcement').then((res) => Yorireply(`Sukses Menutup Group 🫡`)).catch((err) => Yorireply(jsonformat(err)))
                } else if (args[0] === 'open') {
                    await Yori.groupSettingUpdate(from, 'not_announcement').then((res) => Yorireply(`Sukses Membuka Group 🫡`)).catch((err) => Yorireply(jsonformat(err)))
                } else {
                    Yori.sendMessage(m.chat, {
                        image: ppnyauser, caption: `🍃 *Silahkan Ketik*
Group open
Group close`}, { quoted: m })
                }
            }
                break
              case 'gc': case 'group': case 'grup': {
                let msg = generateWAMessageFromContent(from, {
                    viewOnceMessage: {
                        message: {
                            "messageContextInfo": {
                                "deviceListMetadata": {},
                                "deviceListMetadataVersion": 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: botname
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: botname
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    ...(await prepareWAMessageMedia({ image: fs.readFileSync('./data/image/menu.jpg') }, { upload: Yori.waUploadToServer })),
                                    title: `Silahkan Pilih ${pushname}`,
                                    gifPlayback: true,
                                    subtitle: ownername,
                                    hasMediaAttachment: false
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"Group Open","id":".mgrup open"}`
                                        },
                                        {
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"Group Close","id":".mgrup close"}`
                                        },
                                    ],
                                }),
                                contextInfo: {
                                    mentionedJid: [m.sender],
                                    forwardingScore: 999,
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: '120363204138641225@newsletter',
                                        newsletterName: botname,
                                        serverMessageId: 143
                                    }
                                }
                            })
                        }
                    }
                }, {})

                await Yori.relayMessage(msg.key.remoteJid, msg.message, {
                    messageId: msg.key.id
                })
            }
                break

            case 'editinfo': {
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins) return Yorireply(mess.admin)
                if (args[0] === 'open') {
                    await Yori.groupSettingUpdate(from, 'unlocked').then((res) => Yorireply(`Sukses Membuka Edit Info Group 🫡`)).catch((err) => Yorireply(jsonformat(err)))
                } else if (args[0] === 'close') {
                    await Yori.groupSettingUpdate(from, 'locked').then((res) => Yorireply(`Sukses Menutup Edit Info Group 🫡`)).catch((err) => Yorireply(jsonformat(err)))
                } else {
                    Yori.sendMessage(m.chat, {
                        image: ppnyauser, caption: ` Silahkan Ketik
Editinfo Open
Editinfo Close`}, { quoted: m })

                }
            }
                break

            case 'join': {
                if (!isCreator) return Yorireply(mess.owner)
                if (!text) throw 'Masukkan Link Group!'
                if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) throw 'Link Invalid! 🤔'
                Yorireply('🍃 *Sabar Yaa*')
                let result = args[0].split('https://chat.whatsapp.com/')[1]
                await Yori.groupAcceptInvite(result).then((res) => Yorireply(jsonformat(res))).catch((err) => Yorireply(jsonformat(err)))
            }
                break

            case 'leave': {
                if (!isCreator) return Yorireply(mess.owner)
                Yorireply("Selamat Tinggal 😥")
                await Yori.groupLeave(m.chat).then((res) => Yorireply(jsonformat(res))).catch((err) => Yorireply(jsonformat(err)))
            }
                break

            case 'editsubjek': {
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                if (!isAdmins) return Yorireply(mess.admin)
                if (!text) throw 'Text nya ?'
                await Yori.groupUpdateSubject(from, text).then((res)).catch((err) => Yorireply(jsonformat(err)))
            }
                break
            case 'delgc':

                if (!isCreator) return Yorireply(mess.owner)

                if (!isGroup) return Yorireply(`Khusus Group`)

                var ini = pler.indexOf(m.chat)

                pler.splice(ini, 1)

                fs.writeFileSync('./all/database/idgrup.json', JSON.stringify(pler))

                Yorireply(`${command} Sukses Menonaktifkan Fitur Domain Di Grup Ini`)

                break

            case 'addgc':

                if (!isGroup) return Yorireply(`Khusus Group`)

                if (!isCreator) return Yorireply(mess.owner)

                pler.push(m.chat)

                fs.writeFileSync('./all/database/idgrup.json', JSON.stringify(pler))

                Yorireply(`${command} Sukses Mengaktifkan Fitur Domain Di Grup Ini`)

                break

            case 'editdesk': {
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                if (!isAdmins) return Yorireply(mess.admin)
                if (!text) throw 'Text Nya ?'
                await Yori.groupUpdateDescription(from, text).then((res)).catch((err) => Yorireply(jsonformat(err)))
            }
                break

            case 'tagall': {
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins) return Yorireply(mess.admin)
                let teks = `🍃 *Tag All*
🎁 *Pesan : ${q ? q : 'Kosong'}*\n\n`
                for (let mem of participants) {
                    teks += `⨠ @${mem.id.split('@')[0]}\n`
                }
                Yori.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, { quoted: m })
            }
                break

            case 'creategroup':
            case 'creategc':
                {
                    let eek = m.sender;
                    Yori.sendMessage(m.chat, {
                        react: {
                            text: '⏳',
                            key: m.key
                        }
                    });
                    let pesan = "*Haloo Kak " + pushname + "*\n*Mau Create Group Di YoriBotz?, Langsung saja pilih dibagian list Paket Mingguan  ≧﹏≦*\n";
                    let msg = generateWAMessageFromContent(from, {
                        viewOnceMessage: {
                            message: {
                                messageContextInfo: {
                                    deviceListMetadata: {},
                                    deviceListMetadataVersion: 0x2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: pesan
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: "🚩Jika ragu kami juga mempunyai testimoni yang bisa dilihat sendiri di saluran whatsapp kami maupun instagram ⌓̈⃝୨\n"
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        ...(await prepareWAMessageMedia({
                                            image: fs.readFileSync('./data/image/menu.jpg')
                                        }, { upload: Yori.waUploadToServer })),
                                        title: '',
                                        gifPlayback: true,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            name: 'single_select',
                                            buttonParamsJson: JSON.stringify({
                                                title: "LIST CREATE GROUP",
                                                sections: [{
                                                    title: "PILIH PAKET MANA YG MAU KAMU CREATE GROUP NYA",
                                                    rows: [{
                                                        header: "GROUP 1 MINGGU ✨",
                                                        title: "Click Here!!",
                                                        description: "Group paket 1 Minggu",
                                                        id: "gcreate 1 minggu",
                                                    }, {
                                                        header: "GROUP 2 MINGGU ✨",
                                                        title: "Click Here!!",
                                                        description: "Group Paket 2 Minggu",
                                                        id: "gcreate 2 minggu",
                                                    }, {
                                                        header: "GROUP 3 MINGGU ✨",
                                                        title: "Click Here!!",
                                                        description: "Group Paket 3 Minggu",
                                                        id: "gcreate 3 minggu",
                                                    }]
                                                }]
                                            })
                                        }, {
                                            name: 'quick_reply',
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "PAYMENT💰",
                                                id: prefix + "pembayaran"
                                            })
                                        }, {
                                            name: 'quick_reply',
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "OWNER👥",
                                                id: prefix + "owner"
                                            })
                                        }]
                                    })
                                })
                            }
                        }
                    }, {
                        userJid: from,
                        quoted: m
                    });
                    await Yori.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
                }
                break;
            case 'produkcreator':
                {
                    let eek = m.sender;
                    Yori.sendMessage(m.chat, {
                        react: {
                            text: '⏳',
                            key: m.key
                        }
                    });
                    let pesan = "*Haloo Kak " + pushname + "*\n*Silahkan Pilih List Harga Produk  ≧﹏≦*\n";
                    let msg = generateWAMessageFromContent(from, {
                        viewOnceMessage: {
                            message: {
                                messageContextInfo: {
                                    deviceListMetadata: {},
                                    deviceListMetadataVersion: 0x2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: pesan
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: "© Copyright Yori Chan - 2024 ⌓̈⃝୨\n"
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        ...(await prepareWAMessageMedia({
                                            image: fs.readFileSync('./data/image/menu.jpg')
                                        }, { upload: Yori.waUploadToServer })),
                                        title: '',
                                        gifPlayback: true,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            name: 'single_select',
                                            buttonParamsJson: JSON.stringify({
                                                title: "LIST HARGA PRODUK",
                                                sections: [{
                                                    title: "PILIH HARGA PRODUK DI BAWAH YA KAK 😁✨",
                                                    rows: [{
                                                        header: "Panel Pterodactyl ✨",
                                                        title: "List Harga Menu Pterodactyl !!",
                                                        description: "Harga List",
                                                        id: ".sewapanel",
                                                    }, {
                                                        header: "Nomor Kosong Virtual ✨",
                                                        title: "Click Here!!",
                                                        description: "List Harga Menu Nomor Kosong",
                                                        id: ".listnokos",
                                                    }]
                                                }]
                                            })
                                        }, {
                                            name: 'quick_reply',
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "PAYMENT💰",
                                                id: prefix + "pembayaran"
                                            })
                                        }, {
                                            name: 'quick_reply',
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "OWNER👥",
                                                id: prefix + "owner"
                                            })
                                        }]
                                    })
                                })
                            }
                        }
                    }, {
                        userJid: from,
                        quoted: m
                    });
                    await Yori.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
                }
                break;
            case 'sewa':
            case 'sewabot':
                {
                    let eek = m.sender;
                    Yori.sendMessage(m.chat, {
                        react: {
                            text: '⏳',
                            key: m.key
                        }
                    });
                    let pesan = "*Haloo Kak " + pushname + "*\n*Mau Sewa YoriBotz?, Langsung saja pilih dibagian list sewa ≧﹏≦*\n";
                    let msg = generateWAMessageFromContent(from, {
                        viewOnceMessage: {
                            message: {
                                messageContextInfo: {
                                    deviceListMetadata: {},
                                    deviceListMetadataVersion: 0x2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: pesan
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: "© Yori Chan || New 2023 - 2024"
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        ...(await prepareWAMessageMedia({
                                            image: fs.readFileSync('./data/image/menu.jpg')
                                        }, { upload: Yori.waUploadToServer })),
                                        title: '',
                                        gifPlayback: true,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            name: 'single_select',
                                            buttonParamsJson: JSON.stringify({
                                                title: "LIST SEWA",
                                                sections: [{
                                                    title: "PILIH PAKET MANA YG MAU KAMU BELI",
                                                    rows: [{
                                                        header: "🥉PAKET BRONZE🥉",
                                                        title: "Click Here!!",
                                                        description: "Buy paket Bronze",
                                                        id: ".bronzepaket",
                                                    }, {
                                                        header: "🥈PAKET REGULER🥈",
                                                        title: "Click Here!!",
                                                        description: "Buy paket Reguler",
                                                        id: ".regulerpaket",
                                                    }, {
                                                        header: "🏆PAKET UNLIMITED🏆",
                                                        title: "Click Here!!",
                                                        description: "Buy paket Unli",
                                                        id: ".unlipaket",
                                                    }]
                                                }]
                                            })
                                        }, {
                                            name: 'quick_reply',
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "PAYMENT💰",
                                                id: prefix + "pembayaran"
                                            })
                                        }, {
                                            name: 'quick_reply',
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "OWNER👥",
                                                id: prefix + "owner"
                                            })
                                        }]
                                    })
                                })
                            }
                        }
                    }, {
                        userJid: from,
                        quoted: m
                    });
                    await Yori.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
                }
                break;
            case 'bronzepaket':
                {
                    let list = "*`🥉PAKET BRONZE🥉`*\n\n*⛩️Info pembelian*\n> Name: " + pushname + "\n> Paket: Bronze\n\n*⛩️List Paket Bronze*\n> 3k = 3 Hari\n> 5k = 1 Minggu \n> 7k = 3 Minggu \n*⛩️Keuntungan Sewa Bot:*\n> Jaga Group\n> Game Seru\n> Antilink GC lain\n> Anti Promosi\n\n*🏮Untuk melakukan pembayaran silahkan hubungi owner atau gunakan tombol dibawah*\n";
                    let msg = generateWAMessageFromContent(from, {
                        viewOnceMessage: {
                            message: {
                                messageContextInfo: {
                                    deviceListMetadata: {},
                                    deviceListMetadataVersion: 0x2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: list
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: "🚩Jika ragu kami juga mempunyai testimoni yang bisa dilihat sendiri di saluran whatsapp kami maupun instagram kami\n> " + global.instagram + "⌓̈⃝୨\n"
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        ...(await prepareWAMessageMedia({
                                            image: {
                                                url: "https://telegra.ph/file/2b8b3d38959aa69f748e3.jpg"
                                            }
                                        }, {
                                            upload: Yori.waUploadToServer
                                        })),
                                        title: '',
                                        gifPlayback: true,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            name: 'quick_reply',
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "PAYMENT💰",
                                                id: prefix + "pembayaran"
                                            })
                                        }, {
                                            name: 'cta_url',
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "👤 Beli ( " + global.ownername + " )",
                                                url: "https://wa.me/62895342022385?text=Hai+kak+ererexid+mau+sewa+bot+dong+yang+paket+bronze" + global.ownernumber,
                                                merchant_url: "https://wa.me/62895342022385?text=Hai+kak+ererexid+mau+sewa+bot+dong+yang+paket+bronze" + global.ownernumber
                                            })
                                        }]
                                    })
                                })
                            }
                        }
                    }, {
                        userJid: from,
                        quoted: m
                    });
                    await Yori.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
                }
                break;
            case 'regulerpaket':
                {
                    let list = "*`🥈PAKET REGULER 🥈`*\n\n*⛩️Info pembelian*\n> Name: " + pushname + "\n> Paket: Reguler \n\n*⛩️List Paket Reguler*\n> 20K = 1 Bulan\n> 25k = 2 Bulan\n> 30k = 2 Bulan 7 Hari \n\n*⛩️Keuntungan Sewa Bot:*\n> Jaga Group\n> Game Seru\n> Antilink GC lain\n> Anti Promosi\n> Request Fitur\n> Admin Mendapatkan Premium\n> Welcome Kece\n\n*🏮Untuk melakukan pembayaran silahkan hubungi owner atau gunakan tombol dibawah*\n";
                    let msg = generateWAMessageFromContent(from, {
                        viewOnceMessage: {
                            message: {
                                messageContextInfo: {
                                    deviceListMetadata: {},
                                    deviceListMetadataVersion: 0x2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: list
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: "🚩Jika ragu kami juga mempunyai testimoni yang bisa dilihat sendiri di saluran whatsapp kami maupun instagram kami\n> " + global.instagram + "⌓̈⃝୨\n"
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        ...(await prepareWAMessageMedia({
                                            image: {
                                                url: "https://telegra.ph/file/bfde0ae26b67a1d30dc1d.jpg"
                                            }
                                        }, {
                                            upload: Yori.waUploadToServer
                                        })),
                                        title: '',
                                        gifPlayback: true,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            name: 'quick_reply',
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "PAYMENT💰",
                                                id: prefix + "pembayaran"
                                            })
                                        }, {
                                            name: 'cta_url',
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "👤 Beli ( " + global.ownername + " )",
                                                url: "https://wa.me/62895342022385?text=Hai+kak+ererexid+mau+sewa+bot+dong+yang+paket+reguler" + global.ownernumber,
                                                merchant_url: "https://wa.me/62895342022385?text=Hai+kak+ererexid+mau+sewa+bot+dong+yang+paket+reguler" + global.ownernumber
                                            })
                                        }]
                                    })
                                })
                            }
                        }
                    }, {
                        userJid: from,
                        quoted: m
                    });
                    await Yori.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
                }
                break;
            case 'unlipaket':
                {
                    let list = "*`🏆PAKET UNLIMITED 🏆`*\n\n*⛩️Info pembelian*\n> Name: " + pushname + "\n> Paket: Unlimited \n\n*⛩️Harga Paket Unlimited*\n> 50k = Permanen\n> 65k = Permanen + Premium\n\n*⛩️Keuntungan Sewa Bot:*\n> Jaga Group\n> Game Seru\n> Antilink GC lain\n> Anti Promosi\n> Request Fitur\n> Admin Mendapatkan Premium\n> Welcome Kece\n> Limit Unlimited\n> Unlock Semua Fitur\n> Dapet Update lebih cepat\n\n*🏮Untuk melakukan pembayaran silahkan hubungi owner atau gunakan tombol dibawah*\n";
                    let msg = generateWAMessageFromContent(from, {
                        viewOnceMessage: {
                            message: {
                                messageContextInfo: {
                                    deviceListMetadata: {},
                                    deviceListMetadataVersion: 0x2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: list
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: "🚩Jika ragu kami juga mempunyai testimoni yang bisa dilihat sendiri di saluran whatsapp kami maupun instagram kami\n> " + global.instagram + "⌓̈⃝୨\n"
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        ...(await prepareWAMessageMedia({
                                            image: {
                                                url: "https://telegra.ph/file/4764dd8d71dec0d270b6f.jpg"
                                            }
                                        }, {
                                            upload: Yori.waUploadToServer
                                        })),
                                        title: '',
                                        gifPlayback: true,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            name: 'quick_reply',
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "PAYMENT💰",
                                                id: prefix + "pembayaran"
                                            })
                                        }, {
                                            name: 'cta_url',
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "👤 Beli ( " + global.ownername + " )",
                                                url: "https://wa.me/62895342022385?text=Hai+kak+ererexid+mau+sewa+bot+dong+yang+paket+unli" + global.ownernumber,
                                                merchant_url: "https://wa.me/62895342022385?text=Hai+kak+ererexid+mau+sewa+bot+dong+yang+paket+unli" + global.ownernumber
                                            })
                                        }]
                                    })
                                })
                            }
                        }
                    }, {
                        userJid: from,
                        quoted: m
                    });
                    await Yori.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
                }
                break;

            case 'stiker': case 'sticker': case 's': case 'stickers': case 'sgif': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                if (!quoted) Yorireply`Balas Video/Image Dengan Caption ${prefix + command}`
                if (/image/.test(mime)) {
                    let media = await quoted.download()
                    let encmedia = await Yori.sendImageAsSticker(from, media, m, { packname: global.packname, author: global.author })
                    await fs.unlinkSync(encmedia)
                } else if (/video/.test(mime)) {
                    if ((quoted.msg || quoted).seconds > 11) return Yorireply('Maksimal 10 detik!')
                    let media = await quoted.download()
                    let encmedia = await Yori.sendVideoAsSticker(from, media, m, { packname: global.packname, author: global.author })
                    await fs.unlinkSync(encmedia)
                } else {
                    Yorireply(`🍃 *Kirim Gambar/Video Yang Ingin Dijadikan Sticker*\n⚠️ *Durasi VIdeo Minimal 1 - 9 Detik*`)
                }
            }
                break

            case 'animekiss': {
                await Yorireply(mess.wait)
                waifudd = await axios.get(`https://nekos.life/api/v2/img/kiss`)
                await Yori.sendMessage(m.chat, { image: { url: waifudd.data.url }, caption: mess.success }, { quoted: m }).catch(err => {
                    return ('Error!')
                })
            }
                break

            case 'inspect': {
                if (isBan) return Yorireply('*Lu Di Ban Owner*')
                YoriLD()
                if (!args[0]) return Yorireply("Linknya?")
                let linkRegex = args.join(" ")
                let coded = linkRegex.split("https://chat.whatsapp.com/")[1]
                if (!coded) return Yorireply("Link Invalid 🤔")
                Yori.query({
                    tag: "iq",
                    attrs: {
                        type: "get",
                        xmlns: "w:g2",
                        to: "@g.us"
                    },
                    content: [{ tag: "invite", attrs: { code: coded } }]
                }).then(async (res) => {
                    tekse = `🍃 *Group Link Yang Di Inspect*

 *⨠ Nama Group : ${res.content[0].attrs.subject ? res.content[0].attrs.subject : "undefined"}*
 *⨠ Deskripsi Di Ubah : ${res.content[0].attrs.s_t ? moment(res.content[0].attrs.s_t * 1000).tz("Asia/Jakarta").format("DD-MM-YYYY, HH:mm:ss") : "undefined"}*
 *⨠ Pembuat Group : ${res.content[0].attrs.creator ? "@" + res.content[0].attrs.creator.split("@")[0] : "undefined"}*
 *⨠ Group Di Buat : ${res.content[0].attrs.creation ? moment(res.content[0].attrs.creation * 1000).tz("Asia/Jakarta").format("DD-MM-YYYY, HH:mm:ss") : "undefined"}*
 *⨠ Total Member : ${res.content[0].attrs.size ? res.content[0].attrs.size : "undefined"} Member*

*⨠ ID Group  : ${res.content[0].attrs.id ? res.content[0].attrs.id : "undefined"}*
🎁 *By ${botname}*`
                    try {
                        pp = await Yori.profilePictureUrl(res.content[0].attrs.id + "@g.us", "image")
                    } catch {
                        pp = "https://tse2.mm.bing.net/th?id=OIP.n1C1oxOvYLLyDIavrBFoNQHaHa&pid=Api&P=0&w=153&h=153"
                    }
                    Yori.sendFile(from, pp, "", m, { caption: tekse, mentions: await Yori.parseMention(tekse) })

                })
            }
                break

     case 'ping':
       case 'speed':
         case 'speeds':
          case 'botstatus':
           case 'statusbot': {
             const used = process.memoryUsage()
             const cpus = os.cpus().map(cpu => {
cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
    return cpu
   })
             const cpu = cpus.reduce((last, cpu, _, {
   length
}) => {
last.total += cpu.total
last.speed += cpu.speed / length
last.times.user += cpu.times.user
last.times.nice += cpu.times.nice
last.times.sys += cpu.times.sys
last.times.idle += cpu.times.idle
last.times.irq += cpu.times.irq
return last
}, {
speed: 0,
total: 0,
times: {
user: 0,
nice: 0,
sys: 0,
idle: 0,
irq: 0
}
})
let timestamp = speed()
let latensi = speed() - timestamp
neww = performance.now()
oldd = performance.now()
respon = `
*_ᴋᴇᴄᴇᴘᴀᴛᴀɴ ʀᴇsᴘᴏɴ : ${latensi.toFixed(4)} ᴅᴇᴛɪᴋ_* \n *_${oldd - neww} ᴍɪʟɪᴅᴇᴛɪᴋ_*\n*_ʀᴜɴᴛɪᴍᴇ : ${runtime(process.uptime())}_*

*ɪɴғᴏ sᴇʀᴠᴇʀ*
 *⨠ ʀᴀᴍ : ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}*

${cpus[0] ? `*ᴛᴏᴛᴀʟ ᴄᴘᴜ ᴜsᴀɢᴇ*\n *⨠ ${cpus[0].model.trim()} (${cpu.speed} MHZ)*\n${Object.keys(cpu.times).map(type => ` *⨠ ${(type + '*').padEnd(6)}: *${(100 * cpu.times[type] / cpu.total).toFixed(2)}%*`).join('\n')}
 *⨠ CPU Core(s) Usage (${cpus.length} Core CPU)*` : ''}
`.trim()
await Yori.sendMessage(m.chat, {
text: respon,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
title: 'ᴋᴇᴄᴇᴘᴇᴛᴀɴ sʏsᴛᴇᴍ ʏᴏʀɪ ᴄʜᴀɴ ʙᴏᴛᴢ',
body: `${latensi.toFixed(4)} sᴇᴄᴏɴᴅ`,
thumbnailUrl: 'https://widipe.com/file/ojUtb3QgX1pW.jpg',
sourceUrl: global.link,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, {
quoted: len
})
}
                break

            case 'bcgc': case 'bcgroup': {
                if (!isCreator) return Yorireply(mess.owner)
                YoriLD()
                if (!text) Yorireply`🍃 *Contoh : ${prefix + command} Subscribe Nakano Ai*`
                let getGroups = await Yori.groupFetchAllParticipating()
                let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
                let anu = groups.map(v => v.id)
                for (let i of anu) {
                    await sleep(1500)
                    Yori.sendMessage(i, { text: `${text}` }, { quoted: len })
                }
                Yorireply(`🍃 Sukses Mengirim Broadcast Ke ${anu.length} Group`)
            }
                break

            case 'bcimg': case 'bcvid': case 'bcvideo': case 'share': {
                if (!isCreator) return Yorireply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
                if (m.isGroup) return Yorireply(mess.private)
                if (!text) return Yorireply(`*Penggunaan Salah Silahkan Gunakan Seperti Ini*\n${prefix + command} teks\n\nYoriReply Gambar Untuk Mengirim Gambar Ke Semua Group`)
                Yorireply(mess.wait)
                let getGroups = await Yori.groupFetchAllParticipating()
                let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
                let anu = groups.map((v) => v.id)
                global.teksjpm = text
                for (let xnxx of anu) {
                    let metadat72 = await Yori.groupMetadata(xnxx)
                    let participanh = await metadat72.participants
                    if (/image/.test(mime)) {
                        media = await Yori.downloadAndSaveMediaMessage(quoted)
                        mem = await uptotelegra(media)
                        await Yori.sendMessage(xnxx, { image: { url: mem }, caption: global.teksjpm, contextInfo: { mentionedJid: participanh.map(a => a.id) } }, { quoted: len })
                        await sleep(2000)
                    } else {
                        if (/video/.test(mime)) {
                            media1 = await Yori.downloadAndSaveMediaMessage(quoted)
                            mem1 = await uptotelegra(media1)
                            await Yori.sendMessage(xnxx, { video: { url: mem1 }, caption: global.teksjpm, contextInfo: { mentionedJid: participanh.map(a => a.id) } }, { quoted: len })
                            await sleep(2000)
                        } else {
                            await Yori.sendMessage(xnxx, { text: global.teksjpm, contextInfo: { mentionedJid: participanh.map(a => a.id) } }, { quoted: len })
                            await sleep(2000)
                        }
                    }
                }
            }
                break
/*
            case 'antitoxic': {
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins && !isCreator) return Yorireply(mess.admin)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].Yori_antitoxic) return Yorireply(`📣 *Anti Toxic Sudah Aktif*`)
                    db.data.chats[m.chat].Yori_antitoxic = true
                    Yorireply(`📣 *Anti Toxic Diaktifkan Didalam Group*`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].Yori_antitoxic) return Yorireply(`⚠️ *Anti Toxic Sudah Dinonaktifkan*`)
                    db.data.chats[m.chat].Yori_antitoxic = false
                    Yorireply(`⚠️ *Anti Toxic Dinonaktifkan Didalam Group*`)
                } else {
                    Yorireply(`Mode ${command}\n\n\nKetik ${prefix + command} on/off`)
                }
            }
                break
                */

            case 'antilinkgcv1': {
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins && !isCreator) return Yorireply(mess.admin)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].Yori_antigc) return Yorireply(`🍃 *Autokick Link Gc Aktif*`)
                    db.data.chats[m.chat].Yori_antigc = true
                    Yorireply(`🍃 *Autokick Link Gc Aktif*`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].Yori_antigc) return Yorireply(`🍃 *Autokick Link Gc Di Nonatifkan*`)
                    db.data.chats[m.chat].Yori_antigc = false
                    Yorireply(`🍃 *Autokick Nonaktif*`)
                } else {
                    Yorireply(`🍃 *Ketik Antilinkgcv1 on/off*`)
                }
            }
                break

            case 'antilinkgc':
                if (!isAdmins) return Yorireply('🍃 *Kamu Bukan Admin Group*')
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return Yorireply(mess.admin)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                if (args.length < 1) return Yorireply(`🍃 *Contoh ${prefix + command} on/off*`)
                if (q == 'on') {
                    global.db.data.chats[m.chat].Yori_antigc2 = true
                    Yorireply(`🍃 *Berhasil Mengaktifkan Anti Link Group*\n🎁 *Ketik Antilinkgcv1 Untuk Mengaktifkan Autokick*`)
                } else if (q == 'off') {
                    global.db.data.chats[m.chat].Yori_antigc2 = false
                    Yorireply(`🍃 *Berhasil Mematikan Anti Link Group *`)
                }
                break

            case 'antiwame':
                if (!isAdmins) return Yorireply('🍃 *Kamu Bukan Admin Group*')
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return Yorireply(mess.admin)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                if (args.length < 1) return Yorireply(`🍃 *Contoh ${prefix + command} on/off*`)
                if (q == 'on') {
                    global.db.data.chats[m.chat].Yori_antiwame = true
                    Yorireply(`🍃 *Berhasil Mengaktifkan Anti Chat Wame*`)
                } else if (q == 'off') {
                    global.db.data.chats[m.chat].Yori_antiwame = false
                    Yorireply(`🍃 *Berhasil Mematikan Anti Chat Wame*`)
                }
                break

            case 'antilink':
                if (!isAdmins) return Yorireply('🍃 *Kamu Bukan Admin Group*')
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return Yorireply(mess.admin)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                if (args.length < 1) return Yorireply(`🍃 *Contoh ${prefix + command} on/off*`)
                if (q == 'on') {
                    global.db.data.chats[m.chat].Yori_antilink = true
                    Yorireply(`🍃 *Berhasil Mengaktifkan Anti Link*`)
                } else if (q == 'off') {
                    global.db.data.chats[m.chat].Yori_antilink = false
                    Yorireply(`🍃 *Berhasil Mematikan Anti Link*`)
                }
                break

            case 'antipanel':
                if (!isAdmins) return Yorireply('🍃 *Kamu Bukan Admin Group*')
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return Yorireply(mess.admin)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                if (args.length < 1) return Yorireply(`🍃 *Contoh ${prefix + command} on/off*`)
                if (q == 'on') {
                    global.db.data.chats[m.chat].Yori_antipanel = true
                    Yorireply(`🍃 *Berhasil Mengaktifkan Anti Promosi Panel*`)
                } else if (q == 'off') {
                    global.db.data.chats[m.chat].Yori_antipanel = false
                    Yorireply(`🍃 *Berhasil Mematikan Anti Promosi Panel*`)
                }
                break

            case 'antilinktt':
                if (!isAdmins) return Yorireply('🍃 *Kamu Bukan Admin Group*')
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return Yorireply(mess.admin)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                if (args.length < 1) return Yorireply(`🍃 *Contoh ${prefix + command} on/off*`)
                if (q == 'on') {
                    global.db.data.chats[m.chat].Yori_antitiktok = true
                    Yorireply(`🍃 *Berhasil Mengaktifkan Anti Link Tiktok*`)
                } else if (q == 'off') {
                    global.db.data.chats[m.chat].Yori_antitiktok = false
                    Yorireply(`🍃 *Berhasil Mematikan Anti Link Tiktok*`)
                }
                break

            case 'antilinkyt':
                if (!isAdmins) return Yorireply('🍃 *Kamu Bukan Admin Group*')
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return Yorireply(mess.admin)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                if (args.length < 1) return Yorireply(`🍃 *Contoh ${prefix + command} on/off*`)
                if (q == 'on') {
                    global.db.data.chats[m.chat].Yori_antiyoutube = true
                    Yorireply(`🍃 *Berhasil Mengaktifkan Anti Link Youtube*`)
                } else if (q == 'off') {
                    global.db.data.chats[m.chat].Yori_antiyoutube = false
                    Yorireply(`🍃 *Berhasil Mematikan Anti Link Youtube*`)
                }
                break

            case 'antich':
                if (!isAdmins) return Yorireply('🍃 *Kamu Bukan Admin Group*')
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return Yorireply(mess.admin)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                if (args.length < 1) return Yorireply(`🍃 *Contoh ${prefix + command} on/off*`)
                if (q == 'on') {
                    global.db.data.chats[m.chat].Yori_antich = true
                    Yorireply(`🍃 *Berhasil Mengaktifkan Anti Link Channel Wa*`)
                } else if (q == 'off') {
                    global.db.data.chats[m.chat].Yori_antich = false
                    Yorireply(`🍃 *Berhasil Mematikan Anti Link Channel Wa*`)
                }
                break

            case 'yoripro':
                if (!isAdmins) return Yorireply('🍃 *Kamu Bukan Admin Group*')
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return Yorireply(mess.admin)
                if (!isBotAdmins) return Yorireply(mess.botAdmin)
                if (args.length < 1) return Yorireply(`🍃 *Contoh NakanoPro on/off*`)
                if (q == 'on') {
                    global.db.data.chats[m.chat].Yori_antich = true
                    global.db.data.chats[m.chat].Yori_antigc2 = true
                    db.data.chats[m.chat].Yori_antigc = true
                    Yorireply(`🍃 *YoriPro Berhasil Diaktifkan Didalam Group*`)
                } else if (q == 'off') {
                    global.db.data.chats[m.chat].Yori_antich = false
                    global.db.data.chats[m.chat].Yori_antigc2 = false
                    db.data.chats[m.chat].Yori_antigc = false
                    Yorireply(`⚠️ *YoriPro Dinonaktifkan Dalam Group!*`)
                }
                break

            case 'autoread':
            if (!isCreator) return Yorireply(mess.owner)
            if (args.length < 1) return Yorireply(`Contoh ${prefix + command} on/off`)
            if (q === 'on'){
            global.db.data.settings[botNumber].autoread = true
            Yorireply(`Berhasil mengubah autoread ke ${q}`)
            } else if (q === 'off'){
            global.db.data.settings[botNumber].autoread = false
            Yorireply(`Berhasil mengubah autoread ke ${q}`)
            }
                break
            case 'checkucp': {
                const con = require('./lib/mysql.js');

                const akun = args[0];
                if (!akun) return Yorireply('Masukkan nama akun');

                con.query(`SELECT * FROM whitelist WHERE username = ?`, [akun], (err, res) => {
                    if (err) return console.log(err);

                    if (res.length > 0) {
                        const { pin } = res[0];
                        Yorireply(`*===[ DATA AKUN UCP ]===*
UCP: ${akun}
PIN: ${pin}
=====================================
        *☢️WARNING☢️*
Tidak Boleh Membagikan Pin Ke Orang
Lain, Jika Melakukan Akan Terkena
        Sanksi (Banned)!!!
=====================================`);
                    } else {
                        Yorireply(`*Akun dengan nama ${akun} belum terdaftar!*`);
                    }
                });
            }
                break;

            case 'daftarucp': {
                const con = require('./lib/mysql.js');

                //  if (!isCreator) return await Yori.sendMessage(m.chat, {"text": "Hanya bisa dilakukan oleh owner!"}, { quoted: m });
                const akun = args[0];
                if (!akun) return Yorireply("Masukkan nama akun!");

                con.query(`SELECT * FROM whitelist WHERE username = ?`, [akun], (err, res) => {
                    if (err) return console.log(err);

                    if (res.length === 0) {
                        const pin = Math.floor(Math.random() * 99999) + 1;
                        const masukanNama = `INSERT INTO whitelist(username, pin) VALUES (?, ?)`;
                        con.query(masukanNama, [akun, pin], (err, res) => {
                            if (err) return console.log(err);

                            Yorireply(`*Berhasil menambahkan akun ${akun} ke database!*`);
                        });
                    } else {
                        Yorireply(`*Akun dengan nama ${akun} sudah terdaftar!*`);
                    }
                });
            }
                break;


            case 'call':
                if (!isCreator) return Yorireply('*Khusus Owner*')
                YoriLD()
                if (!args[0]) return Yorireply(`Penggunaan ${prefix + command} nomor\nContoh ${prefix + command} +6281363167747`)
                let nosend = "+" + text.split("|")[0].replace(/[^0-9]/g, '')
                if (args[0].startsWith(`+6281363167747`)) return Yorireply('Tidak bisa call ke nomor ini!')
                axios.post('https://magneto.api.halodoc.com/api/v1/users/authentication/otp/requests', { 'phone_number': `${nosend}`, 'channel': 'voice' }, { headers: { 'authority': 'magneto.api.halodoc.com', 'accept-language': 'id,en;q=0.9,en-GB;q=0.8,en-US;q=0.7', 'cookie': '_gcl_au=1.1.1860823839.1661903409; _ga=GA1.2.508329863.1661903409; afUserId=52293775-f4c9-4ce2-9002-5137c5a1ed24-p; XSRF-TOKEN=12D59ACD8AA0B88A7ACE05BB574FAF8955D23DBA28E8EE54F30BCB106413A89C1752BA30DC063940ED30A599C055CC810636; _gid=GA1.2.798137486.1664887110; ab.storage.deviceId.1cc23a4b-a089-4f67-acbf-d4683ecd0ae7=%7B%22g%22%3A%2218bb4559-2170-9c14-ddcd-2dc80d13c3e3%22%2C%22c%22%3A1656491802961%2C%22l%22%3A1664887110254%7D; amp_394863=nZm2vDUbDAvSia6NQPaGum...1gehg2efd.1gehg3c19.f.0.f; ab.storage.sessionId.1cc23a4b-a089-4f67-acbf-d4683ecd0ae7=%7B%22g%22%3A%22f1b09ad8-a7d9-16f3-eb99-a97ba52677d2%22%2C%22e%22%3A1664888940400%2C%22c%22%3A1664887110252%2C%22l%22%3A1664887140400%7D', 'origin': 'https://www.halodoc.com', 'sec-ch-ua': '"Microsoft Edge";v="105", "Not)A;Brand";v="8", "Chromium";v="105"', 'sec-ch-ua-mobile': '?0', 'sec-ch-ua-platform': '"Windows"', 'sec-fetch-dest': 'empty', 'sec-fetch-mode': 'cors', 'sec-fetch-site': 'same-site', 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.53', 'x-xsrf-token': '12D59ACD8AA0B88A7ACE05BB574FAF8955D23DBA28E8EE54F30BCB106413A89C1752BA30DC063940ED30A599C055CC810636' } }).then(function (response) { Yorireply(`${JSON.stringify(response.data, null, 2)}`) }).catch(function (error) { Yorireply(`${JSON.stringify(error, null, 2)}`) })
                break

            case 'sms': {
                if (!isCreator) return Yorireply('*Khusus Owner*')
                YoriLD()
                const froms = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                if (m.quoted || text) {
                    if (froms.startsWith('08')) return Yorireply('Awali nomor dengan +62')
                    if (froms == owner) return Yorireply('Tidak bisa spam ke nomor ini!')
                    let nosms = '+' + froms.replace('@s.whatsapp.net', '')
                    let mal = ["Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v7108827108815046027 t6205049005192687891", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1692361810532096513 t9071033982482470646", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v4466439914708508420 t8068951106021062059", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v8880767681151577953 t8052286838287810618", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36 RuxitSynthetic/1.0 v6215776200348075665 t6662866128547677118", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1588190262877692089 t2919217341348717815", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v5330150654511677032 t9071033982482470646", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 11; vivo 2007) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Safari/537.36"]
                    let ua = mal[Math.floor(Math.random() * mal.length)];
                    let axios = require('axios').default;
                    let hd = {
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
                    };
                    const dat = {
                        'phone': nosms
                    };
                    for (let x = 0; x < 100; x++) {
                        axios.post('https://api.myfave.com/api/fave/v1/auth', dat, {
                            headers: hd
                        }).then(res => {
                            console.log(res);
                        }).catch(err => {
                            console.log(`[${new Date().toLocaleTimeString()}] Spam (SMS) BY len MODS`);
                        });
                    }
                } else Yorireply(`Penggunaan spamsms nomor/Balas pesan target*\nContoh spamsms +628xxxxxxxxx`)
                Yorireply(`spam sms/call akan di kirim ke no target`)
            }
                break

            case 'flaming': {
                if (args.length == 0) return Yorireply(`🍃 *Mana Teksnya?*`)
                Yorireply(mess.wait)
                let Yori_txt = args.join(" ")
                var Yorihasil = `https://api.loviecho.biz.id/api/photooxy/realistic-flaming-text-effect?api_key=sk-qpic1vg2czjkv0pto&text=${Yori_txt}`
                Yori.sendMessage(from, { image: { url: Yorihasil }, caption: `${mess.success}` }, { quoted: m })
                    .catch((err) => Yorireply('⚠️ *Kayaknya Ada Yang Error*'))
            }
                break

            case 'stars': {
                if (args.length == 0) return Yorireply(`🍃 *Mana Teksnya?*`)
                Yorireply(mess.wait)
                let Yori_txt = args.join(" ")
                var Yorihasil = `https://api.loviecho.biz.id/api/photooxy/write-stars-text-on-the-night-sky?api_key=sk-qpic1vg2czjkv0pto&text=${Yori_txt}`
                Yori.sendMessage(from, { image: { url: Yorihasil }, caption: `${mess.success}` }, { quoted: m })
                    .catch((err) => Yorireply('⚠️ *Kayaknya Ada Yang Error*'))
            }
                break

            case 'shadow': {
                if (args.length == 0) return Yorireply(`🍃 *Mana Teksnya?*`)
                Yorireply(mess.wait)
                let Yori_txt = args.join(" ")
                var Yorihasil = `https://api.loviecho.biz.id/api/photooxy/shadow-text-effect-in-the-sky?api_key=sk-qpic1vg2czjkv0pto&text=${Yori_txt}`
                Yori.sendMessage(from, { image: { url: Yorihasil }, caption: `${mess.success}` }, { quoted: m })
                    .catch((err) => Yorireply('⚠️ *Kayaknya Ada Yang Error*'))
            }
                break

            case 'cartoonstyle': {
                if (!text) return Yorireply('masukkan text nya!')
                try {
let p = await (await fetch(`https://api.shannmoderz.xyz/ephoto360/cartoonstyle?query=${text}`)).json()
let pp = p.result
                    Yori.sendMessage(m.chat, { image: { url: pp }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'glitchtext': {                
                if (!text) return Yorireply('masukkan text nya!')
                try {
let p = await (await fetch(`https://api.shannmoderz.xyz/ephoto360/glitchtext?query=${text}`)).json()
let pp = p.result
                    Yori.sendMessage(m.chat, { image: { url: pp }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'writetext': {
                if (!text) return Yorireply('masukkan text nya!')
                try {
let p = await (await fetch(`https://api.shannmoderz.xyz/ephoto360/writetext?query=${text}`)).json()
let pp = p.result
                    Yori.sendMessage(m.chat, { image: { url: pp }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'bpl': case 'blackpinklogo': {
                if (!text) return Yorireply('masukkan text nya!')
                try {
let p = await (await fetch(`https://api.shannmoderz.xyz/ephoto360/blackpinklogo?query=${text}`)).json()
let pp = p.result
                    Yori.sendMessage(m.chat, { image: { url: pp }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'advancedglow': {            
                if (!text) return Yorireply('masukkan text nya!')
                try {
let p = await (await fetch(`https://api.shannmoderz.xyz/ephoto360/advancedglow?query=${text}`)).json()
let pp = p.result
                    Yori.sendMessage(m.chat, { image: { url: pp }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'typographytext': {          
                if (!text) return Yorireply('masukkan text nya!')
                try {
let p = await (await fetch(`https://api.shannmoderz.xyz/ephoto360/typographytext?query=${text}`)).json()
let pp = p.result
                    Yori.sendMessage(m.chat, { image: { url: pp }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'pixelglitch': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/pixelglitch?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'neonglitch': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/neonglitch?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'flag': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/flag?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'flag2': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/flag2?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'deletingtext': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/deletingtext?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'blackpinkstyle': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/blackpinkstyle?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'glowingtext': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/glowingtext?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'underwater': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/glitchtext?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'logomaker': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/logomaker?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'papercut': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/papercut?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'watercolor': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/watercolor?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'effectclouds': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/effectclouds?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'gradienttext': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/gradienttext?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'summerbeach': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/summerbeach?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'luxurygold': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/luxurygold?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'multicolored': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/multicolored?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'sandsummer': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/sandsummer?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'galaxy': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/galaxy?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case '1917style': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/1917style?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'makingneon': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/makingneon?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'royaltext': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/royaltext?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'texteffect': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/texteffect?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'galaxystyle': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/galaxystyle?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'lighteffect': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/lighteffect?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break
            case 'burnpaper': {
                if (args.length == 0) return Yorireply(`🍃 *Mana Teksnya?*`)
                Yorireply(mess.wait)
                let Yori_txt = args.join(" ")
                var Yorihasil = `https://api.loviecho.biz.id/api/photooxy/write-text-on-burn-paper?api_key=sk-qpic1vg2czjkv0pto&text=${Yori_txt}`
                Yori.sendMessage(from, { image: { url: Yorihasil }, caption: `${mess.success}` }, { quoted: m })
                    .catch((err) => Yorireply('⚠️ *Kayaknya Ada Yang Error*'))
            }
                break

            case 'grass': {
                if (args.length == 0) return Yorireply(`🍃 *Mana Teksnya?*`)
                Yorireply(mess.wait)
                let Yori_txt = args.join(" ")
                var Yorihasil = `https://api.loviecho.biz.id/api/photooxy/make-quotes-under-grass?api_key=sk-qpic1vg2czjkv0pto&text=${Yori_txt}`
                Yori.sendMessage(from, { image: { url: Yorihasil }, caption: `${mess.success}` }, { quoted: m })
                    .catch((err) => Yorireply('⚠️ *Kayaknya Ada Yang Error*'))
            }
                break

            case 'underwater': {
                if (!text) return Yorireply('masukkan text nya!, Contoh : Yori Chan')
                try {
                    Yori.sendMessage(m.chat, { image: { url: `https://api.shannmoderz.xyz/ephoto360/underwater?query=${text}` }, caption: `>//< Selesai Kak` }, { quoted: m })
                } catch (err) {
                    Yorireply('masukkan text lainnya atau coba lagi nanti')
                }
            }
                break

            case 'whitecube': {
                if (args.length == 0) return Yorireply(`🍃 *Mana Teksnya?*`)
                Yorireply(mess.wait)
                let Yori_txt = args.join(" ")
                var Yorihasil = `https://api.loviecho.biz.id/api/photooxy/3d-text-effect-under-white-cube?api_key=sk-qpic1vg2czjkv0pto&text=${Yori_txt}`
                Yori.sendMessage(from, { image: { url: Yorihasil }, caption: `${mess.success}` }, { quoted: m })
                    .catch((err) => Yorireply('⚠️ *Kayaknya Ada Yang Error*'))
            }
                break

            case 'smokyneon': {
                if (args.length == 0) return Yorireply(`🍃 *Mana Teksnya?*`)
                Yorireply(mess.wait)
                let Yori_txt = args.join(" ")
                var Yorihasil = `https://api.loviecho.biz.id/api/photooxy/make-smoky-neon-glow-effect?api_key=sk-qpic1vg2czjkv0pto&text=${Yori_txt}`
                Yori.sendMessage(from, { image: { url: Yorihasil }, caption: `${mess.success}` }, { quoted: m })
                    .catch((err) => Yorireply('⚠️ *Kayaknya Ada Yang Error*'))
            }
                break

            case 'fabric': {
                if (args.length == 0) return Yorireply(`🍃 *Mana Teksnya?*`)
                Yorireply(mess.wait)
                let Yori_txt = args.join(" ")
                var Yorihasil = `https://api.loviecho.biz.id/api/photooxy/army-camouflage-fabric-text-effect?api_key=sk-qpic1vg2czjkv0pto&text=${Yori_txt}`
                Yori.sendMessage(from, { image: { url: Yorihasil }, caption: `${mess.success}` }, { quoted: m })
                    .catch((err) => Yorireply('⚠️ *Kayaknya Ada Yang Error*'))
            }
                break

            case 'glowing': {
                if (args.length == 0) return Yorireply(`🍃 *Mana Teksnya?*`)
                Yorireply(mess.wait)
                let Yori_txt = args.join(" ")
                var Yorihasil = `https://api.loviecho.biz.id/api/photooxy/create-a-3d-glowing-text-effect?api_key=sk-qpic1vg2czjkv0pto&text=${Yori_txt}`
                Yori.sendMessage(from, { image: { url: Yorihasil }, caption: `${mess.success}` }, { quoted: m })
                    .catch((err) => Yorireply('⚠️ *Kayaknya Ada Yang Error*'))
            }
                break

            case 'honey': {
                if (args.length == 0) return Yorireply(`🍃 *Mana Teksnya?*`)
                Yorireply(mess.wait)
                let Yori_txt = args.join(" ")
                var Yorihasil = `https://api.loviecho.biz.id/api/photooxy/honey-text-effect?api_key=sk-qpic1vg2czjkv0pto&text=${Yori_txt}`
                Yori.sendMessage(from, { image: { url: Yorihasil }, caption: `${mess.success}` }, { quoted: m })
                    .catch((err) => Yorireply('⚠️ *Kayaknya Ada Yang Error*'))
            }
                break

            case 'vintage': {
                if (args.length == 0) return Yorireply(`🍃 *Mana Teksnya?*`)
                Yorireply(mess.wait)
                let Yori_txt = args.join(" ")
                var Yorihasil = `https://api.loviecho.biz.id/api/photooxy/vintage-text-style?api_key=sk-qpic1vg2czjkv0pto&text=${Yori_txt}`
                Yori.sendMessage(from, { image: { url: Yorihasil }, caption: `${mess.success}` }, { quoted: m })
                    .catch((err) => Yorireply('⚠️ *Kayaknya Ada Yang Error*'))
            }
                break

            case 'gradient': {
                if (args.length == 0) return Yorireply(`🍃 *Mana Teksnya?*`)
                Yorireply(mess.wait)
                let Yori_txt = args.join(" ")
                var Yorihasil = `https://api.loviecho.biz.id/api/photooxy/gradient-avatar-text-effect?api_key=sk-qpic1vg2czjkv0pto&text=${Yori_txt}`
                Yori.sendMessage(from, { image: { url: Yorihasil }, caption: `${mess.success}` }, { quoted: m })
                    .catch((err) => Yorireply('⚠️ *Kayaknya Ada Yang Error*'))
            }
                break

            case 'fur': {
                if (args.length == 0) return Yorireply(`🍃 *Mana Teksnya?*`)
                Yorireply(mess.wait)
                let Yori_txt = args.join(" ")
                var Yorihasil = `https://api.loviecho.biz.id/api/photooxy/fur-text-effect-generator?api_key=sk-qpic1vg2czjkv0pto&text=${Yori_txt}`
                Yori.sendMessage(from, { image: { url: Yorihasil }, caption: `${mess.success}` }, { quoted: m })
                    .catch((err) => Yorireply('⚠️ *Kayaknya Ada Yang Error*'))
            }
                break

            case 'striking': {
                if (args.length == 0) return Yorireply(`🍃 *Mana Teksnya?*`)
                Yorireply(mess.wait)
                let Yori_txt = args.join(" ")
                var Yorihasil = `https://api.loviecho.biz.id/api/photooxy/striking-3d-text-effect?api_key=sk-qpic1vg2czjkv0pto&text=${Yori_txt}`
                Yori.sendMessage(from, { image: { url: Yorihasil }, caption: `${mess.success}` }, { quoted: m })
                    .catch((err) => Yorireply('⚠️ *Kayaknya Ada Yang Error*'))
            }
                break
/*
            case 'cuaca': {
                if (!text) return Yorireply('🍃 *Mana Lokasinya?*')
                Yorireply('🍃 *Sabar Yaa*')
                let wdata = await axios.get(
                    `https://api.openweathermap.org/data/2.5/weather?q=${text}&units=metric&appid=060a6bcfa19809c2cd4d97a212b19273&language=id`
                );
                let Yori_txt = ""
                Yori_txt += `🍃 *Cuaca Dari : ${text}*\n`
                Yori_txt += `☁️ *Cuaca :* *${wdata.data.weather[0].main}*\n`
                Yori_txt += `🧾 *Deskripsi :* *${wdata.data.weather[0].description}*\n`
                Yori_txt += `🌡️ *Suhu Rata Rata :* *${wdata.data.main.temp}*\n`
                Yori_txt += `💨 *Tekanan :* *${wdata.data.main.pressure}*\n`
                Yori_txt += `🧴 *kelembapan :* *${wdata.data.main.humidity}*\n`
                Yori_txt += `🛳️ *Garis Bujur :* *${wdata.data.coord.lat}*\n`
                Yori_txt += `🌏 *Negara :* *${wdata.data.sys.country}*\n`

                Yori.sendMessage(
                    m.chat, {
                    text: Yori_txt,
                }, {
                    quoted: m,
                }
                )
            }
            */
           case 'infocuaca': case 'cuaca': {
    if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
    if (!text) return Yorireply('🍃 *Ketik nama lokasi untuk melihat cuaca!*')
    Yorireply('🍃 *Sedang mencari informasi cuaca...*')

    let wdata = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?q=${text}&units=metric&appid=060a6bcfa19809c2cd4d97a212b19273&language=id`
    );
    
    // Ambil data yang diperlukan dari API
    let weatherMain = wdata.data.weather[0].main;
    let weatherDesc = wdata.data.weather[0].description;
    let temp = wdata.data.main.temp;
    let humidity = wdata.data.main.humidity;
    let pressure = wdata.data.main.pressure;
    let country = wdata.data.sys.country;
    let icon = wdata.data.weather[0].icon;
    let iconUrl = `https://widipe.com/file/bsIFvljmexyZ.jpg`; // URL thumbnail

    // Format pesan yang simpel dan menarik
    let Yori_txt = `
        🌍 *Cuaca di ${text}* (${country})
        ☁️ *${weatherMain}* - ${weatherDesc}
        🌡️ *Suhu:* ${temp}°C
        💧 *Kelembapan:* ${humidity}%
        🔵 *Tekanan Udara:* ${pressure} hPa
    `;

    // Kirim pesan dengan thumbnail cuaca
    Yori.sendMessage(
        m.chat, {
            text: Yori_txt,
            footer: 'Data cuaca by OpenWeatherMap',
            thumbnail: iconUrl, // Thumbnail ikon cuaca
        }, {
            quoted: m,
        }
    );
}
                break
                /*
  case 'jadwalsholat': {
     if (!text) return Yorireply(`[ Example ] : Jadwalsholat Lokasi Anda`) 
     try {
        let respon = await fetch(`https://api.agatz.xyz/api/jadwalsholat?kota=${text}`);
        let data = await respon.json();       
        let subuh = data.subuh;
        let dhuhur = data.dhuhur;
        let ashar = data.ashar;
        let maghrib = data.maghrib;
        let isya = data.isya;
        // Menampilkan hasil Ya woy
        Yori.sendMessage(from, {
            image: { url: './data/image/jadwal.jpg' },
            caption: `*Jadwal Sholat di Kota ${text}*\n\n` +
                     `🕌 Subuh: ${data.subuh}\n` +
                     `🕌 Dhuhur: ${data.dhuhur}\n` +
                     `🕌 Ashar: ${data.ashar}\n` +
                     `🕌 Maghrib: ${data.maghrib}\n` +
                     `🕌 Isya: ${data.isya}\n\n` +
                     `Jangan Lupa Sholat Dan Semoga sholat kita diterima Allah SWT.`,
        });
    } catch (error) {
        console.error(error);
        Yorireply('⚠️ *Terjadi kesalahan saat melakukan pencarian. Silakan coba lagi.*');
   }
 }
 */
case 'jadwalsholat': {
     if (!text) return Yorireply(`[ Example ] : Jadwalsholat Lokasi Anda`) 
     try {
        let respon = await fetch(`https://api.agatz.xyz/api/jadwalsholat?kota=${text}`);
        let waktu = await respon.json();       
        let subuh = waktu.data.subuh;
        let dhuhur = waktu.data.dhuhur;
        let ashar = waktu.data.ashar;
        let maghrib = waktu.data.maghrib;
        let isya = waktu.data.isya;
        // Menampilkan hasil Ya woy
        Yori.sendMessage(from, {
            image: { url: './data/image/jadwal.jpg' },
            caption: `*Jadwal Sholat di Kota ${text}*\n\n` +
                     `🕌 Subuh: ${subuh}\n` +
                     `🕌 Dhuhur: ${dhuhur}\n` +
                     `🕌 Ashar: ${ashar}\n` +
                     `🕌 Maghrib: ${maghrib}\n` +
                     `🕌 Isya: ${isya}\n\n` +
                     `Jangan Lupa Sholat Dan Semoga sholat kita diterima Allah SWT.`,
        });
    } catch (error) {
        console.error(error);
        Yorireply('⚠️ *Terjadi kesalahan saat melakukan pencarian. Silakan coba lagi.*');
   }
 }
                break               

            case 'imdb':
                if (!text) return Yorireply(`🍃 *Masukan Judul Filmnya*`)
                Yorireply('🍃 *Sabar Yaa*')
                let fids = await axios.get(`http://www.omdbapi.com/?apikey=742b2d09&t=${text}&plot=full`)
                let Yori_txt = ""
                console.log(fids.data)
                Yori_txt += "🍃 *IMDB Search*\n"
                Yori_txt += "📖 *Judul :* *" + fids.data.Title + "*\n"
                Yori_txt += "📅 *Tahun :* *" + fids.data.Year + "*\n"
                Yori_txt += "📦 *Rilis :* *" + fids.data.Released + "*\n"
                Yori_txt += "🕒 *Durasi :* *" + fids.data.Runtime + "*\n"
                Yori_txt += "📰 *Genre :* *" + fids.data.Genre + "*\n"
                Yori_txt += "📋 *Direktur :* *" + fids.data.Director + "*\n"
                Yori_txt += "📝 *Penulis :* *" + fids.data.Writer + "*\n"
                Yori_txt += "👤 *Aktor :* *" + fids.data.Actors + "*\n"
                Yori_txt += "💬 *Bahasa :* *" + fids.data.Language + "*\n"
                Yori_txt += "🌏 *Negara :* *" + fids.data.Country + "*\n"
                Yori_txt += "🏆 *Penghargaan :* *" + fids.data.Awards + "*\n"
                Yori_txt += "🪙 *Keuntungan :* *" + fids.data.BoxOffice + "*\n"
                Yori_txt += "🏷️ *Nilai :* *" + fids.data.imdbRating + "*\n"
                Yori_txt += "📣 *Pemungutan Suara :* *" + fids.data.imdbVotes + "*\n\n"
                Yori_txt += "📃 *Plot :*\n" + fids.data.Plot + ""
                Yori.sendMessage(m.chat, {
                    image: {
                        url: fids.data.Poster,
                    },
                    caption: Yori_txt,
                }, {
                    quoted: m,
                })
                    .catch(console.error)
                break
                /*
                case 'film': {
  if (!text) return Yorireply(`Example: Film Godzilla`);
  try {
    let response = await fetch(`https://widipe.com/filmapiksearch?query=${text}`);    
    if (!response.ok) {
      return Yorireply(`Terjadi kesalahan. Kode status: ${response.status}`);
    }    
    let data = await response.json();
    if (!data || data.length === 0) {
      return Yorireply(`Film dengan judul "${text}" tidak ditemukan.`);
    }
  const film = data[0];    
   return Yorireply(
      `*Judul Film*: ${film.title}\n` +
      `*Rating*: ${film.rating}\n` +
      `*Deskripsi*: ${film.synopsis}\n` +
      `*Source Link*: ${film.url}\n` +
      `*Thumbnail*: ${film.thumbnail}`
    );
  } catch (error) {
    // Menangani error saat pengambilan data
    return Yorireply(`Terjadi kesalahan saat mengambil data: ${error.message}`);
  }
}
*/
/*
case 'film': {
  if (!text) return m.reply(`Example: Film Godzilla`);
  try {
    let response = await fetch(`https://widipe.com/filmapiksearch?query=${text}`);    
    if (!response.ok) {
      return m.reply(`Terjadi kesalahan. Kode status: ${response.status}`);
    }    
    let data = await response.json();    
    if (!data || data.length === 0) {
      return m.reply(`Film dengan judul "${text}" tidak ditemukan.`);
    }  
    let film = data[0];    
    let title = film.title;
    let rating = film.rating;
    let synopsis = film.synopsis;
    let url = film.url;
    let thumbnail = film.thumbnail;
    
    let filmResult = `*Judul Film*: ${title}\n` +
      `*Rating*: ${rating}\n` +
      `*Deskripsi*: ${synopsis}\n` +
      `*Source Link*: ${url}\n` +
      `*Thumbnail*: ${thumbnail}`
      `Ini adalah Hasil dari Film ${text}`;
     return m.reply(filmResult);  
  } catch (error) {
    return m.reply(`Terjadi kesalahan saat mengambil data: ${error.message}`);
  }
}
*/
                
case 'searchfilm': case 'filmsearch': case 'film': {
if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
if (!text) return m.reply('🔥 Contoh: Film Godzilla 🔥');  
let response = await fetch(`https://widipe.com/filmapiksearch?query=${text}`);
let data = await response.json();

let resultMessage = data.result.data.map(film => 
      `🎬 *Judul:* ${film.title}\n` +
      `⭐ *Rating:* ${film.rating}\n` +
      `📖 *Deskripsi:* ${film.synopsis}\n` +
      `🔗 *URL:* ${film.url}\n`
    ).join('\n');

let button = new Button();
button.setTitle(`*FILM - SEARCH*`);
button.setImage(data.result.data[0].thumbnail); 
button.setBody(`Berikut Hasil Pencarian Dari: ${text}`);
button.addSelection("Open");
button.makeSections(`Film Search: ${text}`, "");
data.result.data.forEach((film) => {
  button.makeRow(
    `${film.title}`,
    `🎬 Judul: ${film.title}\n⭐ Rating: ${film.rating}\n📖 *Deskripsi:* ${film.synopsis}`,
    `🔗 URL: ${film.url}`,
    `#fdl ${film.url}`,
  );
});

await button.run(m.chat, Yori, m);
}
break
/*
case'fdl':{
if (!text) return Yorireply("input url")
let response = await fetchJson(`https://widipe.com/filmapikdl?url=${text}`);
let filmnya = response.result.Url;

let wow = `⭐ VIP : ${filmnya.VIP}
⭐ FILELIONS : ${filmnya.FILELIONS}
⭐ HELLABYTE : ${filmnya.HELLABYTE}
⭐ FILEMOON : ${filmnya.FILEMOON}`;

Yorireply(wow);
}
*/
case 'fdl': {
    if (!text) {
        return m.reply("🚨 Oops! Tolong masukkan URL film yang ingin diunduh.");
    }
    try {
        let response = await fetchJson(`https://widipe.com/filmapikdl?url=${text}`);
        let filmUrls = response.result.Url;
        if (!filmUrls.VIP || !filmUrls.HELLABYTE) {
            return m.reply("⚠️ Maaf, ada masalah dengan data film yang diterima. Coba lagi nanti.");
        }
        let downloadOptions = `
        *Jika ingin melihat langsung dari website resmi langsung saja click link di bawah👇*

        🔗 *Link Url Film* = ${text}
        
        _Kalau anda ingin download film tersebut Pilih Link Server di bawah ya 👇_
      
        🎬 *Pilihan Download Film* 🎬
        
        ⭐ *VIP* : ${filmUrls.VIP}
        🔥 *HELLABYTE* : ${filmUrls.HELLABYTE}
        
        Pilih salah satu server di atas untuk mulai mendownload film! 
        `;
        m.reply(downloadOptions);
    } catch (error) {       
        m.reply("❌ Maaf, terjadi kesalahan saat mengambil data. Pastikan URL yang Anda masukkan benar.");
    }
}

break

            case 'asmaulhusna': {
                const t3xt = require(`./database/teks/${command}.json`)
                const r4andT3xt = t3xt[Math.floor(Math.random() * t3xt.length)]
                Yori.sendMessage(from, { text: r4andT3xt }, { quoted: m })
            }
      break        

            case 'ayatkursi': {
                let Yoricap = `🎁 *Ayat Kursi*

✉️ *Arab :*
اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ وَلَا يَئُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ

✉️ *Latin :*
*“Alloohu laa ilaaha illaa huwal hayyul qoyyuum, laa ta’khudzuhuu sinatuw walaa naum. Lahuu maa fissamaawaati wa maa fil ardli man dzal ladzii yasyfa’u ‘indahuu illaa biidznih, ya’lamu maa baina aidiihim wamaa kholfahum wa laa yuhiithuuna bisyai’im min ‘ilmihii illaa bimaa syaa’ wasi’a kursiyyuhus samaawaati wal ardlo walaa ya’uuduhuu hifdhuhumaa wahuwal ‘aliyyul ‘adhiim.”*

✉️ *Artinya:*
Allah, tidak ada Tuhan (yang berhak disembah) melainkan Dia Yang Hidup kekal lagi terus menerus mengurus (makhluk-Nya); tidak mengantuk dan tidak tidur. Kepunyaan-Nya apa yang di langit dan di bumi. Tiada yang dapat memberi syafa'at di sisi Allah tanpa izin-Nya.
Allah mengetahui apa-apa yang di hadapan mereka dan di belakang mereka, dan mereka tidak mengetahui apa-apa dari ilmu Allah melainkan apa yang dikehendaki-Nya. Kursi Allah meliputi langit dan bumi. Dan Allah tidak merasa berat memelihara keduanya, dan Allah Maha Tinggi lagi Maha Besar." 
*(QS. Al Baqarah: 255)*`
                Yori.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/afb17800d56775ad1791d.png' }, caption: Yoricap }, { quoted: m });
            }

                break

            case 'niatsholat': {
                if (!q) return Yorireply(`Contoh Penggunaan :\nniatsholat Subuh`)
                const niatsholat = [
                    {
                        index: 1,
                        solat: "subuh",
                        latin: "Ushalli fardhosh shubhi rok'ataini mustaqbilal qiblati adaa-an lillaahi ta'aala",
                        arabic: "اُصَلِّى فَرْضَ الصُّبْحِ رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
                        translation_id: "Aku berniat shalat fardhu Shubuh dua raka'at menghadap kiblat karena Allah Ta'ala",
                    },
                    {
                        index: 2,
                        solat: "maghrib",
                        latin: "Ushalli fardhol maghribi tsalaata raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
                        arabic: "اُصَلِّى فَرْضَ الْمَغْرِبِ ثَلاَثَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
                        translation_id: "Aku berniat shalat fardhu Maghrib tiga raka'at menghadap kiblat karena Allah Ta'ala",
                    },
                    {
                        index: 3,
                        solat: "dzuhur",
                        latin: "Ushalli fardhodl dhuhri arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
                        arabic: "اُصَلِّى فَرْضَ الظُّهْرِاَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
                        translation_id: "Aku berniat shalat fardhu Dzuhur empat raka'at menghadap kiblat karena Allah Ta'ala",
                    },
                    {
                        index: 4,
                        solat: "isha",
                        latin: "Ushalli fardhol 'isyaa-i arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
                        arabic: "صَلِّى فَرْضَ الْعِشَاءِ اَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
                        translation_id: "Aku berniat shalat fardhu Isya empat raka'at menghadap kiblat karena Allah Ta'ala",
                    },
                    {
                        index: 5,
                        solat: "ashar",
                        latin: "Ushalli fardhol 'ashri arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
                        arabic: "صَلِّى فَرْضَ الْعَصْرِاَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
                        translation_id: "Aku berniat shalat fardhu 'Ashar empat raka'at menghadap kiblat karena Allah Ta'ala",
                    }
                ]
                let text = q.toLowerCase() || ''
                let data = Object.values(niatsholat).find(v => v.solat == text)
                if (!data) return Yorireply(`${txt} Tidak Ditemukan\n\nList Solat 5 Waktu :\n• Subuh\n• Maghrib\n• Dzuhur\n• Isha\n• Ashar`)
                Yorireply(`
_*Niat Sholat ${text}*_

*Arab :* ${data.arabic}

*Latin :* ${data.latin} 

*Translate :* ${data.translation_id}`.trim())
            }

                break

            case 'quotesislami': {
                const islami = [
                    {
                        "id": "1",
                        "arabic": "مَنْ سَارَ عَلىَ الدَّرْبِ وَصَلَ",
                        "arti": "Barang siapa berjalan pada jalannya, maka dia akan sampai (pada tujuannya)."
                    },
                    {
                        "id": "2",
                        "arabic": "مَنْ صَبَرَ ظَفِرَ",
                        "arti": "Barang siapa bersabar, maka dia akan beruntung."
                    },
                    {
                        "id": "3",
                        "arabic": "مَنْ جَدَّ وَجَـدَ",
                        "arti": "Barang siapa bersungguh-sungguh, maka dia akan meraih (kesuksesan)."
                    },
                    {
                        "id": "4",
                        "arabic": "جَالِسْ أَهْلَ الصِّدْقِ وَالوَفَاءِ",
                        "arti": "Bergaulah bersama orang-orang yang jujur dan menepati janji."
                    },
                    {
                        "id": "5",
                        "arabic": "مَنْ قَلَّ صِدْقُهُ قَلَّ صَدِيْقُهُ",
                        "arti": "Barang siapa sedikit kejujurannya, maka sedikit pulalah temannya."
                    },
                    {
                        "id": 6,
                        "arabic": "مَوَدَّةُ الصَّدِيْقِ تَظْهَرُ وَقْتَ الضِّيْقِ",
                        "arti": "Kecintaan seorang teman itu akan terlihat pada waktu kesempitan."
                    },
                    {
                        "id": "7",
                        "arabic": "الصَّبْرُ يُعِيْنُ عَلَى كُلِّ عَمَلٍ",
                        "arti": "Kesabaran akan menolong segala pekerjaan."
                    },
                    {
                        "id": "8",
                        "arabic": "وَمَا اللَّذَّةُ إِلاَّ بَعْدَ التَّعَبِ",
                        "arti": "Tidak ada kenikmatan kecuali setelah kepayahan."
                    },
                    {
                        "id": "9",
                        "arabic": "جَرِّبْ وَلاَحِظْ تَكُنْ عَارِفًا",
                        "arti": "Coba dan perhatikanlah, maka engkau akan menjadi orang yang tahu."
                    },
                    {
                        "id": "10",
                        "arabic": "بَيْضَةُ اليَوْمِ خَيْرٌ مِنْ دَجَاجَةِ الغَدِ",
                        "arti": "Telur hari ini lebih baik daripada ayam esok hari."
                    },
                    {
                        "id": "11",
                        "arabic": "أُطْلُبِ الْعِلْمَ مِنَ الْمَهْدِ إِلَى الَّلحْدِ",
                        "arti": "Carilah ilmu sejak dari buaian hingga liang lahat."
                    },
                    {
                        "id": "12",
                        "arabic": "الوَقْتُ أَثْمَنُ مِنَ الذَّهَبِ",
                        "arti": "Waktu itu lebih berharga daripada emas."
                    },
                    {
                        "id": "13",
                        "arabic": "لاَ خَيْرَ فيِ لَذَّةٍ تَعْقِبُ نَدَماً",
                        "arti": "Tak ada kebaikan bagi kenikmatan yang diiringi dengan penyesalan."
                    },
                    {
                        "id": "14",
                        "arabic": "أَخِي لَنْ تَنَالَ العِلْمَ إِلاَّ بِسِتَّةٍ سَأُنْبِيْكَ عَنْ تَفْصِيْلِهَا بِبَيَانٍ: ذَكَاءٌ وَحِرْصٌ وَاجْتِهَادٌ وَدِرْهَمٌ وَصُحْبَةُ أُسْتَاذٍ وَطُوْلُ زَمَانٍ",
                        "arti": "Wahai saudaraku, Kamu tidak akan memperoleh ilmu kecuali dengan enam perkara, akan aku sampaikan rinciannya dengan jelas; 1) Kecerdasan, 2) Ketamaan (terhadap ilmu), 3) Kesungguhan, 4) Harta benda (sebagai bekal), 5) Bergaul dengan guru, 6) Waktu yang lama."
                    },
                    {
                        "id": "15",
                        "arabic": "لاَ تَكُنْ رَطْباً فَتُعْصَرَ وَلاَ يَابِسًا فَتُكَسَّرَ",
                        "arti": "Janganlah kamu bersikap lemah, sehingga kamu mudah diperas. Dan janganlah kamu bersikap keras, sehingga kamu mudah dipatahkan."
                    },
                    {
                        "id": "16",
                        "arabic": "لِكُلِّ مَقَامٍ مَقَالٌ وَلِكُلِّ مَقَالٍ مَقَامٌ",
                        "arti": "Setiap tempat memiliki perkataannya masing-masing, dan setiap perkataan memiliki tempatnya masing-masing."
                    }, {
                        "id": "17",
                        "arabic": "خَيْرُ النَّاسِ أَحْسَنُهُمْ خُلُقاً وَأَنْفَعُهُمْ لِلنَّاسِ",
                        "arti": "Sebaik-baik manusia adalah yang paling baik budi pekertinya dan yang paling bermanfaat bagi manusia lainnya."
                    },
                    {
                        "id": "18",
                        "arabic": "خَيْرُ جَلِيْسٍ في الزّمانِ كِتابُ",
                        "arti": "Sebaik-baik teman duduk di setiap waktu adalah buku."
                    },
                    {
                        "id": "19",
                        "arabic": "مَنْ يَزْرَعْ يَحْصُدْ",
                        "arti": "Barang siapa menanam, pasti ia akan memetik (mengetam)."
                    },
                    {
                        "id": "20",
                        "arabic": "لَوْلاَ العِلْمُ لَكَانَ النَّاسُ كَالبَهَائِمِ",
                        "arti": "Kalaulah tidak karena ilmu, niscaya manusia itu seperti binatang."
                    },
                    {
                        "id": "21",
                        "arabic": "سَلاَمَةُ الإِنْسَانِ فيِ حِفْظِ اللِّسَانِ",
                        "arti": "Keselamatan manusia itu terletak pada penjagaan lidahnya (perkataannya)."
                    },
                    {
                        "id": "22",
                        "arabic": "الرِّفْقُ بِالضَّعِيْفِ مِنْ خُلُقِ الشَّرِيْفِ",
                        "arti": "Berlaku lemah lembut kepada orang yang lemah itu termasuk akhlak orang yang mulia (terhormat)."
                    },
                    {
                        "id": "23",
                        "arabic": "وَعَامِلِ النَّاسَ بِمَا تُحِبُّ مِنْهُ دَائِماً",
                        "arti": "Dan bergaullah dengan manusia dengan sikap yang kamu juga suka diperlakukan seperti itu."
                    },
                    {
                        "id": "24",
                        "arabic": "لَيْسَ الجَمَالُ بِأَثْوَابٍ تُزَيِّنُنُا إِنَّ الجَمَالَ جمَاَلُ العِلْمِ وَالأَدَبِ",
                        "arti": "Kecantikan bukanlah dengan pakaian yang melekat menghiasi diri kita, sesungguhnya kecantikan ialah kecantikan dengan ilmu dan budi pekerti."
                    },
                    {
                        "id": "25",
                        "arabic": "مَنْ أَعاَنَكَ عَلىَ الشَّرِّ ظَلَمَكَ",
                        "arti": "Barang siapa membantumu dalam kejahatan, maka sesungguhnya ia telah berbuat aniaya terhadapmu."
                    }
                ]
                const randomIndex = Math.floor(Math.random() * islami.length);
                const randomQuote = islami[randomIndex];
                const { arabic, arti } = randomQuote;
                Yorireply(`${arabic}\n${arti}`)
            }
                break

            case 'kisahnabi': {
                if (!text) return Yorireply(`🍃 *Tolong Masukkan Nama Nabi*`)
                try {
                    let Yori_kn = await fetchJson(`https://api.zeeoneofc.my.id/api/islam/kisahnabi?apikey=QIO8xicLNkEV43Y&nabi=${text}`)
                    const namanabi = Yori_kn.result.name
                    const kelahiran = Yori_kn.result.birth
                    const wafat = Yori_kn.result.death_age
                    const asal = Yori_kn.result.country_from
                    const ceritanabi = Yori_kn.result.story
                    var Yori_result = ` *[ Kisah Nabi ]*
⥁ *Nama Nabi : ${namanabi}*
⥁ *Hari Kelahiran : ${kelahiran}*
⥁ *Wafat Pada Umur : ${wafat}*
⥁ *Asal : ${asal}*

*[ Kisah Dari Nabi ${namanabi} : ]*
${ceritanabi}`
                    Yorireply(Yori_result)
                } catch (error) {
                    Yorireply(`⚠️ *Nama Nabi Tidak Ditemukan*\n✉️ *Pastikan Menggunakan Huruf Kapital Pada Awal Nama Nabi*`);
                }
            }
                break

            case 'doa':
            case 'berdoa': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (!text) return Yorireply(`☘️ *Tolong Masukkan Doa Yang Ingin Dicari*`)
                try {
                    Yorireply(mess.wait)
                    let iYori = await fetchJson(`https://doa-doa-api-ahmadramadhan.fly.dev/api/doa/${text}`)
                    const namadoa = iYori.doa
                    const ayat = iYori.ayat
                    const latin = iYori.latin
                    var Yori_result = `☘️ *Pencarian : ${namadoa}*

*${ayat}*

*${latin}*`
                    Yorireply(Yori_result)
                } catch (error) {
                    return Yorireply(mess.error);
                }
            }
                break
            case 'spotify': case 'spotifysearch': case 'spotifys': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (!text) return Yorireply('[ EXAMPLE ] Spotify Sempurna!')
                let result = await searchSpotify(text)
                let caption = result.map((v, i) => {
                    return {
                        header: "",
                        title: v.name,
                        description: `Link: ${v.link}`,
                        id: '.spdl ' + v.link
                    }
                })
                let msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage: {
                                body: {
                                    text: `🔎 Hasil Pencarian Dari ${text}\nSilahkan Pilih List dibawah ini`,
                                },
                                footer: {
                                    text: 'Yori Chan Spotify'
                                },
                                header: {
                                    title: "Spotify - Search",
                                    subtitle: "",
                                    hasMediaAttachment: false,
                                },
                                nativeFlowMessage: {
                                    buttons: [
                                        {
                                            name: "single_select",
                                            buttonParamsJson: JSON.stringify({
                                                title: "CLICK HERE",
                                                sections: [
                                                    {
                                                        title: "",
                                                        rows: caption
                                                    }
                                                ]
                                            })
                                        }
                                    ]
                                }
                            }
                        }
                    }
                }, { quoted: m }, {});
                await Yori.relayMessage(msg.key.remoteJid, msg.message, {
                    messageId: msg.key.id
                });
            }
                break
case 'spotify2': case 'spotifysearch2': case 'spotifys2': {
    if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
    if (!text) return Yorireply('[ EXAMPLE ] Spotify Sempurna!')
    try {
        let result = await searchSpotify(text)
        if (result.length === 0) return Yorireply('Tidak ada hasil yang ditemukan.')
        let caption = `🔎 Hasil Pencarian Untuk: *${text}*\n\n`
        caption += result.map((v, i) => `${i + 1}. *${v.name}*\n   ∘ Link: ${v.link}\n`).join('\n')
        await Yori.sendMessage(from, { text: caption }, { quoted: m })
    } catch (error) {
        console.error(error)
        Yorireply('Terjadi kesalahan saat melakukan pencarian. Silakan coba lagi.')
    }
}
                break
 case 'spotipi':{
     try {
      if (!text) return Yorireply(mess.search)
       let res = await searchSpotify(text)
         let name = `${res[0].name}`
           Yori.sendMessage(m.chat, {
             text: name,
              contextInfo: {
               externalAdReply: {
                 title: `SPOTIFY AUDIO`,
                 body: `Yori Chan - 2024`,
                   thumbnailUrl: `${res[0].image}`,
                  mediaType: 1,
                 renderLargerThumbnail: true
              }}}, { quoted: m})
            let download = await spotifydl(`${res[0].link}`)
          await Yori.sendMessage(m.chat, { audio: { url: download.download }, mimetype: 'audio/mp4', ptt: true }, { quoted: m })
         } catch (err) {
        console.error(err)
       Yorireply(`an error occurred`)
       }
     }
                break

            case 'spdl': case 'spotifydl': {
                if (!text) return Yorireply('Masukan Link')
                let result = await spotifydl(text)
                let captionvid = `∘ Title: ${result.title}\n∘ Artist: ${result.artis}\n∘ Type: ${result.type}\n\nYori Chan`
                const p = await new canvafy.Spotify()
                    .setTitle(result.title)
                    .setAuthor("Spotify - Downloader")
                    .setTimestamp(40, 100)
                    .setOverlayOpacity(0.8)
                    .setBorder("#fff", 0.8)
                    .setImage(result.image)
                    .setBlur(3)
                    .build();

                await Yori.sendMessage(from, { image: p, caption: captionvid }, { quoted: m })
                Yori.sendMessage(m.chat, { audio: { url: result.download }, mimetype: 'audio/mpeg', filename: 'MP3 BY ' + 'Yori' }, { quoted: m });
            }
                break                
                /*
            case "youtube": case 'yts': case 'ytsearch': case 'youtubesearch': case 'carilagu':
                {
                    if (!text) return Yorireply("Mau Search Apa nih?");
                    const data = await fetch(
                        `https://api.betabotz.eu.org/api/search/yts?query=${text}&apikey=${sherly}`
                    );
                    const res = await data.json();

                    let sections = [
                        {
                            title: `Hasil Dari ${text}`,
                            highlight_label: `maybe you like`,
                            rows: [
                                {
                                    title: `${res.result[0].title}`,
                                    description: `𝗜𝗗 : ${res.result[0].videoId} | 𝗗𝗨𝗥𝗔𝗦𝗜 : ${res.result[0].duration}`,
                                    id: `.ytselect ${res.result[0].url}`,
                                },
                                {
                                    title: `${res.result[1].title}`,
                                    description: `𝗜𝗗 : ${res.result[1].videoId} | 𝗗𝗨𝗥𝗔𝗦𝗜 : ${res.result[1].duration}`,
                                    id: `.ytselect ${res.result[1].url}`,
                                },
                                {
                                    title: `${res.result[2].title}`,
                                    description: `𝗜𝗗 : ${res.result[2].videoId} | 𝗗𝗨𝗥𝗔𝗦𝗜 : ${res.result[2].duration}`,
                                    id: `.ytselect ${res.result[2].url}`,
                                },
                            ],
                        },
                    ];

                    let listMessage = {
                        title: `${res.result[0].title}`,
                        sections,
                    };

                    let msgs = generateWAMessageFromContent(
                        m.from,
                        {
                            viewOnceMessage: {
                                message: {
                                    messageContextInfo: {
                                        deviceListMetadata: {},
                                        deviceListMetadataVersion: 2,
                                    },
                                    interactiveMessage: proto.Message.InteractiveMessage.create({
                                        contextInfo: {
                                            mentionedJid: [m.sender],
                                            isForwarded: true,
                                            forwardedNewsletterMessageInfo: {
                                                newsletterJid: "120363204138641225@newsletter",
                                                newsletterName: "Powered BY Yori Chan",
                                                serverMessageId: -1,
                                            },
                                            businessMessageForwardInfo: {
                                                businessOwnerJid: Yori.decodeJid(Yori.user.id),
                                            },
                                            externalAdReply: {
                                                title: "Yori Chan | New 2023 - 2024",
                                                thumbnail: fs.readFileSync(
                                                    "./data/image/profile.jpg"
                                                ),
                                                sourceUrl: '',
                                                mediaType: 2,
                                                renderLargerThumbnail: false,
                                            },
                                        },
                                        body: proto.Message.InteractiveMessage.Body.create({
                                            text: `Yori Chan | New 2023 - 2024`,
                                        }),
                                        footer: proto.Message.InteractiveMessage.Footer.create({
                                            text: `Click the button below to play audio`,
                                        }),
                                        header: proto.Message.InteractiveMessage.Header.create({
                                            ...(await prepareWAMessageMedia(
                                                { image: { url: res.result[0].thumbnail } },
                                                { upload: Yori.waUploadToServer }
                                            )),
                                            title: `┌─❖\n│「 𝗛𝗶 ${pushname}👋 」\n└┬❖ 「  YTSEARCH BY YORI CHAN  」\n│✑ \n│✑  Search Results From\n│✑  *${res.result[0].title}*\n└───────────────┈ ⳹`,
                                            subtitle: `${res.result[0].title}`,
                                            hasMediaAttachment: false,
                                        }),

                                        nativeFlowMessage:
                                            proto.Message.InteractiveMessage.NativeFlowMessage.create(
                                                {
                                                    buttons: [
                                                        {
                                                            name: "single_select",
                                                            buttonParamsJson: JSON.stringify(listMessage),
                                                        },
                                                    ],
                                                }
                                            ),
                                        contextInfo: {
                                            mentionedJid: [m.sender],
                                            forwardingScore: 999,
                                            isForwarded: true,
                                            forwardedNewsletterMessageInfo: {
                                                newsletterJid: "0@newsletter",
                                                newsletterName: ownername,
                                                businessMessageForwardInfo: {
                                                    businessOwnerJid: Yori.decodeJid(Yori.user.id),
                                                },
                                                serverMessageId: 143,
                                            },
                                        },
                                    }),
                                },
                            },
                        },
                        {}
                    );
                    Yori.relayMessage(m.key.remoteJid, msgs.message, {
                        messageId: m.key.id,
                    });
                }
                break;
            case "ytselect":
                {
                    if (!text) return Yorireply("link?");
                    const data = await fetch(
                        `https://api.betabotz.eu.org/api/search/yts?query=${text}&apikey=${sherly}`
                    );
                    const res = await data.json();

                    let sections = [
                        {
                            title: `Yori Chan | New 2023 - 2024`,
                            highlight_label: `maybe you like`,
                            rows: [
                                {
                                    title: `Audio`,
                                    description: `Send Audio Files`,
                                    id: `.ytmp3 ${text}`,
                                },
                                {
                                    title: `Vidio`,
                                    description: `send vidio files`,
                                    id: `.ytmp4 ${text}`,
                                },
                            ],
                        },
                    ];

                    let listMessage = {
                        title: `OPTION`,
                        sections,
                    };

                    let msgs = generateWAMessageFromContent(
                        m.from,
                        {
                            viewOnceMessage: {
                                message: {
                                    messageContextInfo: {
                                        deviceListMetadata: {},
                                        deviceListMetadataVersion: 2,
                                    },
                                    interactiveMessage: proto.Message.InteractiveMessage.create({
                                        contextInfo: {
                                            mentionedJid: [m.sender],
                                            isForwarded: true,
                                            forwardedNewsletterMessageInfo: {
                                                newsletterJid: "120363204138641225@newsletter",
                                                newsletterName: "Powered BY YORI CHAN",
                                                serverMessageId: -1,
                                            },
                                            businessMessageForwardInfo: {
                                                businessOwnerJid: Yori.decodeJid(Yori.user.id),
                                            },
                                            externalAdReply: {
                                                title: "Yori Chan | New 2023 - 2024",
                                                thumbnail: fs.readFileSync(
                                                    "./data/image/profile.jpg"
                                                ),
                                                sourceUrl: '',
                                                mediaType: 2,
                                                renderLargerThumbnail: false,
                                            },
                                        },
                                        body: proto.Message.InteractiveMessage.Body.create({
                                            text: `Yori Chan | New 2023 - 2024`,
                                        }),
                                        footer: proto.Message.InteractiveMessage.Footer.create({
                                            text: `Click the button`,
                                        }),
                                        header: proto.Message.InteractiveMessage.Header.create({
                                            ...(await prepareWAMessageMedia(
                                                { image: { url: res.result[0].thumbnail } },
                                                { upload: Yori.waUploadToServer }
                                            )),
                                            title: `┌─❖\n│「 𝗛𝗶 ${pushname}👋 」\n└┬❖ 「  YTDL BY Yori Chan  」\n│✑\n└───────────────┈ ⳹`,
                                            subtitle: `OPTIONS`,
                                            hasMediaAttachment: false,
                                        }),

                                        nativeFlowMessage:
                                            proto.Message.InteractiveMessage.NativeFlowMessage.create(
                                                {
                                                    buttons: [
                                                        {
                                                            name: "single_select",
                                                            buttonParamsJson: JSON.stringify(listMessage),
                                                        },
                                                    ],
                                                }
                                            ),
                                        contextInfo: {
                                            mentionedJid: [m.sender],
                                            forwardingScore: 999,
                                            isForwarded: true,
                                            forwardedNewsletterMessageInfo: {
                                                newsletterJid: "0@newsletter",
                                                newsletterName: ownername,
                                                businessMessageForwardInfo: {
                                                    businessOwnerJid: Yori.decodeJid(Yori.user.id),
                                                },
                                                serverMessageId: 143,
                                            },
                                        },
                                    }),
                                },
                            },
                        },
                        {}
                    );
                    Yori.relayMessage(m.key.remoteJid, msgs.message, {
                        messageId: m.key.id,
                    });
                }
                */
                /*
                case 'yts': case 'youtubesearch': {
    if (!text) return Yorireply(`[ Example ] : \n .yts Sempurna`)
    Yorireply(mess.wait)
    try {
        let yts = require('yt-search')
        let search = await yts(text)
        if (search.all.length === 0) return Yorireply('Tidak ada hasil yang ditemukan.')
        let teks = `🔎 Hasil Pencarian Untuk: *${text}*\n\n.yta untuk memutarkan lagu dari pencarian ${text}
.ytv untuk memutarkan sebuah video youtube dari ${text}\n\nContoh Penggunaan :
[ Example ] : .yta Link yutub dari ${text}
[ Example ] : .ytv Link Yutub dari ${text}\n\n`
        teks += search.all.slice(0, 5).map((video, i) => 
            `${i + 1}. *${video.title}*\n    ∘ Views: *${video.views}*\n    ∘ Durasi: *${video.timestamp}*\n    ∘ Diunggah: *${video.ago}*\n    ∘ URL: ${video.url}\n`
        ).join('\n')
        await Yori.sendMessage(m.chat, { text: teks }, { quoted: m })
    } catch (error) {
        console.error(error)
        Yorireply('Terjadi kesalahan saat melakukan pencarian. Silakan coba lagi.')
    }
}
*/
/*
      case 'yts': case 'ytsearch': case 'youtubesearch': {
    if (!text) return Yorireply(`*⚠️ Contoh Penggunaan*: \n .yts Sempurna`)
    Yorireply(mess.wait)
    try {
        let yts = require('yt-search')
        let search = await yts(text)
        if (search.all.length === 0) return Yorireply('❌ *Tidak ada hasil yang ditemukan.*')
        
        let teks = `🎬 *Hasil Pencarian Untuk*: _*${text}*_\n\n`
        teks += `📥 *Ketik* _*.yta*_ *untuk download lagu* dari pencarian _${text}_\n`
        teks += `📺 *Ketik* _*.ytv*_ *untuk download video* dari _${text}_\n\n`
        teks += `*📌 Contoh Penggunaan*:\n`
        teks += `∘ .yta Link YouTube ${text} (download audio)\n`
        teks += `∘ .ytv Link YouTube ${text} (download video)\n\n`
        teks += `🔎 *Top 10 Hasil Pencarian*: \n`

        // Loop untuk menampilkan hasil pencarian
        teks += search.all.slice(0, 10).map((video, i) => 
            `*${i + 1}. ${video.title}*\n`
            + `   ∘ 👁️ *Views*: ${video.views}\n`
            + `   ∘ ⏳ *Durasi*: ${video.timestamp}\n`
            + `   ∘ 📅 *Diunggah*: ${video.ago}\n`
            + `   ∘ 🔗 *URL*: ${video.url}\n`
        ).join('\n')
        
        await Yori.sendMessage(m.chat, { text: teks }, { quoted: m })        
    } catch (error) {
        console.error(error)
        Yorireply('⚠️ *Terjadi kesalahan saat melakukan pencarian. Silakan coba lagi.*')
    }
}
*/
case 'yts': case 'ytsearch': case 'youtubesearch': {
    if (!text) return Yorireply(`*⚠️ Contoh Penggunaan*: \n .yts Sempurna`);
    Yorireply(mess.wait);
    try {
        let yts = require('yt-search');
        let search = await yts(text);
        if (search.all.length === 0) return Yorireply('❌ *Tidak ada hasil yang ditemukan.*');        
        let teks = `🎬 *Hasil Pencarian Untuk*: _*${text}*_\n\n`;
        teks += `📥 *Ketik* _*.yta*_ *untuk download lagu* dari pencarian _${text}_\n`;
        teks += `📺 *Ketik* _*.ytv*_ *untuk download video* dari _${text}_\n\n`;
        teks += `*📌 Contoh Penggunaan*:\n`;
        teks += `∘ .yta Link YouTube ${text} (download audio)\n`;
        teks += `∘ .ytv Link YouTube ${text} (download video)\n\n`;
        teks += `🔎 *Top 10 Hasil Pencarian*: \n`;
        // Loop untuk menampilkan hasil pencarian
        let searchResults = search.all.slice(0, 10).map((video, i) => 
            `*${i + 1}. ${video.title}*\n`
            + `   ∘ 👁️ *Views*: ${video.views}\n`
            + `   ∘ ⏳ *Durasi*: ${video.timestamp}\n`
            + `   ∘ 📅 *Diunggah*: ${video.ago}\n`
            + `   ∘ 🔗 *URL*: ${video.url}\n`
        ).join('\n');        
        // Ambil video pertama sebagai thumbnail
        let thumbnail = search.all[0].thumbnail;
        teks += searchResults;
        await Yori.sendMessage(
            m.chat, 
            {
                image: { url: thumbnail },
                caption: teks,
            }, 
            { quoted: m }
        );        
    } catch (error) {
        console.error(error);
        Yorireply('⚠️ *Terjadi kesalahan saat melakukan pencarian. Silakan coba lagi.*');
    }
}
             break  

            case 'tesanying': {
                let msgs = generateWAMessageFromContent(m.chat,
                    {
                        viewOnceMessage: {
                            message: {
                                "messageContextInfo": {
                                    "deviceListMetadata": {},
                                    "deviceListMetadataVersion": 2
                                },
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: botname
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: botname
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        ...(await prepareWAMessageMedia({ image: fs.readFileSync('./data/image/menu.jpg') }, { upload: Yori.waUploadToServer })),
                                        title: `Kenapa Kak ${pushname} ? 😇*
`,
                                        subtitle: ownername,
                                        hasMediaAttachment: false
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [
                                            {
                                                "name": "quick_reply",
                                                "buttonParamsJson": `{"display_text":"Daftar Ucp 🔰","id":".daftarucp"}`
                                            },
                                            {
                                                "name": "quick_reply",
                                                "buttonParamsJson": "{\"display_text\":\"quick_reply\",\"id\":\".play a thousand year\"}"
                                            },
                                            {
                                                "name": "cta_url",
                                                "buttonParamsJson": "{\"display_text\":\"url\",\"url\":\"https://www.google.com\",\"merchant_url\":\"https://www.google.com\"}"
                                            },
                                            {
                                                "name": "cta_call",
                                                "buttonParamsJson": "{\"display_text\":\"call\",\"id\":\"message\"}"
                                            },
                                            {
                                                "name": "cta_copy",
                                                "buttonParamsJson": "{\"display_text\":\"copy\",\"id\":\"123456789\",\"copy_code\":\"message\"}"
                                            },
                                            {
                                                "name": "cta_reminder",
                                                "buttonParamsJson": "{\"display_text\":\"cta_reminder\",\"id\":\"message\"}"
                                            },
                                            {
                                                "name": "cta_cancel_reminder",
                                                "buttonParamsJson": "{\"display_text\":\"cta_cancel_reminder\",\"id\":\"message\"}"
                                            },
                                            {
                                                "name": "address_message",
                                                "buttonParamsJson": "{\"display_text\":\"address_message\",\"id\":\"message\"}"
                                            },
                                            {
                                                "name": "send_location",
                                                "buttonParamsJson": ""
                                            }
                                        ],
                                    })
                                })
                            }
                        }
                    },
                    {});

                return Yori.relayMessage(m.chat,
                    msgs.message,
                    {
                        messageId: m.key.id
                    });
            }
                break
            /*
            case 'play': case 'song': {
                            if (!text) return Yorireply(`Example : ${prefix + command} Sempurna`)
                            Yorireply(mess.wait)
                            if (global.db.data.users[m.sender].limit < 3) return Yorireply(mess.endLimit) // respon ketika limit habis
                            db.data.users[m.sender].limit -= 3
                            let yts = require ('yt-search')
                            let search = await yts(`${text}`)
                            let linknya = search.all[0].url
                            let bodytextnya = `ᴛɪᴛʟᴇ : *${search.all[0].title}*\nᴠɪᴇᴡs : *${search.all[0].views}*\nᴅᴜʀᴀᴛɪᴏɴ : *${search.all[0].timestamp}*\nᴜᴘʟᴏᴀᴅᴇᴅ : *${search.all[0].ago}*\nᴜʀʟ : *${linknya}*`
                           // rioo.sendMessage(m.chat, { image: { url: search.all[0].thumbnail },  caption: teks }, { quoted: m })
                            
                        let bokepp = generateWAMessageFromContent(from, {
              viewOnceMessage: {
                message: {
                    "messageContextInfo": {
                      "deviceListMetadata": {},
                      "deviceListMetadataVersion": 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                      body: proto.Message.InteractiveMessage.Body.create({
                        text: bodytextnya
                      }),
                      footer: proto.Message.InteractiveMessage.Footer.create({
                        text: botname
                      }),
                      header: proto.Message.InteractiveMessage.Header.create({
                            ...(await prepareWAMessageMedia({ image : { url : search.all[0].thumbnail }}, { upload: Yori.waUploadToServer})), 
                              title: ``,
                              gifPlayback: true,
                              subtitle: ownername,
                              hasMediaAttachment: false  
                            }),
                      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                          {
                            "name": "quick_reply",
                            "buttonParamsJson": `{"display_text":"Video MP4","id":"${prefix}ytmp4 ${linknya}"}`
                          },
                          {
                            "name": "quick_reply",
                            "buttonParamsJson": `{"display_text":"Audio MP3","id":"${prefix}ytmp3 ${linknya}"}`
                          }
                       ],
                      }),
                      contextInfo: {
                              mentionedJid: [m.sender], 
                              forwardingScore: 999,
                              isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterName: 'Yori Chan Music',
                                newsletterJid: '120363204138641225@newsletter',
                              serverMessageId: 143
                            }
                            }
                    })
                }
              }
            }, {})
            
            await Yori.relayMessage(bokepp.key.remoteJid, bokepp.message, {
              messageId: bokepp.key.id
            })
                        }
            */

//jika ingin aktifkan fitur play button silahkan
/*
            case 'play': case 'music': case 'song': {
                if (!text) return Yorireply(`*Example*: ${prefix + command} drunk text`)
                // Menghasilkan pengurangan acak antara 1 dan 5
                const randomReduction = Math.floor(Math.random() * 5) + 1;

                let search = await yts(text)
                let linknya = search.all[0].url
                let bodytextnya = `> Title : *${search.all[0].title}*\n> Views : *${search.all[0].views}*\n> Duration : *${search.all[0].timestamp}*\n> Uploaded : *${search.all[0].ago}*\n> Url : *${linknya}*`
                let msg = generateWAMessageFromContent(from, {
                    viewOnceMessage: {
                        message: {
                            "messageContextInfo": {
                                "deviceListMetadata": {},
                                "deviceListMetadataVersion": 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: bodytextnya
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    ...(await prepareWAMessageMedia({ image: { url: search.all[0].thumbnail } }, { upload: Yori.waUploadToServer })),
                                    title: ``,
                                    gifPlayback: true,
                                    subtitle: botname,
                                    hasMediaAttachment: false
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"Video Ytmp4","id":".ytmp4 ${linknya}"}`
                                        },
                                        {
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"Audio Ytmp3","id":".ytmp3 ${linknya}"}`
                                        }
                                    ],
                                }),
                                contextInfo: {
                                    mentionedJid: [m.sender],
                                    forwardingScore: 999,
                                    isForwarded: true,
                                }
                            })
                        }
                    }
                }, {})

                await Yori.relayMessage(msg.key.remoteJid, msg.message, {
                    messageId: msg.key.id
                })
            }
*/
                /*
                case 'play':
                case 'song':
                case 'music': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                if (!text) return Yorireply(`*[ Example : ${prefix + command} Boa - Duvet ]*`)
                if (text.length > 30) return Yorireply(`*Maksimal 30 Karakter*`)
                YoriLD()
                let res = await yts(text)
                let url = res.all;
                let result = url[Math.floor(Math.random() * url.length)]
                teks = `*[ Playing ]*
                 *⨠ Judul : ${result.title}*
                 *⨠ Upload : ${result.ago}*
                 *⨠ Url : ${result.url}*
                
                *[ Audio Akan Dikirim Dalam 1 - 5 Menit ]*
                `
                Yori.sendMessage(m.chat, { image: { url: result.thumbnail },  caption: teks }, { quoted: m })
                await downloadMp3(result.url)
                }
                */
                break
/*               
             case 'music': case 'play': case 'songs': {
  if (!q) return Yorireply(`[ NOTICE ] : Play2 Jiwaru days`);  
  try {
    Yorireply(mess.wait);   
    let yts = require("yt-search");
    let search = await yts(text);
    let anup3k = search.videos[0];
    let { title, thumbnail, timestamp, views, ago, url } = anup3k;  
    // Menggunakan node-fetch (pastikan sudah diinstal dengan npm install node-fetch)
    const fetch = require('node-fetch');
    let procees = await (await fetch(`https://widipe.com/download/ytdl?url=${url}`)).json();  
    let doc = { 
      audio: {
        url: procees.result.mp3
      },
      mimetype: 'audio/mp4',
      fileName: `${title}`,
      contextInfo: {
        externalAdReply: {
          showAdAttribution: true,
          mediaType: 2,
          mediaUrl: url,
          title: title,
          sourceUrl: url,
          thumbnail: await (await Yori.getFile(thumbnail)).data
        }
      }
    };
    
    await Yori.sendMessage(m.chat, doc, { quoted: m });
  } catch (e) {
    Yorireply('*terjadi error :*' + e);
  }
}
*/
case 'play': 
 case 'music': 
  case 'song': 
   case 'songs': {
  if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
  if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*');
  if (!text) return Yorireply(`[ Example ] : Music Forever - Young*`);

  // Search for the media using yts
  let search = await yts(text);
  let linknya = search.all[0].url;
  let bodytextnya = `🎵 *Title*: ${search.all[0].title}\n👁️ *Views*: ${search.all[0].views}\n⏳ *Duration*: ${search.all[0].timestamp}\n📅 *Uploaded*: ${search.all[0].ago}\n🔗 *URL*: ${linknya}`;

  // Generate the message content with the media preview and buttons
  let msg = generateWAMessageFromContent(from, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: bodytextnya
          },
          footer: {
            text: `Yori Chan -Multi Device`
          },
          header: {
            ...(await prepareWAMessageMedia({ image: { url: search.all[0].thumbnail } }, { upload: Yori.waUploadToServer })),
            title: '',
            gifPlayback: true,
            subtitle: botname,
            hasMediaAttachment: false
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  title: "Click Here",
                  sections: [
                    {
                      title: "YOUTUBE DONWLOAD",
                      highlight_label: 'POPULER',
                      rows: [
                        {
                          title: "Click To Audio",
                          description: "Only Audio",
                          id: `${prefix}ytmp3 ${linknya}`
                        },
                        {
                          title: "Click to Video 🎥",
                          description: "Only Video",
                          id: `${prefix}ytmp4 ${linknya}`
                        },                        
                      ]
                    },
                    {
                      title: "Spotify Search",
                      highlight_label: 'Spotify Pencarian',
                      rows: [
                        {
                          title: "Play Spotify",
                          description: "Antisipasi Jika Error",
                          id: `${prefix}spotipi ${text}`
                        }
                      ]
                    }
                  ]
                })
              }
            ]
          },
          contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: '120363204138641225@newsletter',
              newsletterName: botname,
              serverMessageId: 143
            }
          }
        }
      }
    }
  }, { quoted: m }, {});

  // Relay the message to the chat
  await Yori.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
}
/*
case 'songs': case 'song': case 'music': case 'play': {
if (!text) return Yorireply(`Kamu mau lagu apa, jalang?!, kasih tahu aku cara menggunakan fitur ini\nContoh: Wish You Were Here`);
await Yori.sendMessage(m.chat, { react: { text: "⏳",key: m.key,}
})
Yorireply(mess.wait) 
const ytdl = require('node-yt-dl')
let yts = await ytdl.search(text);
let yta = await ytdl.mp3(yts.data[0].url);
let jx = `- Title : ${yts.data[0].title}\n- Channel : ${yts.data[0].author.name}\n- Url : ${yts.data[0].url}/n Audio akan di kirim 1-3menit`;
let xj = await Yori.sendMessage(m.chat, {
 image: {
 url: yts.data[0].img
 },
 caption: jx
}, { quoted: fdoc })
try {
   Yori.sendMessage(m.chat, {
     audio: {
       url: yta.media
     },
     ptt: false,
     mimetype: 'audio/mpeg'
   }, { quoted: fvn })
} catch (e) {
   console.log(e)
   Yorireply('Kemungkinan Ada Problem Didalam Fitur Ini.....')
}
}
*/
                break

case 'chord': {
    if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
    if (!text) return Yorireply(`Masukan Nama Lagu yang ingin dilihat lirik`);

    try {
        // Fetch data dari API eksternal
        let response = await fetch(`https://widipe.com/chord?query=${text}`);
        let Yori_chord = await response.json();

        // Jika hasil ditemukan
        if (Yori_chord.result) {
            let judul = Yori_chord.result.title;
            let chordlagu = Yori_chord.result.chord;
            let Yori_result = `*Chord Lagu*\n*Nama Lagu : ${text}*\n*Chord Lagu :*\n${chordlagu}`;
            return Yorireply(Yori_result);
        } else {
            return Yorireply("⚠️ Nama Lagu Tidak Ditemukan");
        }
    } catch (error) {
        return Yorireply("⚠️ Terjadi kesalahan saat mencari chord lagu.");
    }
}

                break
              case 'liriklagu':
               case 'lirikmusic':
                case 'lirik': {
    if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
    if (!text) return Yorireply(`Masukan Nama Lagu yang ingin dilihat lirik`);

    try {
        // Fetch data dari API eksternal
        let response = await fetch(`https://widipe.com/lirik?text=${text}`);
        let Yori_lirik = await response.json();

        // Jika hasil ditemukan
        if (Yori_lirik.result) {
            let lirikmusic = Yori_lirik.result.lyrics;
            let Yori_result = `*Lirik Music*\n*Nama Music : ${text}*\n*Lirik music :*\n${lirikmusic}`;
            return Yorireply(Yori_result);
        } else {
            return Yorireply("⚠️ Nama Music Tidak Ditemukan");
        }
    } catch (error) {
        return Yorireply("⚠️ Terjadi kesalahan saat mencari Lirik Music.");
    }
}

                break
                /*
case 'tafsir': 
case 'tafsirsurah': {
    if (!text) return Yorireply(`✨ *Contoh Penggunaan* : .tafsir adam\n\n💡 *Tips* : Ketik nama surah yang ingin Anda ketahui tafsirnya, misalnya '.tafsir Yusuf'.`)
  Yorireply(`⏳ *Sedang mencari tafsir...* 📚\n\nTunggu sebentar, informasi tafsir akan segera kami tampilkan.`);
    try {
        let response = await fetch(`https://widipe.com/tafsirsurah?text=${text}`);
        let tafsirData = await response.json();
        if (tafsirData.result) {
            let surah = tafsirData.surah;
            let tafsir = tafsirData.tafsir;
            let artikel = tafsirData.type;
            let source = tafsirData.source;
            let tafsirResult = `🌿 *Tafsir Surah ${surah}*\n\n` +
                `• *Surah* : ${surah}\n` +
                `• *Tafsir* :\n${tafsir}\n\n` +
                `• *Kategori Tafsir* : ${artikel}\n` +
                `• *Sumber* : ${source}\n\n` +
                `Terima kasih telah menggunakan layanan kami! 🌸`;
            return Yorireply(tafsirResult);
        } else {
            return Yorireply("⚠️ *Maaf, Tafsir Surah Tidak Ditemukan*\n\nCoba cek kembali nama surah yang Anda masukkan.");
        }
    } catch (error) {
        return Yorireply("⚠️ *Terjadi Kesalahan!* 🙁\n\nMohon maaf, ada masalah saat mencari tafsir surah. Silakan coba lagi nanti.");
    }
}
*/
case 'tafsir': 
case 'tafsirsurah': {
    if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
    if (!text) return m.reply(`✨ *Contoh Penggunaan* : .tafsir adam\n\n💡 *Tips* : Ketik nama surah yang ingin Anda ketahui tafsirnya, misalnya '.tafsir Yusuf'.`)
  m.reply(`⏳ *Sedang mencari tafsir...* 📚\n\nTunggu sebentar, informasi tafsir akan segera kami tampilkan.`);
    try {
        let response = await fetchJson(`https://widipe.com/tafsirsurah?text=${text}`);
const results = response.result;
function getRandomElement(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}
const anubis = getRandomElement(results);
if (anubis && anubis.surah && anubis.tafsir && anubis.type && anubis.source) {
    let surah = anubis.surah;
    let tafsir = anubis.tafsir;
    let artikel = anubis.type;
    let source = anubis.source;

    let tafsirResult = `🌿 *Tafsir Surah ${surah}*\n\n` +
        `• *Surah* : ${surah}\n` +
        `• *Tafsir* :\n${tafsir}\n\n` +
        `• *Kategori Tafsir* : ${artikel}\n` +
        `• *Sumber* : ${source}\n\n` +
        `Terima kasih telah menggunakan layanan kami! 🌸`;

    return m.reply(tafsirResult);
} else {
    return m.reply("⚠️ *Maaf, data tafsir tidak lengkap atau tidak ditemukan.*");
}
    } catch (error) {
        return m.reply("⚠️ *Terjadi Kesalahan!* 🙁\n\nMohon maaf, ada masalah saat mencari tafsir surah. Silakan coba lagi nanti.");
    }
}
                break               
                /*
                case 'ytmp3': case 'youtubemp3': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                if (!q) return Yorireply(`🍃 *Kirim Link Youtube*`)
                await YoriLD ()
                downloadMp3(text)
                }
                */
                /*
                            case "ytmp3": {
                            const ytdlnew = require('./lib/ytdl.js') 
                             if (!text) return Yorireply(`• *Example :* .${command} https://www.youtube.com/xxxxxxx`)
                             Yori.sendMessage(m.chat, { react: { text: '🕒', key: m.key }})
                             let searchResponse = await ytdlnew(text)
                             Yori.sendMessage(m.chat, { audio: {url: searchResponse.mp3DownloadLink}, mimetype: "audio/mp4", ptt: true},
                                          { quoted:m})
                }
                */
                break
            /*
            case 'yt': case 'ytmp4': {
            const Yorivid = require('./lib/ytdl')
            if (args.length < 1 || !isUrl(text) || !Yorivid.isYTUrl(text)) Yorireply(`🍃 *Link Youtubenya Mana?*`)
            const vid=await Yorivid.mp4(text)
            Yorireply(mess.wait)
            const Yoricap=`🎁 *Youtube Selesai*
            🕒 *Durasi : ${vid.duration} Detik*
            📦 *Kualitas : ${vid.quality}*`
            await Yori.sendMessage(m.chat,{
                video: {url:vid.videoUrl},
                caption: Yoricap
            },{quoted:m})
            }
            */
            
          case 'yta': case 'mp3': case 'ytmp3': {
 if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
 if (isBan) return Yorireply(mess.ban)
 if (!text) return Yorireply('*PERMINTAAN ERROR!! CONTOH :*\n> *.ytmp3 <link youtube>*')
try {
Yorireply(mess.wait) 
 let procees = await (await fetch(`https://endpoint.web.id/downloader/yt-audio?key=Yori&url=${text}`)).json()
 let audio = procees.result; 
 Yori.sendMessage(m.chat, { 
 audio: { 
 url: audio.download_url 
 }, 
 mimetype: 'audio/mp4', contextInfo: {
 externalAdReply: {
 title: audio.title,
 body: `Type : ${audio.type}`,
 thumbnailUrl: audio.image,
 mediaType: 1,
 showAdAttribution: false,
 renderLargerThumbnail: true,
 },
 }, 
 }, { quoted: m });
} catch (e) {
 Yorireply('*Maybe Fiture Ini sedang mengalami Tahap Pengerjaan*')
}
}

/*
        case 'yta': case 'tomp3': case 'mp3': case 'ytmp3': {
if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
if (!q) return Yorireply(`*Kirim Link Youtube*`)
try {
Yorireply(mess.wait)
let proces = await (await fetch(`https://widipe.com/download/ytdl?url=${text}`)).json()
let audio = proces.result; Yori.sendMessage(m.chat,{audio:{url: audio.mp3 }, mimetype: 'audio/mp4' },{quoted: m})
} catch (e) {
Yorireply(mess.error);
}
}
*/
/*
   case 'yta': case 'ytmp3': {
        if (isBan) return Yorireply(mess.ban)
        if (!text) return Yorireply('*PERMINTAAN ERROR!! CONTOH :*\n> *.ytmp3 <link youtube>*')
    try {
     Yorireply(mess.wait) 
        let procees = await (await fetch(`https://api.shannmoderz.xyz/downloader/yt-audio?key=&url=${text}`)).json()
        let audio = procees.result; 
    Yori.sendMessage(m.chat, { 
      audio: { 
      url: audio.download_url 
    }, 
     mimetype: 'audio/mp4', contextInfo: {
       externalAdReply: {
       title: audio.title,
       body: `Type : ${audio.type}`,
       thumbnailUrl: audio.image,
       mediaType: 1,
       showAdAttribution: false,
       renderLargerThumbnail: true,
       },
    }, 
 }, { quoted: m });
 } catch (e) {
    Yorireply('*terjadi error*')
  }
}
*/
                break
/*
            case "ytmp4": {
                if (m.isGroup) {
                    m.reply(`Bot Telah Mengirimkan Video Di Private Chat !!!`)
                }
                if (!text) return Yorireply(`• *Example :* .${command} https://www.youtube.com/xxxxxxx`)
                Yori.sendMessage(m.chat, { react: { text: '🕒', key: m.key } })
                // const ytdlnew = require('./lib/ytdlnew.js') 
                let searchResponse = await ytdlnew(text)
                Yori.sendMessage(sender, { video: { url: searchResponse.mp4DownloadLink }, caption: '' }, { quoted: m })
            }
*/  
       
case 'ytmp4': {
 if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
 if (isBan) return m.reply(mess.ban)
 if (!text) return m.reply('*PERMINTAAN ERROR!! CONTOH :*\n> *.ytmp4 <link youtube>*')
try {
 m.reply('*Process sending video, mungkin membutuhkan 1-3 menit jika durasi video panjang!*')
 let proces = await (await fetch(`https://endpoint.web.id/downloader/yt-video?key=Yori&url=${text}`)).json()
 let video4 = proces.result; 
 Yori.sendMessage(m.chat,{video:{url: video4.download_url }, caption: video4.title},{quoted: m})
} catch (e) {
 m.reply('*Mungkin fitur ini masih dalam tahap perbaikan....*');
}
}
/*
case 'ytv':  case 'ytmp4': {
  if (!text) return Yorireply(' [ Example ] :*\n> *.ytmp4 <link youtube>*')
try {
  Yorireply(mess.wait) 
  let proces = await (await fetch(`https://api.shannmoderz.xyz/downloader/yt-video?url=${text}`)).json()
  let video4 = proces.result; Yori.sendMessage(m.chat,{video:{url: video4.download_url }, caption: video4.title},{quoted: m})
} catch (e) {
    Yorireply('*terjadi error :*' + e);
  }
}
*/
                break

            case 'git': case 'gitclone':
               if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                if (!args[0]) return Yorireply(`Mana link nya?`)
                if (!isUrl(args[0]) && !args[0].includes('github.com')) return Yorireply(`Link invalid!! 🤔`)
                YoriLD()
                let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
                let [, user, repo] = args[0].match(regex1) || []
                repo = repo.replace(/.git$/, '')
                let url = `https://api.github.com/repos/${user}/${repo}/zipball`
                let filename = (await fetch(url, { method: 'HEAD' })).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
                Yori.sendMessage(m.chat, { document: { url: url }, fileName: filename, mimetype: 'application/zip' }, { quoted: m }).catch((err) => Yorireply(mess.error))
                    .catch(console.error)
                break

            case 'tt':
            case 'tiktok': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                if (args.length == 0) return Yorireply(`🍃 *Link Tiktoknya Mana?*`)
                Yorireply(mess.wait)
                let Yoricap = `🎁 *Tiktok Selesai*`
                let res = await tiktok2(`${args[0]}`)
                Yori.sendMessage(m.chat, { video: { url: res.no_watermark }, caption: Yoricap, fileName: `tiktok.mp4`, mimetype: 'video/mp4' }).then(() => {
                    Yori.sendMessage(m.chat, { audio: { url: res.music }, fileName: `tiktok.mp3`, mimetype: 'audio/mp4' })
                })
            }
                break

            case 'ttslide':
            case 'tiktokslide': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                if (!text) return Yorireply(`🍃 *Link Tiktoknya Mana?`)
                if (!q.includes('tiktok')) return Yorireply(`Link Invalid!!`)
                Yorireply(mess.wait)
                let ban = m.mentionedJid[0] || m.sender || Yori.parseMention(args[0]) || (args[0].replace(/[@.+-]/g, '').replace(' ', '') + '@s.whatsapp.net') || '';
                try {
                    let anu = await fetchJson(`https://rest.dimasbotzz.my.id/api/downloader/tiktokSlide?url=${text}`)
                    for (let slide of anu.result.image) {
                        await sleep(1500)
                        await Yori.sendFile(ban, slide, ``, m)
                    }
                    await Yori.sendMessage(ban, { text: `🎁 *Tiktok Slide Selesai*` }, { quoted: m })
                } catch (error) {
                    Yorireply(`⚠️ *Kayaknya Ada Yang Error*`);
                }
            }
                break

            case 'tiktokht':
            case 'tthastag':
            case 'ttsearch': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                if (args.length == 0) return Yorireply(`🍃 *Contoh: ${prefix + command} Ohto Ai Edit*`)
                Yorireply(mess.wait)
                try {
                    let res = await tiktoks(`${args[0]}`)
                    Yori.sendMessage(m.chat, { video: { url: res.no_watermark }, caption: res.title, mimetype: 'video/mp4' })
                } catch (e) {
                    Yorireply(`⚠️ *Kayaknya Ada Yang Error, Coba Di Lain Waktu Ya*`);
                }
            }
                break

            case 'ttslide':
            case 'tiktokslide': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                if (!text) return Yorireply(`☘️ *Link Tiktoknya Mana?`)
                if (!isUrl(args[0])) return Yorireply(mess.link)
                Yorireply(mess.wait)
                try {
                    let anu = await fetchJson(`https://rest.dimasbotzz.my.id/api/downloader/tiktokSlide?url=${text}`)
                    for (let slide of anu.result.image) {
                        await sleep(1500)
                        await Yori.sendFile(m.chat, slide, ``, m)
                    }
                    await Yori.sendMessage(m.chat, { text: `🎁 *Tiktok Slide Selesai*` }, { quoted: m })
                } catch (error) {
                    return Yorireply(mess.error);
                }
            }
                break

            case 'fb': case 'fbdl': {
                if (!text) return Yorireply(`☘️ *Link Facebooknya Mana?*`)
                if (!isUrl(args[0])) return Yorireply(mess.link)
                Yorireply(mess.wait)
                try {
                    let anu = await fetchJson(`https://widipe.com/download/fbdown?url=${text}`)
                    let Yoricap = `🎁 *Facebook Selesai*`
                    Yori.sendMessage(m.chat, { video: { url: anu.result.url.urls[0].hd }, caption: Yoricap }, { quoted: m })
                } catch (error) {
                    return Yorireply(mess.error)
                }
            }
                break

            case 'cepcut': case 'capcut': {
                if (!text) return Yorireply(`*Link capcutnya Mana?*`)
                if (!isUrl(args[0])) return Yorireply(mess.link)
                Yorireply(mess.wait)
                try {
                    let anu = await fetchJson(`https://endpoint.web.id/downloader/capcut?key=Yori&url=${text}`)
                    let Yoricap = `*Nih Video Capcutnya >\\<*`
                    Yori.sendMessage(m.chat, { video: { url: anu.result.url.urls[0].hd }, caption: Yoricap }, { quoted: m })
                } catch (error) {
                    return Yorireply(mess.error)
                }
            }
                break

              case 'drive': case 'gdrive': {
		if (!args[0]) return Yorireply(`Enter the Google Drive link`)
	Yorireply(mess.wait)
	GDriveDl(args[0]).then(async (res) => {
		if (!res) throw res
        let txt = `• Name: ${res.fileName}\n• Size: ${res.fileSize}\n• Type: ${res.mimetype}`
		await Yorireply(txt)
        Yori.sendMessage(m.chat, { document: { url: res.downloadUrl }, fileName: res.fileName, mimetype: res.mimetype }, { quoted: m })
		
	})
  
}
                break
     
case 'twit': case 'twitter': 
  if (!text) return m.reply('masukkan url twitter');
  try {
    let tw = await (await fetch('https://endpoint.web.id/downloader/twitter?key=Yori&url=' + text)).json();
    let yori = tw.result.downloads[1];
    await Yori.sendMessage(m.chat, { video: { url: yori.url }, caption: `*SUCCESS RESOLUSI ${yori.text} *` },{ quoted: m });
} catch (e) {
    return m.reply(mess.error);
}
break
                
            /*
            case 'ig':
            case 'igdl': case 'instagram': {
            if (!text) return Yorireply("- Example : Instagram [ Link ]*")
            Yorireply(mess.wait)
            try {
                res = await fetch(`https://api.kyuurzy.site/api/download/igdl?query=${text}`)
              } catch (error) {
                return Yorireply(`[ NOTICE : - *Kayaknya Ada Error Nih : ${error.message} ]*`)
              }
              let api_response = await res.json()
              if (!api_response || !api_response.data) {
                return Yorireply(`*[ GA KETEMU NI KAK [ BUG ] ]*`)
              }
              const mediaArray = api_response.data;
              for (const mediaData of mediaArray) {
                const mediaType = mediaData.type
                const mediaURL = mediaData.url_download
                let Yoricap = `*[ INSTAGRAM DONE ]*`
                if (mediaType === 'video') {
                  Yori.sendMessage(m.chat, {video: {url: mediaURL}, caption: Yoricap}, {quoted: m})
                } else if (mediaType === 'image') {
                  Yori.sendMessage(m.chat, { image: {url: mediaURL}, caption: Yoricap}, {quoted: m})
                }
              }
            }
            */
            /*
            case 'ig':
            case 'igdl':
            case 'instagram': {
            if (!text) return Yorireply(`*Example : ${prefix} [ Link Instagram ]*`)
                            if (!isUrl(args[0])) return Yorireply(mess.link)
                            Yorireply(mess.wait)
                            const res = await Yori.download.igdl.v2(args[0])
                            let yorichan = `*[ INSTAGRAM SELESAI ]*`
                            Yori.sendMessage(m.chat, { video: { url: res[0] }, mimetype: 'video/mp4', caption: yorichan }, { quoted: m }).catch((err) => Yorireply(mess.error))
                        }
            */
            /*
            case 'ig':
            case 'igdl': case 'Instagram': {
            if (!text) return Yorireply(`- *Example : ${prefix} Instagram [ Link ]*`)
            if (!isUrl(args[0])) return Yorireply(mess.link)
            Yorireply(mess.wait)
            const { igdl, igdl2 } = require('./lib/igdl.js')
            const res = await igdl(args[0])
            const url = res.data[0]
            let yoricap = `*[ INSTAGRAM SELESAI ]*`
            Yori.sendMessage(m.chat, {video: { url: url}, mimetype: 'video/mp4', caption : yoricap}, {quoted: m}).catch((err) => Yorireply(mess.error))
            }
            */
            /*
            case 'ig': case 'igdl': case 'instagram': {
                if (args.length == 0) return Yorireply(`Example: ${prefix + command} https://www.instagram.com/p/CJ8XKFmJ4al/?igshid=1acpcqo44kgkn`)
                let ig = await fetchJson(`https://api.kyuurzy.site/api/download/igdl?query=${text}`)
                let url = ig.result.media
                if (!url.length == 1) {
                    if (m.isGroup) {
                        ig.result.media.forEach(async (k) => {
                            await Yori.sendMessage(m.sender, {
                                image: {
                                    url: k
                                }
                            }, {
                                quoted: m
                            });
                        })

                        Yorireply(`All photos have been sent to your private chat`)
                    } else {
                        ig.result.media.forEach(async (k) => {
                            await Yori.sendMessage(from, {
                                image: {
                                    url: k
                                }
                            }, {
                                quoted: m
                            });
                        })
                    }
                } else {
                    Yori.sendMessage(m.chat, {
                        video: {
                            url: ig.result.media[0]
                        },
                        caption: mess.done
                    },
                        { quoted: m })
                }
            }
            */
            /*
            case'instagram': case 'igdl': case 'ig': case 'igvideo': case 'igimage': case 'igvid': case 'igimg': {
	  if (!text) return Yorireply(`Anda perlu memberikan URL video, postingan, reel, gambar Instagram apa pun`)
	  Yorireply(mess.wait)
 try {
    const data = await fetchJson(`https://widipe.com/download/igdl?url=${encodeURIComponent(text)}`);
    if (data && data.result && data.result.length > 0 && data.result[0].url) {
        const hasil = data.result[0].url;
        const cap = `Ini dia kak🔥`;
        Yori.sendMessage(m.chat, {video: {url: hasil}, caption: cap}, {quoted: m});
    } else {
        throw new Error('URL not found in result');
    }
} catch (error) {
    console.error(error);
    const cap = `Maaf, videonya nggak bisa diambil. Ini gambar yang tersedia:`;
    Yori.sendMessage(m.chat, { image: {url: hasil}, caption: cap}, {quoted: m});
}
}
*/
         case 'ig':
         case 'igdl': {
    if (!text) return Yorireply(`☘️ *Link Instagramnya Mana?*`)
    if (!isUrl(args[0])) return Yorireply(mess.link)
      Yorireply(mess.wait)
        try {   
         let anu = await fetchJson(`https://widipe.com/download/igdl?url=${text}`)
         let yoricap = `🎁 *Instagram Selesai*`
Yori.sendMessage(m.chat, { video: { url: anu.result[0].url }, caption: yoricap }, { quoted: m })
} catch (error) {
    return Yorireply(mess.error)
}
}
                break

            case 'igsl':
            case 'igslide': {
                if (!text) return Yorireply("🍃 *Link Instagramnya Mana?*")
                Yorireply(mess.wait)
                try {
                    res = await fetch(`https://api.shannmoderz.xyz/download/instagram?url=${text}`)
                } catch (error) {
                    return Yorireply(`🍃 *Kayaknya Ada Error Nih : ${error.message}*`)
                }
                let api_response = await res.json()
                if (!api_response || !api_response.data) {
                    return Yorireply(`⚠️ *Gak Ketemu Nih, Coba Di Ulang*`)
                }
                const mediaArray = api_response.data;
                for (const mediaData of mediaArray) {
                    const mediaType = mediaData.type
                    const mediaURL = mediaData.url_download
                    let Yoricap = `🎁 *Instagram Selesai*`
                    if (mediaType === 'video') {
                        Yori.sendMessage(m.chat, { video: { url: mediaURL }, caption: Yoricap }, { quoted: m })
                    } else if (mediaType === 'image') {
                        Yori.sendMessage(m.chat, { image: { url: mediaURL }, caption: Yoricap }, { quoted: m })
                    }
                }
            }
                break
/*
   case 'mediafire': case 'mf': {
        if (isBan) return Yorireply(mess.ban)
        if (!text) return Yorireply(` • *Example*  ${command} (link}`)
        if (q.startsWith("https://www.mediafire.com")){
         const { mediafire } = require('./scrape/mediafire')
         const baby1 = await mediafire(text)
         Yorireply(mess.wait) 
         const result = `*MEDIAFIRE DOWNLOADER*
📄 *Name* : ${baby1.filename}
⚖️ *Size* : ${baby1.filesize}
📨 zType* : ${baby1.filetype}
🔗 *Link* : ${baby1.link}
📋 *UploadAt*: ${baby1.uploadAt}
`
         const contextInfo = {
    mentionedJid: [sender],
     forwardingScore: 9999, 
      isForwarded: true, 
       forwardedNewsletterMessageInfo: {
        newsletterJid:'120363204138641225@newsletter',
         serverMessageId: 20,
          newsletterName: `Yori Chan | New 2024`,
      }
   }
Yori.sendMessage(m.chat, {
    document: {url: baby1.link}, 
  mimetype: "application/zip",
   fileName: `${baby1.filename}`,
    caption: result,
     contextInfo,
}, { quoted: m }).catch((err) => Yorireply('_⛩️Maaf terjadi Kesalahan!_'))
    if (baby1.filesize > 400000 && !isCreator){
    if (m.sender.startsWith("62"))
await Yorireply("File size melebihi batas,\nbatas yang di tentukan adalah 400mb")              
return
     }
   }
}
*/

case 'mediafire': {
  if (isBan) return m.reply(mess.ban);
  if (!text) return m.reply('masukan link nya!')
  const baby1 = await (await fetch('https://endpoint.web.id/downloader/mediafire?key=Yori&url=' + text)).json();
  const yori = baby1.result;
  const extension = yori.filename.split('.').pop().toLowerCase();

  const mimeTypes = {
      'pdf': 'application/pdf',
      'jpg': 'image/jpeg',
      'jpeg': 'image/jpeg',
      'png': 'image/png',
      'gif': 'image/gif',
      'mp4': 'video/mp4',
      'mp3': 'audio/mpeg',
      'zip': 'application/zip',
      'txt': 'text/plain',
      //tambahin mimetype lain kalo perlu
  };
  const mimeType = mimeTypes[extension] || 'application/octet-stream';

  const result4 = `🔧 *MEDIAFIRE DOWNLOADER*\r\n\r\n🔖 *Name* : ${yori.name}\r\n💽 *Size* : ${yori.size}\r\n📌 *Desc* : ${yori.desc}`
  
  Yori.sendMessage(m.chat, {
      document: { url: yori.media },
      fileName: yori.filename,
      mimetype: mimeType,
      caption: result4
  }, { quoted: m });
}
               break

            case 'ssweb':{
if (!q) return Yorireply(`🍃 *Contoh ${prefix+command} Link Kamu*`)
Yorireply(mess.wait)
global.sh = q
let krt = await ssweb(global.sh)
Yori.sendMessage(from ,{ image: krt.result, caption: mess.success },{ quoted: m })
}
                break

            case 'wm': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                let teks = `${text}`
                try {
                    if (!quoted) Yorireply`Balas Video/Image Dengan Caption ${prefix + command}`
                    if (/image/.test(mime)) {
                        let media = await quoted.download()
                        let encmedia = await Yori.sendImageAsSticker(from, media, m, { packname: `${teks}`, author: global.author })
                        await fs.unlinkSync(encmedia)
                    }
                } catch (e) {
                    Yorireply(mess.error)
                }
            }
                break
case 'pin2': {
if (!text) return Yorireply(`Use example ${prefix+ command} Trisha Jkt48`)
    const { googleImage } = require('@bochilteam/scraper')
    const anutrest = await googleImage(text)
    let image = anutrest[Math.floor(Math.random() * anutrest.length)]
let msgs = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Hi ${pushname}\n_*Here is the result of: ${text}*_`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: botname
          }),
          header: proto.Message.InteractiveMessage.Header.create({
          hasMediaAttachment: false,
          ...await prepareWAMessageMedia({ image: { url: image } }, { upload: Yori.waUploadToServer })
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [{
            "name": "quick_reply",
              "buttonParamsJson": `{\"display_text\":\"Next Image\",\"id\":\"${prefix + command} ${text}\"}`
            }],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: '120363204138641225@newsletter',
                  newsletterName: botname,
                  serverMessageId: 143
                }
                }
       })
    }
  }
}, { quoted: m })
return await Yori.relayMessage(m.chat, msgs.message, {})
}
                break
            /*
            case 'pin': case 'pinterest':{
            if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
            if (!text) return Yorireply(`*[ Example ] ${prefix+command} Anime*`)
            let anu = await pinterest(text)
            let result = anu[Math.floor(Math.random() * anu.length)]
            Yori.sendMessage(m.chat, { image: { url: result }, caption: '*[ PINTEREST DOWNLOAD ]*'}, { quoted: m })
            }
            */

            case 'pin': case 'pinterest': {
                if (!q) return Yorireply(mess.query);
                //try {
                await Yorireply(mess.wait);

                async function createImage(url) {
                    const { imageMessage } = await generateWAMessageContent({
                        image: {
                            url
                        }
                    }, {
                        upload: Yori.waUploadToServer
                    });
                    return imageMessage;
                }

                function shuffleArray(array) {
                    for (let i = array.length - 1; i > 0; i--) {
                        const j = Math.floor(Math.random() * (i + 1));
                        [array[i], array[j]] = [array[j], array[i]];
                    }
                }

                let push = [];
                let { data } = await axios.get(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${q}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${q}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);
                let res = data.resource_response.data.results.map(v => v.images.orig.url);

                shuffleArray(res); // Mengacak array
                let ult = res.splice(0, 10); // Mengambil 10 gambar pertama dari array yang sudah diacak
                let i = 1;

                for (let pus of ult) {
                    push.push({
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: `Image ${i++} / 10`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.fromObject({
                            text: `*© Yori Chan | New 2023 - 2024*`
                        }),
                        header: proto.Message.InteractiveMessage.Header.fromObject({
                            title: `*Image Hasil Dari :* ${text}`,
                            hasMediaAttachment: true,
                            imageMessage: await createImage(pus)
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                            buttons: [
                                {
                                    name: "cta_url",
                                    buttonParamsJson: `{"display_text":"Pinterest","url":"https://www.pinterest.com/search/pins/?rs=typed&q=${text}","merchant_url":"https://www.pinterest.com/search/pins/?rs=typed&q=${text}"}`
                                }
                            ]
                        })
                    });
                }

                const msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: `*🔍 Hasil Pencarian :* ${text}`
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: ` © Yori Chan | New 2023 - 2024`
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    hasMediaAttachment: false
                                }),
                                carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                                    cards: [
                                        ...push
                                    ]
                                })
                            })
                        }
                    }
                }, {});

                await Yori.relayMessage(m.chat, msg.message, {
                    messageId: msg.key.id
                });

            }
                break

            case 'enka':
            case 'profilgi':
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                if (args.length == 0) return Yorireply(`🍃 *Contoh: ${prefix + command}* 800000001`)
                Yorireply('🍃 *Sabar Yaa*')
                global.sh = `https://enka.network/u/${args[0]}`
                let krt = await ssweb(global.sh)
                axios.get(`https://enka.network/api/uid/${args[0]}?info`).then(({ data }) => {
                    var caption = `🍃 *Profile Genshin*\n\n  *⨠ Nickname* : *${data.playerInfo.nickname}*\n`
                    caption += `  *⨠ Adventure Rank* : *${data.playerInfo.level}*\n`
                    caption += `  *⨠ Signature* : *${data.playerInfo.signature}*\n`
                    caption += `  *⨠ World Level* : *${data.playerInfo.worldLevel}*\n\n`
                    caption += `  *⨠ Achievement* : *${data.playerInfo.finishAchievementNum}*\n`
                    caption += `  *⨠ Abyss* : *Floor ${data.playerInfo.towerFloorIndex} Chamber ${data.playerInfo.towerLevelIndex}*\n\n`
                    caption += `🎁 *Lebih Lengkap Cek Disini :* https://enka.network/u/${args[0]}\n`
                    Yori.sendMessage(from, { image: krt.result, caption: caption }, { quoted: m })
                })
                    .catch(console.error)
                break

            case 'neko':
            case 'waifu': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                let res = await fetch(`https://waifu.pics/api/sfw/${command}`)
                let json = await res.json()
                let cap = `*Sukses* 😋`
                Yori.sendMessage(from, { image: { url: json.url }, caption: `*Alamak* 😋` }, { quoted: m }).catch(err => {
                    return ('Error!')
                })
            }
                break
            /*
            lu bisa fix gege si😂
            case 'waifu': {
                  let response = await fetch(`https://waifu.pics/api/sfw/${command}`)
                  let json = await response.json() // Get the image data as a buffer
                  let msgs = generateWAMessageFromContent(m.chat, {
              viewOnceMessage: {
                message: {
                    "messageContextInfo": {
                      "deviceListMetadata": {},
                      "deviceListMetadataVersion": 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                      body: proto.Message.InteractiveMessage.Body.create({
                        text: `Hi ${pushname}\n_*Berikut Adalah Foto ${command}*_`
                      }),
                      footer: proto.Message.InteractiveMessage.Footer.create({
                        text: botname
                      }),
                      header: proto.Message.InteractiveMessage.Header.create({
                      hasMediaAttachment: false,
                      ...await prepareWAMessageMedia(from, { image: { url: response.url }}, { upload: Yori.waUploadToServer })
                      }),
                      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [{
                        "name": "quick_reply",
                          "buttonParamsJson": `{\"display_text\":\"Next To Photo ➡️\",\"id\":\"${prefix+command}"}`
                        }],
                      }), 
                      contextInfo: {
                              mentionedJid: [m.sender], 
                              forwardingScore: 999,
                              isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                              newsletterJid: '120363204138641225@newsletter',
                              newsletterName: botname,
                              serverMessageId: 143
                            }
                            }
                   })
                }
              }
            }, { quoted: m })
            return await Yori.relayMessage(m.chat, msgs.message, {})
                        }
                        
            break
            */

            case 'cry': case 'kill': case 'hug': case 'pat': case 'lick':
            case 'kiss': case 'bite': case 'yeet': case 'bully': case 'bonk':
            case 'wink': case 'poke': case 'nom': case 'slap': case 'smile':
            case 'wave': case 'awoo': case 'blush': case 'smug': case 'glomp':
            case 'happy': case 'dance': case 'cringe': case 'cuddle': case 'highfive':
            case 'handhold':
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                axios.get(`https://api.waifu.pics/sfw/${command}`)
                    .then(({ data }) => {
                        Yori.sendImageAsSticker(from, data.url, m, { packname: global.packname, author: global.author })
                    })
                break

            case 'bucin': case 'dare': case 'faktaunik': case 'fml': case 'katabijak': case 'katacinta': case 'katagalau': case 'katahacker': case 'katailham': case 'katasenja': case 'katasindiran': case 'motivasi': case 'nickff': case 'pantun': case 'puisi': case 'quotesislamic': case 'quotespubg': case 'truth': case 'sad': case 'galau': case 'katagalau': case 'quotesgalau': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                const t3xt = require(`./database/teks/${command}.json`)
                const r4andT3xt = t3xt[Math.floor(Math.random() * t3xt.length)]
                Yori.sendMessage(from, { text: r4andT3xt }, { quoted: m })
            }
                break

            case 'quotes':
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                var resi = await Quotes()
                teks = `\n🍃 *Author: ${resi.author}*\n`
                teks = `\n🎁 *Quotes:*\n`
                teks = `🍃 *${resi.quotes}*\n`
                Yorireply(teks)
                break

            case 'quotesanime': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                const an1 = JSON.parse(fs.readFileSync("./data/quotesanime.json"))
                const r4ndan1 = an1[Math.floor(Math.random() * an1.length)]
                const tgt99 = `*🍃 Random Quotes Anime*

🍃 *Nama Anime : ${r4ndan1.anime}*
🍁 *Nama Character : ${r4ndan1.character}*
🍁 *Episode : ${r4ndan1.episode}*

🎁 *Quotes : ${r4ndan1.quotes}*`
                Yori.sendMessage(from, { text: tgt99 }, { quoted: len })
            }
                break

            case 'kompasnews':
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                KompasNews().then(async (res) => {
                    no = 0
                    teks = ""
                    for (let i of res) {
                        no += 1
                        teks += `\n🍃 *Berita ${no.toString()}*\n`
                        teks += ` *⨠ Berita: ${i.berita}*\n`
                        teks += ` *⨠ Upload: ${i.berita_diupload}*\n`
                        teks += ` *⨠ Jenis: ${i.berita_jenis}*\n`
                        teks += ` *⨠ Link:* ${i.berita_url}\n`
                    }
                    teks += ""
                    Yori.sendMessage(m.chat, { image: { url: res[0].berita_thumb }, caption: teks }, { quoted: m })
                })
                break

            case 'detiknews':
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                DetikNews().then(async (res) => {
                    no = 0
                    teks = ""
                    for (let i of res) {
                        no += 1
                        teks += `\n🍃 *Berita ${no.toString()}*\n`
                        teks += ` *⨠ Berita: ${i.berita}*\n`
                        teks += ` *⨠ Upload: ${i.berita_diupload}*\n`
                        teks += ` *⨠ Link:* ${i.berita_url}\n`
                    }
                    teks += ""
                    Yori.sendMessage(m.chat, { image: { url: res[0].berita_thumb }, caption: teks }, { quoted: m })
                })
                break

            case 'dailynews':
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                DailyNews().then(async (res) => {
                    no = 0
                    teks = ""
                    for (let i of res) {
                        no += 1
                        teks += `\n🍃 *Berita ${no.toString()}*\n`
                        teks += ` *⨠ Berita: ${i.berita}*\n`
                        teks += ` *⨠ Link:* ${i.berita_url}\n`
                    }
                    teks += ""
                    Yori.sendMessage(m.chat, { image: { url: res[0].berita_thumb }, caption: teks }, { quoted: m })
                })
                break

            case 'cuaca': {
            if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (!text) throw `Pengunaan: \n${usedPrefix + command} <teks>\n\nExample:\n${usedPrefix + command} Surabaya`
                Yorireply(mess.wait)
                let res = await fetch(API('https://api.openweathermap.org', '/data/2.5/weather', {
                    q: text,
                    units: 'metric',
                    appid: '060a6bcfa19809c2cd4d97a212b19273'
                }))
                if (!res.ok) throw 'location not found'
                let json = await res.json()
                if (json.cod != 200) throw json
                let teks = `乂 C U A C A

        Lokasi: ${json.name}
        Negara: ${json.sys.country}
        Cuaca: ${json.weather[0].description}
        Suhu saat ini: ${json.main.temp} °C
        Suhu tertinggi: ${json.main.temp_max} °C
        Suhu terendah: ${json.main.temp_min} °C
        Kelembapan: ${json.main.humidity} %
        Angin: ${json.wind.speed} km/jam
        `
                Yori.sendMessage(m.chat, {
                    text: teks, contextInfo:
                    {
                        "externalAdReply": {
                            "title": botname,
                            "body": command + ' ' + text,
                            "showAdAttribution": true,
                            "previewType": "PHOTO",
                            "sourceUrl": 'https://chat.whatsapp.com/IRimbEMvL16AzrxxPGJJqU',
                            "thumbnailUrl": weather,

                        }
                    }
                })
            }
                break

            case 'inews':
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                iNews().then(async (res) => {
                    no = 0
                    teks = ""
                    for (let i of res) {
                        no += 1
                        teks += `\n🍃 *Berita ${no.toString()}*\n`
                        teks += ` *⨠ Berita: ${i.berita}*\n`
                        teks += ` *⨠ Upload: ${i.berita_diupload}*\n`
                        teks += ` *⨠ Jenis: ${i.berita_jenis}*\n`
                        teks += ` *⨠ Link:* ${i.berita_url}\n`
                    }
                    teks += ""
                    Yorireply(teks)
                })
                break

            case 'gempa':
            case 'infogempa': {
              if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                try {
                    const res = await fetch('https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json')
                    const data = await res.json()
                    const gempa = data.Infogempa.gempa
                    let txt = `*${gempa.Wilayah}*\n\n`
                    txt += `Tanggal : ${gempa.Tanggal}\n`
                    txt += `Waktu : ${gempa.Jam}\n`
                    txt += `Potensi : *${gempa.Potensi}*\n\n`
                    txt += `Magnitude : ${gempa.Magnitude}\n`
                    txt += `Kedalaman : ${gempa.Kedalaman}\n`
                    txt += `Koordinat : ${gempa.Coordinates}`
                    if (gempa.Dirasakan.length > 3) {
                        txt += `\nDirasakan : ${gempa.Dirasakan}`
                    }

                    Yori.sendMessage(m.chat, {
                        text: txt, contextInfo: {
                            "externalAdReply": {
                                "title": botname,
                                "body": command,
                                "showAdAttribution": true,
                                "mediaType": 1,
                                "sourceUrl": 'https://chat.whatsapp.com/IRimbEMvL16AzrxxPGJJqU',
                                "thumbnailUrl": thumb, "renderLargerThumbnail": true
                            }
                        }
                    }, { quoted: m })
                } catch (e) {
                    console.log(e)
                    Yorireply('[!] Ada Yang Error.')
                }
            }
                break

            case 'kontan':
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                KontanNews().then(async (res) => {
                    teks = ""
                    no = 0
                    for (let i of res) {
                        no += 1
                        teks += `\n🍃 *Berita ${no.toString()}*\n`
                        teks += ` *⨠ Berita: ${i.berita}*\n`
                        teks += ` *⨠ Jenis: ${i.berita_jenis}*\n`
                        teks += ` *⨠ Link:* ${i.berita_url}\n`
                    }
                    teks += ""
                    Yori.sendMessage(m.chat, { image: { url: res[0].berita_thumb }, caption: teks }, { quoted: m })
                })
                break

            case 'meme': {
               if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                var reis = await JalanTikusMeme()
                teks = ""
                teks += "🍃 *Random Meme*\n\n"
                teks += `🎁 *Source Meme :* ${reis}`
                teks += ""
                Yori.sendMessage(m.chat, { image: { url: reis }, caption: teks }, { quoted: m })
            }
                break
                case 'carbon':
 if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
 if (isBan) return Yorireply(mess.ban)
 if (!text) return Yorireply(`*PERMINTAAN ERROR!! CONTOH :*\n> .carbon const axios = require('axios')`)
 try {
 Yorireply(mess.wait) 
 let car = await (await fetch(`https://endpoint.web.id/tools/carbon?key=Yori&query=${text}`)).json()
 let bon = car.result
 Yori.sendMessage(m.chat,{image:{url: bon }, caption: '*FOR YOU*'},{quoted: m})
 okk()
 } catch (err) {
 Yorireply(mess.error)
 }
                break

            case 'gcreate':
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (isBan) return Yorireply('*Lu Di Ban Owner*')
                if (!isCreator) return Yorireply(mess.owner)
                if (!text) return Yorireply(`*Contoh* :\n#group create 1 minggu `)
                let cret = await Yori.groupCreate(args.join(" "), [])
                let response = await Yori.groupInviteCode(cret.id)
                Yori.sendMessage(m.chat, {
                    text: `🍃 *Create Group*

🍃 *CGroup Selama ${text} Telah Di Proses, Silahkan Masuk Group Melalui Link Yang Sudah Di Sediakan*

🍃 *Bot : ${botname}*
🍃 *Time : ${moment(cret.creation * 1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")} WIB_https://chat.whatsapp.com/${response}*
`, m
                })
                Yorireply('🎁 *Link Group Khusus Berhasil Dikirim Melalui Chat Pribadi Anda*')
                break

            case 'smeme':
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                if (!text) Yorireply`Balas Image Dengan Caption ${prefix + command}`
                if (/image/.test(mime)) {
                    mee = await Yori.downloadAndSaveMediaMessage(quoted)
                    mem = await uptotelegra(mee)
                    kaytid = await getBuffer(`https://api.memegen.link/images/custom/-/${text}.png?background=${mem}`)
                    Yori.sendImageAsSticker(m.chat, kaytid, m, { packname: global.packname, author: global.author })
                }
                break

            case 'tomp3': {
                if (!/video/.test(mime) && !/audio/.test(mime)) Yorireply`Kirim/Balas Video/Audio Yang Ingin Dijadikan MP3 Dengan Caption ${prefix + command}`
                Yorireply(mess.wait)
                if (!quoted) Yorireply`*Send/Reply the Video/Audio You Want to Use as Audio With Caption* ${prefix + command}`
                let media = await Yori.downloadMediaMessage(quoted)
                let { toAudio } = require('./lib/converter')
                let audio = await toAudio(media, 'mp4')
                Yori.sendMessage(m.chat, { document: audio, mimetype: 'audio/mpeg', fileName: `Convert By ${Yori.user.name}.mp3` }, { quoted: m })
            }
                break

            case 'tourl': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                Yorireply(mess.wait)
                let media = await Yori.downloadAndSaveMediaMessage(quoted)
                if (/image/.test(mime)) {
                    let anu = await TelegraPh(media)
                    Yorireply(util.format(anu))
                } else if (!/image/.test(mime)) {
                    let anu = await UploadFileUgu(media)
                    Yorireply(util.format(anu))
                }
                await fs.unlinkSync(media)
            }
            /*
           case 'tourl': {
      if (isBan) return m.reply(mess.ban);
      if (!/video/.test(mime) && !/image/.test(mime)) {
    return Yorireply(`*[ PERMINTAAN ERROR!! PESAN ] :*\\n> *Reply/Send Gambar/Video Dengan Caption .tourl*`);
  }
  if (!quoted) {
    return Yorireply(`*[ PERMINTAAN ERROR!! PESAN ] :*\\n> *Reply/Send Gambar/Video Dengan Caption .tourl*`);
  }
  let media = await Yori.downloadAndSaveMediaMessage(quoted);
  let anu = await yoricdn(media);
  if (anu && anu.status) {
    Yorireply(JSON.stringify(anu, null, 2)); // Send the entire response as a formatted JSON string
  } else {
    Yorireply(`*ERROR: Tidak dapat mengambil URL dari media.*`);
  }
  await fs.unlinkSync(media);
}
*/
/*
case'tourl':{
let q = m.quoted ? m.quoted : m
Yori.sendMessage(m.chat, { react: { text: '🕒', key: m.key }});
let media = await uploadImage()
let uploadImage = require('../lib/uploadImage')
let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime)
let link = await (isTele ? uploadImage : uploadFile)(media)
const baten = new Button()
let ads = baten.setBody(`${isTele ? '(Tidak ada tanggal kadaluwarsa)' : '(Tidak diketahui)'}\n ${media.length} Byte(s)`)
ads += baten.addCopy("Copy Url Media", `${link}`);
ads += baten.run(m.chat, Yori, fmage);
}
*/
                break

            case 'toimg': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                Yorireply(mess.wait)
                const getRandom = (ext) => {
                    return `${Math.floor(Math.random() * 10000)}${ext}`
                }
                if (!m.quoted) return Yorireply(`_Reply dengan stiker untuk di jadikan foto/image._`)
                let mime = m.quoted.mtype
                if (mime == "imageMessage" || mime == "stickerMessage") {
                    let media = await Yori.downloadAndSaveMediaMessage(m.quoted)
                    let name = await getRandom('.png')
                    exec(`ffmpeg -i ${media} ${name}`, (err) => {
                        fs.unlinkSync(media)
                        let buffer = fs.readFileSync(name)
                        Yori.sendMessage(m.chat, { image: buffer }, { quoted: m })
                        fs.unlinkSync(name)
                    })

                } else return Yorireply(`Please Jangan Reply Stiker Yang Bergerak`)
            }
                break

case 'rvo':
case 'readviewonce': {
	if (!text) return m.reply(`Balas untuk melihat pesan sekali`)
	if (text.mtype !== 'viewOnceMessageV2') return m. reply(`This is not a view once message`)
    let msg = text.message
    let type = Object.keys(msg)[0]
    let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : 'video')
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return Yori.sendFile(m.chat, buffer, 'media.mp4', msg[type].caption || '', m)
    } else if (/image/.test(type)) {
        return Yori.sendFile(m.chat, buffer, 'media.jpg', msg[type].caption || '', m)
    }
}
               break
            case 'fetch': case 'get': {
                if (!text.startsWith('http')) return Yorireply(`No Query?\n\nExample : ${prefix + command} https://google.com`)
                try {
                    const res = await axios.get(isUrl(text) ? isUrl(text)[0] : text)
                    if (!/json|html|plain/.test(res.headers['content-type'])) {
                        await Yorireply(text)
                    } else {
                        Yorireply(util.format(res.data))
                    }
                } catch (e) {
                    Yorireply(util.format(e))
                }
            }
                break
/*
            case 'confes':
            case 'confess':
            case 'menfes':
            case 'menfess': {
if (!text) return Yorireply(`*Format : Menfess Nomor|Pengirim|Pesan*\n\n📑 *Contoh : Menfes 628xxxxxx|Yori|Semangat Yah*`)
let nomor = q.split('|')[0] ? q.split('|')[0] : q
let yori_nama = q.split('|')[1] ? q.split('|')[1] : q
let yorichat = q.split('|')[2] ? q.split('|')[2] : ''
if (yorichat.length < 1) return Yorireply(`⚠️ *Tolong Isi Semua Data Dengan Baik*`)
let yori_txt = `☘️ *Halo Ada Menfess Nih*\n🎁 *Dari : ${yori_nama}* \n📃 *Pesan :*\n${yorichat}\n\n⚠️ *Menfess Ini Dikirim Oleh Bot Lenwy*`
Yori.sendMessage(`${nomor}@s.whatsapp.net`, { caption: yori_txt, image: {url: `https://telegra.ph/file/f76287ac4c1968857cf1e.png`}})
Yorireply(`☘️ *Sukses Mengirim Menfess*`)    
}
*/
case 'menfes': case 'menfess': case 'confes': case 'confess': {
    if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
    if (!q) {
        return Yorireply(`*Format : Menfess Nomor|Pengirim|Pesan*\n\n📑 *Contoh : Menfess 628xxxxxx|Yori|Semangat Yah*`);
    }
    let parts = q.split('|');
    if (parts.length < 3) {
        return Yorireply(`⚠️ *Format salah. Format yang benar: Menfess Nomor|Pengirim|Pesan*`);
    }
    let nomor = parts[0].trim();
    let yori_nama = parts[1].trim();
    let yorichat = parts[2].trim();
    if (!nomor || !yori_nama || !yorichat) {
        return Yorireply(`⚠️ *Tolong Isi Semua Data Dengan Baik*`);
    }
    let nomor_valid = nomor.replace(/\D/g, '');
    if (nomor_valid.length < 10 || nomor_valid.length > 15) {
        return Yorireply(`⚠️ *Nomor telepon tidak valid. Pastikan menggunakan format internasional (misal: 628xxxxxx)*`);
    }

    let yori_txt = `☘️ *Halo Ada Menfess Nih*\n🎁 *Dari : ${yori_nama}* \n📃 *Pesan :*\n${yorichat}\n\n⚠️ *Menfess Ini Dikirim Oleh Bot Yori Chan*`;

    try {
        // Pastikan bahwa fungsi di mana blok ini berada sudah async
        await Yori.sendMessage(`${nomor_valid}@s.whatsapp.net`, { caption: yori_txt, image: { url: `https://cdn.meitang.xyz/file/BQACAgUAAxkDAAEBE7Bm8syHAavQojZ6V-BEoUAmBPDHhAAC5RQAAuPgmFd0yCwiDETvtTYE` } });
        Yorireply(`☘️ *Sukses Mengirim Menfess*`);
    } catch (error) {
        console.error('Error saat mengirim menfess:', error);
        Yorireply(`⚠️ *Gagal Mengirim Menfess: ${error.message}*`);
    }
}


                break

            case 'reminder': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                if (!args[0] || !args[1] || !args[2]) return Yorireply('☘️ *Format : Reminder Waktu Detik/Menit/Jam Pesan*\n\n📑 *Contoh : Reminder 30 Menit Jangan Lupa Sholat*')
                const time = parseInt(args[0]) * (args[1].match(/(m|minute)/i) ? 60 : args[1].match(/(h|hour)/i) ? 3600 : 1) * 1000
                const message = args.slice(2).join(' ')
                setTimeout(() => {
                    Yori.sendMessage(from, { text: `☘️ *Reminder Untuk @${sender.split("@")[0]}*\n\n📑 *Dengan Pesan :* ${message}`, contextInfo: { mentionedJid: [sender] } }, { quoted: m })
                }, time)
                Yorireply(`📑 *Berhasil Mengatur Reminder Untuk ${args[0]} ${args[1]} Ke Depan*`)
            }
                break
/*
            case 'google': {
                if (!isPrem) return Yorireply(mess.prem)
                if (!q) return Yorireply(`🍃 *Contoh : ${prefix + command} Youtube Yori*`)
                let google = require('google-it')
                google({ 'query': text }).then(res => {
                    let teks = `🍃 *Google Search From : ${text}*\n\n`
                    for (let g of res) {
                        teks += ` *⨠ Title* : ${g.title}\n`
                        teks += ` *⨠ Description* : ${g.snippet}\n`
                        teks += ` *⨠ Link* : ${g.link}\n\n────────────────────────\n\n`
                    }
                    Yorireply(teks)
                })
            }
            */            

case 'google':
    if (!text) return m.reply('masukan tema nya!');
    try {
        let goo = await (await fetch('https://endpoint.web.id/search/google?key=Yori&query=' + text)).json();
        if (goo.status && goo.result.length > 0) {
            let results = goo.result.map(item => {
                return `*Title:* ${item.title}\n*Description:* ${item.description}\n*URL:* ${item.url}\n`;
            }).join('\n');
            m.reply(results);
        } else {
            m.reply('Tidak ada hasil ditemukan.');
        }
    } catch (e) {
        m.reply('Terjadi kesalahan!');
    }            
                break

            case 'jarak': {
                if (!isRegistered) return deniedreply('Maaf Anda Belum Terdaftar, Dan Tidak Bisa Menggunakan Perintah Ini!\n\nSilahkan Register Terlebih Dahulu Dengan Cara Ketik .daftar')
                if (!text) return Yorireply(`🍃 *Contoh: ${prefix + command} Jakarta|Bandung*`)
                Yorireply(mess.wait)
                let [from, to] = text.split(/[^\w\s]/g)
                if (!(from && to)) return Yorireply(`🍃 *Contoh: ${prefix + command} Jakarta|Bandung*`)
                let data = await jarak(from, to)
                if (data.img) return Yori.sendMessage(m.chat, { image: data.img, caption: data.desc }, { quoted: m })
                else Yorireply(data.desc)
            }
                break

            case 'apksearch': {
                if (!text) return Yorireply(`⚠️ *Masukkan Nama Apk*`)
                var js = await fetch(`https://dikaardnt.com/api/search/apk?q=${q}`)
                Yorireply(mess.wait)
                var json = await js.json()
                var Yoricap = `
📑 *Nama :* ${json[0].title}
📦 *Developer :* ${json[0].developer}
🛒 *Rating :* ${json[0].rating}
📣 *Link Download :* 
${json[0].url}
`;
                await Yori.sendMessage(m.chat, { image: { url: json[0].thumbnail }, caption: Yoricap }, { quoted: m })
            }
                break

            case 'searchanime': case 'sanime': {
                if (!text) return Yorireply(`⚠️ *Masukkan Nama Anime, Contoh : Naruto Shippuden*`)
                var js = await fetch(`https://dikaardnt.com/api/search otakudesu?q=${q}`)
                Yorireply(mess.wait)
                var json = await js.json()
                var Yoricap = `
📑 *Judul :* ${json[0].title}
📦 *Genre :* ${json[0].genres}
📣 *Link :* ${json[0].url}
📶 *Status :* ${json[0].status}
📊 *Nilai :* ${json[0].rating}
📡 *Streaming :* ${json[0].url}
`;
                await Yori.sendMessage(m.chat, { image: { url: json[0].thumbnail }, caption: Yoricap }, { quoted: m })
            }
                break

            case 'storyanime': {
                if (isBan) return Yorireply(mess.ban)
                let sni = await (await fetch('https://aemt.me/download/storyanime')).json()
                let sni2 = sni.result
                Yori.sendMessage(m.chat, { video: { url: sni2.url }, caption: '*SUCCESS KAK* ✅' }, { quoted: m })
            }
                break

            case 'drakorsearch': {
                if (!text) return Yorireply(`⚠️ *Masukkan Nama Drakor*`)
                var js = await fetch(`https://dikaardnt.com/api/search/drakor?q=${q}`)
                Yorireply(mess.wait)
                var json = await js.json()
                var Yoricap = `
📑 *Judul :* ${json[0].title}
📦 *Genre :* ${json[0].genres}
📣 *Link :* ${json[0].url}
`;
                await Yori.sendMessage(m.chat, { image: { url: json[0].thumbnail }, caption: Yoricap }, { quoted: m })
            }
                break

            case 'otakudesu': {
                if (!text) return Yorireply(`⚠️ *Masukkan Nama Anime*`)
                var js = await fetch(`https://otakudesu-anime-api.vercel.app/api/v1/search/${q}`)
                Yorireply(mess.wait)
                var json = await js.json()
                var Yoricap = `
📑 *Judul :* ${json[0].title}
📦 *Genre :* ${json[0].genres}
📊 *Status :* ${json[0].status}
🏷️ *Nilai :* ${json[0].rating}
📣 *Link :* ${json[0].url}
`;
                await Yori.sendMessage(m.chat, { image: { url: json[0].image }, caption: Yoricap }, { quoted: m })
            }
                break

            case 'couple': {
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                let anu = await fetchJson('https://raw.githubusercontent.com/iamriz7/kopel_/main/kopel.json')
                let random = anu[Math.floor(Math.random() * anu.length)]
                Yori.sendMessage(from, { image: { url: random.male }, caption: `🎁 *Couple Male*` }, { quoted: m })
                Yori.sendMessage(from, { image: { url: random.female }, caption: `🎁 *Couple Female*` }, { quoted: m })
            }
                break

            case 'getname': {
                if (qtod === "true") {
                    namenye = await Yori.getName(m.quoted.sender)
                    Yorireply(namenye)
                } else if (qtod === "false") {
                    Yori.sendMessage(from, { text: "✉️ *Reply Orangnya*" }, { quoted: m })
                }
            }
                break

            case 'getpic': {
                if (!isPrem) return Yorireply(mess.prem)
                if (qtod === "true") {
                    try {
                        pporg = await Yori.profilePictureUrl(m.quoted.sender, 'image')
                    } catch {
                        pporg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
                    }
                    Yori.sendMessage(from, { image: { url: pporg }, caption: `🍃 *Selesai*` }, { quoted: m })
                } else if (qtod === "false") {
                    try {
                        pporgs = await Yori.profilePictureUrl(from, 'image')
                    } catch {
                        pporgs = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
                    }
                    Yori.sendMessage(from, { image: { url: pporgs }, caption: `🍃 *Selesai*` }, { quoted: m })
                }
            }
                break



            case 'setppbot': {
                if (!isCreator) return Yorireply(mess.owner)
                if (!quoted) return Yorireply(`Kirim/Balas Image Dengan Caption ${prefix + command}`)
                if (!/image/.test(mime)) return Yorireply(`Kirim/Balas Image Dengan Caption ${prefix + command}`)
                if (/webp/.test(mime)) return Yorireply(`Kirim/Balas Image Dengan Caption ${prefix + command}`)
                var medis = await Yori.downloadAndSaveMediaMessage(quoted, 'ppbot.jpeg')
                if (args[0] == `/full`) {
                    var { img } = await generateProfilePicture(medis)
                    await Yori.query({
                        tag: 'iq',
                        attrs: {
                            to: botNumber,
                            type: 'set',
                            xmlns: 'w:profile:picture'
                        },
                        content: [
                            {
                                tag: 'picture',
                                attrs: { type: 'image' },
                                content: img
                            }
                        ]
                    })
                    fs.unlinkSync(medis)
                    Yorireply(`Sukses`)
                } else {
                    var memeg = await Yori.updateProfilePicture(botNumber, { url: medis })
                    fs.unlinkSync(medis)
                    Yorireply(`Sukses`)
                }
            }
                break

            case 'setppgroup': case 'setppgrup': case 'setppgc': {
                if (!m.isGroup) return Yorireply(mess.group)
                if (!isAdmins) return Yorireply(mess.admin)
                if (!/image/.test(mime)) Yorireply`Kirim/Balas Image Dengan Caption ${prefix + command}`
                if (/webp/.test(mime)) Yorireply`Kirim/Balas Image Dengan Caption ${prefix + command}`
                let media = await Yori.downloadAndSaveMediaMessage(m)
                await Yori.updateProfilePicture(m.chat, { url: media }).catch((err) => fs.unlinkSync(media))
                Yorireply('done')
            }
                break

            case 'block': {
                if (!isCreator) return Yorireply(mess.owner)
                YoriLD()
                let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                await Yori.updateBlockStatus(users, 'block').then((res) => Yorireply(jsonformat(res))).catch((err) => Yorireply(jsonformat(err)))
            }
                break

            case 'unblock': {
                if (!isCreator) return Yorireply(mess.owner)
                YoriLD()
                let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                await Yori.updateBlockStatus(users, 'unblock').then((res) => Yorireply(jsonformat(res))).catch((err) => Yorireply(jsonformat(err)))
            }
                break

            case 'stalktiktok':
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                YoriLD()
                if (args.length == 0) return Yorireply(`Contoh: ${prefix + command} bulansutena`)
                axios.get(`https://api.lolhuman.xyz/api/stalktiktok/${args[0]}?apikey=haikalgans`).then(({ data }) => {
                    var caption = `Username : ${data.result.username}\n`
                    caption += `Nickname : ${data.result.nickname}\n`
                    caption += `Followers : ${data.result.followers}\n`
                    caption += `Followings : ${data.result.followings}\n`
                    caption += `Likes : ${data.result.likes}\n`
                    caption += `Video : ${data.result.video}\n`
                    caption += `Bio : ${data.result.bio}\n`
                    Yori.sendMessage(from, { image: { url: data.result.user_picture }, caption })
                })
                break

            case 'afk': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                let user = global.db.data.users[m.sender]
                user.afkTime = + new Date
                user.afkReason = text
                Yorireply(`🍃 *${pushname} Melakukan AFK*\n⚠️ *Dengan Alasan ${text ? ': ' + text : ''}*`)
            }
                break

            case 'listdb':
                if (!isCreator) return Yorireply(mess.owner)
                Yori_user = '📦 *Database User*'
                Yori_user += `\n📑 *Total : ${pengguna.length} User*`
                Yori.sendMessage(from, { text: Yori_user.trim() }, 'extendedTextMessage', { quoted: m, contextInfo: { "mentionedJid": pengguna } })
                break

            case 'getdb': {
if (!isCreator) return Yorireply(mess.owner)
Yorireply('📑 *Mengambil Seluruh Database')
let sesi = await fs.readFileSync('./src/database.json')
Yori.sendMessage(m.chat, { document: sesi, mimetype: 'application/json', fileName: 'database.json' }, { quoted: len })
}
break

case 'getuser': {
if (!isCreator) return Yorireply(mess.owner)
Yorireply('📑 *Mengambil User Database')
let sesi = await fs.readFileSync('./database/user.json')
Yori.sendMessage(m.chat, { document: sesi, mimetype: 'application/json', fileName: 'user.json' }, { quoted: len })
}
                break

            case 'suitpvp':
            case 'suit': {
                this.suit = this.suit ? this.suit : {}
                let poin = 10
                let poin_lose = 10
                let timeout = 60000
                if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.sender))) Yorireply(`Selesaikan suit mu sebelumnya`)
                if (m.mentionedJid[0] === m.sender) return Yorireply(`Tidak bisa bermain sendiri !`)
                if (!m.mentionedJid[0]) return Yorireply(`_Siapa yang ingin kamu tantang?_\nTag Orang tersebut..\n\nExample : ${prefix}suit @${owner[1]}`, m.chat, {
                    mentions: [owner[1] + '@s.whatsapp.net']
                })
                if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.mentionedJid[0]))) return Yorireply(`orang yang kamu tantang sedang bermain kartu dengan orang lain :(`)
                let id = 'suit_' + new Date() * 1
                let caption = `_*SUIT PvP*_

@${m.sender.split`@`[0]} challenged @${m.mentionedJid[0].split`@`[0]} to play suits

Please  @${m.mentionedJid[0].split`@`[0]} to type accept/reject`
                this.suit[id] = {
                    chat: await Yori.sendText(m.chat, caption, m, {
                        mentions: parseMention(caption)
                    }),
                    id: id,
                    p: m.sender,
                    p2: m.mentionedJid[0],
                    status: 'wait',
                    waktu: setTimeout(() => {
                        if (this.suit[id]) Yori.sendText(m.chat, `_Waktu suit telah berakhir_`, m)
                        delete this.suit[id]
                    }, 60000),
                    poin,
                    poin_lose,
                    timeout
                }
            }
                break

            case 'tebak': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                if (args[0] === "gambar") {
                    if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) Yorireply('⚠️ *Masih Ada Sesi Yang Belum Diselesaikan!*')
                    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json')
                    let result = anu[Math.floor(Math.random() * anu.length)]
                    Yori.sendImage(from, result.img, `🍃 *Silahkan Jawab Soal Di Atas Ini*\n\n📑 *Deskripsi :* ${result.deskripsi}\n\n🕒 *Waktu : 60s*`, m).then(() => {
                        tebakgambar[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
                    })
                    await sleep(60000)
                    if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) {
                        console.log("Jawaban: " + result.jawaban)
                        Yori.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/fce09c9f149e5a71aced1.jpg' }, caption: `🕒 *Waktu Habis*\n🎁 *Jawaban : ${tebakgambar[m.sender.split('@')[0]]}*\n\n📣 *Ingin Bermain Lagi? Ketik Tebak Gambar*` }, { quoted: m })
                        delete tebakgambar[m.sender.split('@')[0]]
                    }
                } else if (args[0] === 'kata') {
                    if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) Yorireply('⚠️ *Masih Ada Sesi Yang Belum Diselesaikan!*')
                    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkata.json')
                    let result = anu[Math.floor(Math.random() * anu.length)]
                    Yori.sendText(from, `🍃 *Silahkan Jawab Pertanyaan Berikut :*\n\n📦 *${result.soal}*\n\n🕒 *Waktu : 60s*`, m).then(() => {
                        tebakkata[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
                    })
                    await sleep(60000)
                    if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) {
                        console.log("Jawaban: " + result.jawaban)
                        Yori.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/fce09c9f149e5a71aced1.jpg' }, caption: `🕒 *Waktu Habis*\n🎁 *Jawaban : ${tebakkata[m.sender.split('@')[0]]}*\n\n📣 *Ingin Bermain Lagi? Ketik Tebak Kata*` }, { quoted: m })
                        delete tebakkata[m.sender.split('@')[0]]
                    }
                } else if (args[0] === 'kalimat') {
                    if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) Yorireply('⚠️ *Masih Ada Sesi Yang Belum Diselesaikan!*')
                    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkalimat.json')
                    let result = anu[Math.floor(Math.random() * anu.length)]
                    Yori.sendText(from, `🍃 *Silahkan Jawab Pertanyaan Berikut :*\n\n📦 *Pertanyaan :* ${result.soal}\n\n🕒 *Waktu : 60s*`, m).then(() => {
                        tebakkalimat[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
                    })
                    await sleep(60000)
                    if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) {
                        console.log("Jawaban: " + result.jawaban)
                        Yori.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/c7bf98b555e2c373267f9.jpg' }, caption: `🕒 *Waktu Habis*\n🎁 *Jawaban : ${tebakkalimat[m.sender.split('@')[0]]}*\n\n📣 *Ingin Bermain Lagi? Ketik Tebak Kalimat*` }, { quoted: m })
                        delete tebakkalimat[m.sender.split('@')[0]]
                    }
                } else if (args[0] === 'lirik') {
                    if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) Yorireply('⚠️ *Masih Ada Sesi Yang Belum Diselesaikan!*')
                    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaklirik.json')
                    let result = anu[Math.floor(Math.random() * anu.length)]
                    Yori.sendText(from, `🍃 *Ini Adalah Lirik Dari Lagu? :* \n\n📦 *${result.soal}?*\n\n🕒 *Waktu : 60s*`, m).then(() => {
                        tebaklirik[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
                    })
                    await sleep(60000)
                    if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) {
                        console.log("Jawaban: " + result.jawaban)
                        Yori.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/c7bf98b555e2c373267f9.jpg' }, caption: `🕒 *Waktu Habis*\n🎁 *Jawaban : ${tebaklirik[m.sender.split('@')[0]]}*\n\n📣 *Ingin Bermain Lagi? Ketik Tebak Lirik*` }, { quoted: m })
                        delete tebaklirik[m.sender.split('@')[0]]
                    }
                } else if (args[0] === 'lontong') {
                    if (caklontong.hasOwnProperty(m.sender.split('@')[0])) Yorireply('⚠️ *Masih Ada Sesi Yang Belum Diselesaikan!*')
                    let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/caklontong.json')
                    let result = anu[Math.floor(Math.random() * anu.length)]
                    Yori.sendText(from, `🍃 *Jawablah Pertanyaan Berikut :*\n📦 *${result.soal}*\n🕒 *Waktu : 60s*`, m).then(() => {
                        caklontong[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
                        caklontong_desk[m.sender.split('@')[0]] = result.deskripsi
                    })
                    await sleep(60000)
                    if (caklontong.hasOwnProperty(m.sender.split('@')[0])) {
                        console.log("Jawaban: " + result.jawaban)
                        Yori.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/7f29747c244f4be389e9e.jpg' }, caption: `🕒 *Waktu Habis*\n🎁 *Jawaban : ${caklontong[m.sender.split('@')[0]]}*\n\n📑 *Deskripsi : ${caklontong_desk[m.sender.split('@')[0]]}* \n\n📣 *Ingin Bermain Lagi? Ketik Tebak Lontong*` }, { quoted: m })
                        delete caklontong[m.sender.split('@')[0]]
                        delete caklontong_desk[m.sender.split('@')[0]]
                    }
                }
            }
                break

            case 'kuismath': case 'math': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                if (kuismath.hasOwnProperty(m.sender.split('@')[0])) Yorireply('⚠️ *Masih Ada Sesi Yang Belum Diselesaikan!*')
                let { genMath, modes } = require('./src/math')
                if (!text) Yorireply`Mode: ${Object.keys(modes).join(' | ')}\nContoh penggunaan: ${prefix}math medium`
                let result = await genMath(text.toLowerCase())
                Yori.sendText(from, `🍃 *Berapa Hasil Dari : ${result.soal.toLowerCase()}*?\n\n🕒 *Waktu : ${(result.waktu / 1000).toFixed(2)} detik*`, m).then(() => {
                    kuismath[m.sender.split('@')[0]] = result.jawaban
                })
                await sleep(result.waktu)
                if (kuismath.hasOwnProperty(m.sender.split('@')[0])) {
                    console.log("Jawaban: " + result.jawaban)
                    Yorireply("🕒 *Waktu Habis*\n🎁 *Jawaban :* " + kuismath[m.sender.split('@')[0]])
                    delete kuismath[m.sender.split('@')[0]]
                }
            }
                break

            case 'ttc': case 'ttt': case 'tictactoe': {
                if (isBan) return Yorireply('⚠️ *Kamu Di Ban Owner*')
                let TicTacToe = require("./lib/tictactoe")
                this.game = this.game ? this.game : {}
                if (Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))) throw '⚠️ *Kamu Masih Didalam Permainan*'
                let room = Object.values(this.game).find(room => room.state === 'WAITING' && (text ? room.name === text : true))
                if (room) {
                    Yorireply('🍃 *Lawan Bermain Ditemukan*')
                    room.o = from
                    room.game.playerO = m.sender
                    room.state = 'PLAYING'
                    let arr = room.game.render().map(v => {
                        return {
                            X: '❌',
                            O: '⭕',
                            1: '1️⃣',
                            2: '2️⃣',
                            3: '3️⃣',
                            4: '4️⃣',
                            5: '5️⃣',
                            6: '6️⃣',
                            7: '7️⃣',
                            8: '8️⃣',
                            9: '9️⃣',
                        }[v]
                    })
                    let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

Menunggu @${room.game.currentTurn.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
                    if (room.x !== room.o) await Yori.sendText(room.x, str, m, { mentions: parseMention(str) })
                    await Yori.sendText(room.o, str, m, { mentions: parseMention(str) })
                } else {
                    room = {
                        id: 'tictactoe-' + (+new Date),
                        x: from,
                        o: '',
                        game: new TicTacToe(m.sender, 'o'),
                        state: 'WAITING'
                    }
                    if (text) room.name = text
                    Yorireply('🍃 *Menunggu Lawan Bermain*' + (text ? ` mengetik command dibawah ini ${prefix}${command} ${text}` : ''))
                    this.game[room.id] = room
                }
            }
                break

            case 'del':
            case 'delete': {
                Yori.sendMessage(m.chat,
                    {
                        delete: {
                            remoteJid: m.chat,
                            fromMe: true,
                            id: m.quoted.id,
                            participant: m.quoted.sender
                        }
                    })
            }
                break

            case "buatpanel": {
                const owned = `6285389454230@s.whatsapp.net`
                const text12 = xeonytimewisher + ` *@${sender.split("@")[0]}*

 
BY ${global.botname}

CARA ADD USER PANEL :
ram user,nomer

contoh : 1gb jonggun,number 

Powered By *@${owned.split("@")[0]}*
▬▭▬▭▬▭▬▭▬▭▬▭▬`
                Yori.sendMessage(from, { text: text12, contextInfo: { mentionedJid: [sender, owned], forwardingScore: 9999, isForwarded: true } }, { quoted: m })
            }
                break

            case "listusr": {
                if (!isCreator) return Yorireply(mess.owner)
                let page = args[0] ? args[0] : '1';
                let f = await fetch(domain + "/api/application/users?page=" + page, {
                    "method": "GET",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                });
                let res = await f.json();
                let users = res.data;
                let messageText = "Berikut list user:\n\n";

                for (let user of users) {
                    let u = user.attributes;
                    messageText += `ID: ${u.id} - Status: ${u.attributes?.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
                    messageText += `${u.username}\n`;
                    messageText += `${u.first_name} ${u.last_name}\n\n`;
                }

                messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
                messageText += `Total Users: ${res.meta.pagination.count}`;

                await Yori.sendMessage(m.chat, { text: messageText }, { quoted: m });

                if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
                    reply(`Gunakan perintah ${prefix}listusr ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
                }
            }
                break;
            case "delsrv": {
                if (!isCreator) return Yorireply(`Khusus ${global.botname} Aja`)

                let srv = args[0]
                if (!srv) return Yorireply('ID nya mana?')
                let f = await fetch(domain + "/api/application/servers/" + srv, {
                    "method": "DELETE",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey,
                    }
                })
                let res = f.ok ? {
                    errors: null
                } : await f.json()
                if (res.errors) return Yorireply('*SERVER NOT FOUND*')
                reply('*SUCCESSFULLY DELETE THE SERVER*')
            }
                break
            case "delusr": {
                if (!isCreator) return Yorireply(`Khusus ${global.botname} Aja`)
                let usr = args[0]
                if (!usr) return Yorireply('ID nya mana?')
                let f = await fetch(domain + "/api/application/users/" + usr, {
                    "method": "DELETE",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                })
                let res = f.ok ? {
                    errors: null
                } : await f.json()
                if (res.errors) return reply('*USER NOT FOUND*')
                reply('*SUCCESSFULLY DELETE THE USER*')
            }
                break
            case 'addusr': {
                if (!isPrem) return Yorireply(`Maaf Command Tersebut Khusus Developer Bot WhatsApp`)
                let s = text.split(',')
                let email = s[0];
                let username = s[0]
                let nomor = s[1]
                if (s.length < 2) return Yorireply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
                if (!username) return Yorireply(`Ex : ${prefix + command} Username,@tag/nomor\n\nContoh :\n${prefix + command} example,@user`)
                if (!nomor) return Yorireply(`Ex : ${prefix + command} Username,@tag/nomor\n\nContoh :\n${prefix + command} example,@user`)
                let u = m.quoted ? m.quoted.sender : s[1] ? s[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
                if (!u) return Yorireply(`*Format salah!*

Penggunaan:
${prefix + command} email,username,name,number/tag`);
                let d = (await Yori.onWhatsApp(u.split`@`[0]))[0] || {}
                let password = username + "245"
                let f = await fetch(domain + "/api/application/users", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    },
                    "body": JSON.stringify({
                        "email": username + "@gmail.com",
                        "username": username,
                        "first_name": username,
                        "last_name": "Memb",
                        "language": "en",
                        "password": password.toString()
                    })
                })
                let data = await f.json();
                if (data.errors) return Yorireply(JSON.stringify(data.errors[0], null, 2));
                let user = data.attributes
                let p = `
*SUCCESSFULLY ADD USER*

╭─❏ *『 USER INFO 』*
┣❐ ➤ *ID* : ${user.id}
┣❏ ➤ *USERNAME* : ${user.username}
┣❏ ➤ *EMAIL* : ${user.email} + "@gmail.com"
┣❏ ➤ *NAME* : ${user.first_name} ${user.last_name}
┣❏ ➤ *DIBUAT* : ${new Date().toLocaleTimeString()}
┗⬣ *PASSWORD BERHASIL DI KIRIM KE @${u.split`@`[0]}*
*_Made in Yori Chan MultiDevice_*`

                let sections = [{
                    title: 'Paket Server Panel',
                    highlight_label: 'Recomended',
                    rows: [{
                        title: 'Unli',
                        description: `Unlimited Ram/Cpu`,
                        id: `.addsrv ${user.first_name},${new Date().toLocaleTimeString()},${user.id},16,1,0/0,0`
                    },
                    {
                        title: '1Gb',
                        description: "RAM 1 GB | CPU 30 | DISK 1 GB",
                        id: `.addsrv,${user.first_name},${new Date().toLocaleTimeString()},${user.id},16,1,1000/100,30`
                    },
                    {
                        title: '2Gb',
                        description: "RAM 2 GB | CPU 50| DISK 2 GB",
                        id: `.addsrv ${user.first_name},${new Date().toLocaleTimeString()},${user.id},16,1,2200/2200,50`
                    },
                    {
                        title: '3Gb',
                        description: "RAM 3 GB | CPU 70 | DISK 3 GB ",
                        id: `.addsrv ${user.first_name},${new Date().toLocaleTimeString()},${user.id},16,1,3200/3200,70`
                    },
                    {
                        title: '4Gb',
                        description: "RAM 4 GB | CPU 90| DISK 4 GB",
                        id: `.addsrv ${user.first_name},${new Date().toLocaleTimeString()},${user.id},16,1,4200/4200,90`
                    },
                    {
                        title: '5Gb',
                        description: "RAM 5 GB | CPU 100 | DISK 5 GB",
                        id: `.addsrv ${user.first_name},${new Date().toLocaleTimeString()},${user.id},16,1,5200/5200,100`
                    },
                    {
                        title: '6Gb',
                        description: "RAM 6 GB | CPU 120 | DISK 6 GB",
                        id: `.addsrv ${user.first_name},${new Date().toLocaleTimeString()},${user.id},16,1,6200/6200,120`
                    },
                    {
                        title: '7Gb',
                        description: "RAM 7 GB | CPU 140 | DISK 7 GB",
                        id: `.addsrv ${user.first_name},${new Date().toLocaleTimeString()},${user.id},16,1,7200/7200,140`
                    },
                    {
                        title: '8Gb',
                        description: "RAM 8 GB | CPU 160 | DISK 7 GB",
                        id: `.addsrv ${user.first_name},${new Date().toLocaleTimeString()},${user.id},16,1,8200/8200,160`
                    },
                    {
                        title: '9Gb',
                        description: "RAM 9 GB | CPU 180 | DISK 7 GB",
                        id: `.addsrv ${user.first_name},${new Date().toLocaleTimeString()},${user.id},16,1,9200/9200,180`
                    },
                    {
                        title: '10Gb',
                        description: "RAM 10 GB | CPU 200 | DISK 8 GB",
                        id: `.addsrv ${user.first_name},${new Date().toLocaleTimeString()},${user.id},16,1,11000/11000,200`
                    }]
                }]

                let listMessage = {
                    title: 'List Panel',
                    sections
                };

                let msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            "messageContextInfo": {
                                "deviceListMetadata": {},
                                "deviceListMetadataVersion": 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                contextInfo: {
                                    mentionedJid: [m.sender],
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: '120363204138641225@newsletter',
                                        newsletterName: 'Powered By YoriBaby',
                                        serverMessageId: -1
                                    },
                                    businessMessageForwardInfo: { businessOwnerJid: Yori.decodeJid(Yori.user.id) },
                                },
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: ''
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: `© Yori Baby`
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    title: `Pilih Size Server Anda`,
                                    subtitle: "YORI CHAN",
                                    hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/0dbccb0467a3670945832.jpg" } }, { upload: Yori.waUploadToServer }))
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            "name": "single_select",
                                            "buttonParamsJson": JSON.stringify(listMessage)
                                        },
                                    ]
                                })
                            })
                        }
                    }
                }, {})

                await Yori.relayMessage(msg.key.remoteJid, msg.message, {
                    messageId: msg.key.id
                })
                Yori.sendMessage(u, {
                    text: `*BERIKUT DETAIL AKUN PANEL ANDA*\n
╭─❏ *『 USER INFO 』*
┣❏ ➤ *EMAIL* : ${email}
┣❏ ➤ *USERNAME* : ${username}
┣❏ ➤ *PASSWORD* : ${password.toString()}
┣❏ ➤ *LOGIN* : ${domain}
┗⬣`,
                })
            }
                break

            case "listsrv": {
                if (!isCreator) return Yorireply(`Maaf, Anda tidak dapat melihat daftar server.`);
                let page = args[0] ? args[0] : '1';
                let f = await fetch(domain + "/api/application/servers?page=" + page, {
                    "method": "GET",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                });
                let res = await f.json();
                let servers = res.data;
                let sections = [];
                let messageText = "Berikut adalah daftar server:\n\n";

                for (let server of servers) {
                    let s = server.attributes;

                    let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
                        "method": "GET",
                        "headers": {
                            "Accept": "application/json",
                            "Content-Type": "application/json",
                            "Authorization": "Bearer " + capikey
                        }
                    });

                    let data = await f3.json();
                    let status = data.attributes ? data.attributes.current_state : s.status;

                    messageText += `ID Server: ${s.id}\n`;
                    messageText += `Nama Server: ${s.name}\n`;
                    messageText += `Status: ${status}\n\n`;
                }

                messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
                messageText += `Total Server: ${res.meta.pagination.count}`;

                await Yori.sendMessage(m.chat, { text: messageText }, { quoted: m });

                if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
                    reply(`Gunakan perintah ${prefix}listsrv ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
                }
            }
                break;

            case "tutorial": {
                const owned = `923107058820@s.whatsapp.net`
                const version = require("baileys/package.json").version
                const text12 = xeonytimewisher + ` *@${sender.split("@")[0]}*

▭▬▭( *TUTOR RUN* )▭▬▭

*TUTOR RUN BOT*
( https://youtu.be/rqqxkI4P8YY )

 Powered By *@${owned.split("@")[0]}*
▬▭▬▭▬▭▬▭▬▭▬▭▬`
                Yori.sendMessage(from, { text: text12, contextInfo: { mentionedJid: [sender, owned], forwardingScore: 9999, isForwarded: true } }, { quoted: m })
            }
                break

            case "ramlist": {
                const owned = `923107058820@s.whatsapp.net`
                const version = require("baileys/package.json").version
                const text12 = xeonytimewisher + ` *@${sender.split("@")[0]}*

▭▬▭▬▭( *SERVER V1* )▭▬▭▬▭

.1gb [username,nomor]
.2gb [username,nomor]
.3gb [username,nomor]
.4gb [username,nomor]
.5gb [username,nomor]
.6gb [username,nomor]
.7gb [username,nomor]
.8gb [username,nomor]
.unli [username,nomor]

Contoh:
.ram username,nomor
.1gb jonggun,number
▬▭▬▭▬▭▬▭▬▭▬▭▬

▭▬▭▬▭( *SERVER V2* )▭▬▭▬▭

.srv21gb [username,nomor]
.srv22gb [username,nomor]
.srv23gb [username,nomor]
.srv24gb [username,nomor]
.srv25gb [username,nomor]
.srv26gb [username,nomor]
.srv27gb [username,nomor]
.srv2unli [username,nomor]

Contoh:
.srv2(RAM PANEL) username,nomor
.srv21gb jonggun,number
▬▭▬▭▬▭▬▭▬▭▬▭▬`
                Yori.sendMessage(from, { text: text12, contextInfo: { mentionedJid: [sender, owned], forwardingScore: 9999, isForwarded: true } }, { quoted: m })
            } freya = fs.readFileSync('./freya/ramlist.mp3')
                Yori.sendMessage(m.chat, { audio: freya, mimetype: 'audio/mpeg', ptt: true }, { quoted: m })
                break
            case 'premlist': {
                if (!isCreator) return Yorireply(mess.owner)
                let listprem = `*LIST SELER ${global.botname}*\n\nTotal Seller : ${owner.length}\n`
                var no = 1
                for (let x of owner) {
                    listprem += `\nUser: ${no++}\nID: ${x}\n\n`
                }
                listprem += `Untuk Menghapus Akses Prem Ketik ${prefix}delprem 628xxx/@tag`
                Yori.sendMessage(m.chat, { text: listprem }, { quoted: Yori.chat })
            }
                break
            case "addsrv": {
                if (!isCreator) return Yorireply(`Ngapain ? Fitur Ini Khusus Tuan Saya😜`)
                let s = text.split(',');
                if (s.length < 7) return Yorireply(`*Format salah!*

Penggunaan:
${prefix + command} name,tanggal,userId,eggId,locationId,memory/disk,cpu`)
                let name = s[0];
                let desc = s[1] || ''
                let usr_id = s[2];
                let egg = s[3];
                let loc = s[4];
                let memo_disk = s[5].split`/`;
                let cpu = s[6];
                let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
                    "method": "GET",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                })
                let data = await f1.json();
                // = data.attributes.pStartup

                let f = await fetch(domain + "/api/application/servers", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey,
                    },
                    "body": JSON.stringify({
                        "name": name,
                        "description": desc,
                        "user": usr_id,
                        "egg": parseInt(egg),
                        "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
                        "startup": "if [[ -d .git ]] && [[ \${AUTO_UPDATE} == \"1\" ]]; then git pull; fi; if [[ ! -z \${NODE_PACKAGES} ]]; then /usr/local/bin/npm install \${NODE_PACKAGES}; fi; if [[ ! -z \${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall \${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/\${CMD_RUN}",
                        "environment": {
                            "INST": "npm",
                            "USER_UPLOAD": "0",
                            "AUTO_UPDATE": "0",
                            "CMD_RUN": "npm start",
                        },
                        "limits": {
                            "memory": memo_disk[0],
                            "swap": 0,
                            "disk": memo_disk[1],
                            "io": 500,
                            "cpu": cpu
                        },
                        "feature_limits": {
                            "databases": 5,
                            "backups": 5,
                            "allocations": 5
                        },
                        deploy: {
                            locations: [parseInt(loc)],
                            dedicated_ip: false,
                            port_range: [],
                        },
                    })
                })
                let res = await f.json()
                if (res.errors) return Yorireply(JSON.stringify(res.errors[0], null, 2))
                let server = res.attributes
                Yorireply(`*SUCCESSFULLY ADD SERVER*

TYPE: ${res.object}

ID: ${server.id}
UUID: ${server.uuid}
NAME: ${server.name}
DESCRIPTION: ${server.description}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%
CREATED AT: ${server.created_at}`)
            }
                break
            case 'suspend': {
                if (!isCreator) return Yorireply(`Khusus ${global.botname} Ajah`)
                let srv = args[0]
                if (!srv) return reply('ID nya mana?')
                let f = await fetch(domain + "/api/application/servers/" + srv + "/suspend", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                })
                let res = f.ok ? {
                    errors: null
                } : await f.json()
                if (res.errors) return reply('*SERVER NOT FOUND*')
                reply('*BERHASIL SUSPEND..*')
            }
                break
            case 'unsuspend': {
                if (!isCreator) return reply(`Khusus ${global.botname} Ajah`)
                let srv = args[0]
                if (!srv) return reply('ID nya mana?')
                let f = await fetch(domain + "/api/application/servers/" + srv + "/unsuspend", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                })
                let res = f.ok ? {
                    errors: null
                } : await f.json()
                if (res.errors) return reply('*SERVER NOT FOUND*')
                reply('*BERHASIL BUKA SUSPEND..*')
            }
                break
            case "createadmin": {
                if (!isCreator) return Yorireply(mess.owner)

                let s = q.split(',')
                let email = s[0];
                let username = s[0]
                let nomor = s[1]
                if (s.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
                if (!username) return reply(`Ex : ${prefix + command} Username,@tag/nomor\n\nContoh :\n${prefix + command} example,@user`)
                if (!nomor) return reply(`Ex : ${prefix + command} Username,@tag/nomor\n\nContoh :\n${prefix + command} example,@user`)
                let password = username + "46093"
                let nomornya = nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                let f = await fetch(domain + "/api/application/users", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    },
                    "body": JSON.stringify({
                        "email": username + "@gmail.com",
                        "username": username,
                        "first_name": username,
                        "last_name": "Memb",
                        "language": "en",
                        "root_admin": true,
                        "password": password.toString()
                    })

                })

                let data = await f.json();

                if (data.errors) return Yorireply(JSON.stringify(data.errors[0], null, 2));

                let user = data.attributes

                let tks = `
TYPE: user

📡ID: ${user.id}
🌷UUID: ${user.uuid}
👤USERNAME: ${user.username}
📬EMAIL: ${user.email}
🦖NAME: ${user.first_name} ${user.last_name}
🔥LANGUAGE: ${user.language}
📊ADMIN: ${user.root_admin}
☢️CREATED AT: ${user.created_at}

🖥️LOGIN: ${domain}
`
                const listMessage = {

                    text: tks,

                }



                await Yori.sendMessage(m.chat, listMessage)

                await Yori.sendMessage(nomornya, {

                    text: `*BERIKUT DETAIL AKUN ADMIN  PANEL ANDA*\n
USERNAME :  ${username}
PASSWORD: ${password}
LOGIN: ${domain}


*NOTE : OWNER HANYA MENGIRIM 1X DATA AKUN ANDA MOHON DI SIMPAN BAIK BAIK KALAU DATA AKUN ANDA HILANG OWNER TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*


`,

                })

            }
                break
            case "createadmin2": {
                if (!isCreator) return Yorireply(mess.owner)

                let s = q.split(',')
                let email = s[0];
                let username = s[0]
                let nomor = s[1]
                if (s.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
                if (!username) return reply(`Ex : ${prefix + command} Username,@tag/nomor\n\nContoh :\n${prefix + command} example,@user`)
                if (!nomor) return reply(`Ex : ${prefix + command} Username,@tag/nomor\n\nContoh :\n${prefix + command} example,@user`)
                let password = username + "46093"
                let nomornya = nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                let f = await fetch(domain2 + "/api/application/users", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey2
                    },
                    "body": JSON.stringify({
                        "email": username + "@gmail.com",
                        "username": username,
                        "first_name": username,
                        "last_name": "Admin",
                        "language": "en",
                        "root_admin": true,
                        "password": password.toString()
                    })

                })

                let data = await f.json();

                if (data.errors) return Yorireply(JSON.stringify(data.errors[0], null, 2));

                let user = data.attributes

                let tks = `
TYPE: Admin

📡ID: ${user.id}
🌷UUID: ${user.uuid}
👤USERNAME: ${user.username}
📬EMAIL: ${user.email}
🦖NAME: ${user.first_name} ${user.last_name}
🔥LANGUAGE: ${user.language}
📊ADMIN: ${user.root_admin}
☢️CREATED AT: ${user.created_at}

`
                const listMessage = {

                    text: tks,

                }



                await Yori.sendMessage(m.chat, listMessage)

                await Yori.sendMessage(nomornya, {

                    text: `*BERIKUT DETAIL AKUN ADMIN  PANEL ANDA*\n
USERNAME :  ${username}
PASSWORD: ${password}
LOGIN: ${domain2}


*NOTE : OWNER HANYA MENGIRIM 1X DATA AKUN ANDA MOHON DI SIMPAN BAIK BAIK KALAU DATA AKUN ANDA HILANG OWNER TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*


`,

                })

            }
                break
            case "listadmin": {
                if (!isCreator) return Yorireply(`Maaf, Anda tidak dapat melihat daftar pengguna.`);
                let page = args[0] ? args[0] : '1';
                let f = await fetch(domain + "/api/application/users?page=" + page, {
                    "method": "GET",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                });
                let res = await f.json();
                let users = res.data;
                let messageText = "Berikut list admin:\n\n";

                for (let user of users) {
                    let u = user.attributes;
                    if (u.root_admin) {
                        messageText += `ID: ${u.id} - Status: ${u.attributes?.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
                        messageText += `${u.username}\n`;
                        messageText += `${u.first_name} ${u.last_name}\n\n`;
                    }
                }

                messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
                messageText += `Total Admin: ${res.meta.pagination.count}`;

                await Yori.sendMessage(m.chat, { text: messageText }, { quoted: m });

                if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
                    Yorireply(`Gunakan perintah ${prefix}listusr ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
                }
            }
                break;
            case "1gb": {
                if (!isPrem) return Yorireply(mess.prem)
                let t = text.split(',');
                if (t.length < 2) return Yorireply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
                let username = t[0];
                let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
                let name = username + "1GB"
                let egg = global.eggsnya
                let loc = global.location3
                let memo = "1024"
                let cpu = "15"
                let disk = "1024"
                let email = username + "1398@gmail.com"
                akunlo = "https://telegra.ph/file/c7bf98b555e2c373267f9.jpg"
                if (!u) return
                let d = (await Yori.onWhatsApp(u.split`@`[0]))[0] || {}
                let password = username + "001"
                let f = await fetch(domain + "/api/application/users", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    },
                    "body": JSON.stringify({
                        "email": email,
                        "username": username,
                        "first_name": username,
                        "last_name": username,
                        "language": "en",
                        "password": password
                    })
                })
                let data = await f.json();
                if (data.errors) return Yorireply(JSON.stringify(data.errors[0], null, 2));
                let user = data.attributes
                let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
                    "method": "GET",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                })
                Yorireply(`DONE BY ${global.botname} Official⚡

 *DONE CRATE USER + SERVER ID :* ${user.id}`)
                ctf = `Hai @${u.split`@`[0]}

 *👤USERNAME* : ${user.username}
 *🔐PASSWORD* : ${password}
 *🌐LOGIN* : ${domain}
 

NOTE :
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
`
                Yori.sendMessage(u, { image: { url: akunlo }, caption: ctf }, { quoted: Yori.chat })
                let data2 = await f2.json();
                // = data2.attributes.pStartup

                let f3 = await fetch(domain + "/api/application/servers", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey,
                    },
                    "body": JSON.stringify({
                        "name": name,
                        "description": " ",
                        "user": user.id,
                        "egg": parseInt(egg),
                        "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
                        "startup": "if [[ -d .git ]] && [[ \${AUTO_UPDATE} == \"1\" ]]; then git pull; fi; if [[ ! -z \${NODE_PACKAGES} ]]; then /usr/local/bin/npm install \${NODE_PACKAGES}; fi; if [[ ! -z \${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall \${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/\${CMD_RUN}",
                        "environment": {
                            "INST": "npm",
                            "USER_UPLOAD": "0",
                            "AUTO_UPDATE": "0",
                            "CMD_RUN": "npm start",
                        },
                        "limits": {
                            "memory": memo,
                            "swap": 0,
                            "disk": disk,
                            "io": 500,
                            "cpu": cpu
                        },
                        "feature_limits": {
                            "databases": 5,
                            "backups": 5,
                            "allocations": 1
                        },
                        deploy: {
                            locations: [parseInt(loc)],
                            dedicated_ip: false,
                            port_range: [],
                        },
                    })
                })
                let res = await f3.json()
                if (res.errors) return Yorireply(JSON.stringify(res.errors[0], null, 2))
                let server = res.attributes
                let p = await Yorireply(`
𝐃𝐎𝐍𝐄 𝐒𝐈𝐋𝐀𝐇𝐊𝐀𝐍 𝐂𝐄𝐊 𝐃𝐀𝐓𝐀 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐀𝐍𝐃𝐀 𝐒𝐔𝐃𝐀𝐇 𝐓𝐄𝐑𝐊𝐈𝐑𝐈𝐌 𝐊𝐄 𝐍𝐎𝐌𝐎𝐑 𝐓𝐄𝐑𝐒𝐄𝐁𝐔𝐓 ☑️
© Cs ${global.botname} Official
`)

            }

                break
            case "2gb": {
                if (!isPrem) return Yorireply(mess.prem)

                let t = text.split(',');
                if (t.length < 2) return Yorireply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
                let username = t[0];
                let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
                let name = username + "2GB"
                let egg = global.eggsnya
                let loc = global.location3
                let memo = "2048"
                let cpu = "20"
                let disk = "2050"
                let email = username + "1398@gmail.com"
                akunlo = "https://telegra.ph/file/c7bf98b555e2c373267f9.jpg"
                if (!u) return
                let d = (await Yori.onWhatsApp(u.split`@`[0]))[0] || {}
                let password = username + "001"
                let f = await fetch(domain + "/api/application/users", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    },
                    "body": JSON.stringify({
                        "email": email,
                        "username": username,
                        "first_name": username,
                        "last_name": username,
                        "language": "en",
                        "password": password
                    })
                })
                let data = await f.json();
                if (data.errors) return Yorireply(JSON.stringify(data.errors[0], null, 2));
                let user = data.attributes
                let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
                    "method": "GET",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                })
                Yorireply(`SUCCES CREATE USER ID: ${user.id}`)
                ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}

NOTE:
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
=====================================
`
                Yori.sendMessage(u, { image: { url: akunlo }, caption: ctf }, { quoted: Yori.chat })
                let data2 = await f2.json();
                // = data2.attributes.pStartup

                let f3 = await fetch(domain + "/api/application/servers", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey,
                    },
                    "body": JSON.stringify({
                        "name": name,
                        "description": " ",
                        "user": user.id,
                        "egg": parseInt(egg),
                        "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
                        "startup": "if [[ -d .git ]] && [[ \${AUTO_UPDATE} == \"1\" ]]; then git pull; fi; if [[ ! -z \${NODE_PACKAGES} ]]; then /usr/local/bin/npm install \${NODE_PACKAGES}; fi; if [[ ! -z \${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall \${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/\${CMD_RUN}",
                        "environment": {
                            "INST": "npm",
                            "USER_UPLOAD": "0",
                            "AUTO_UPDATE": "0",
                            "CMD_RUN": "npm start",
                        },
                        "limits": {
                            "memory": memo,
                            "swap": 0,
                            "disk": disk,
                            "io": 500,
                            "cpu": cpu
                        },
                        "feature_limits": {
                            "databases": 5,
                            "backups": 5,
                            "allocations": 1
                        },
                        deploy: {
                            locations: [parseInt(loc)],
                            dedicated_ip: false,
                            port_range: [],
                        },
                    })
                })
                let res = await f3.json()
                if (res.errors) return Yorireply(JSON.stringify(res.errors[0], null, 2))
                let server = res.attributes
                let p = await Yorireply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

            }

                break
            case "3gb": {
                if (!isPrem) return Yorireply(mess.prem)

                let t = text.split(',');
                if (t.length < 2) return Yorireply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
                let username = t[0];
                let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
                let name = username + "3GB"
                let egg = global.eggsnya
                let loc = global.location3
                let memo = "3072"
                let cpu = "40"
                let disk = "3073"
                let email = username + "1398@gmail.com"
                akunlo = "https://telegra.ph/file/c7bf98b555e2c373267f9.jpg"
                if (!u) return
                let d = (await Yori.onWhatsApp(u.split`@`[0]))[0] || {}
                let password = username + "001"
                let f = await fetch(domain + "/api/application/users", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    },
                    "body": JSON.stringify({
                        "email": email,
                        "username": username,
                        "first_name": username,
                        "last_name": username,
                        "language": "en",
                        "password": password
                    })
                })
                let data = await f.json();
                if (data.errors) return Yorireply(JSON.stringify(data.errors[0], null, 2));
                let user = data.attributes
                let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
                    "method": "GET",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                })
                Yorireply(`SUCCES CREATE USER ID: ${user.id}`)
                ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}

NOTE :
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
=====================================
`
                Yori.sendMessage(u, { image: { url: akunlo }, caption: ctf }, { quoted: Yori.chat })
                let data2 = await f2.json();
                // = data2.attributes.pStartup

                let f3 = await fetch(domain + "/api/application/servers", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey,
                    },
                    "body": JSON.stringify({
                        "name": name,
                        "description": " ",
                        "user": user.id,
                        "egg": parseInt(egg),
                        "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
                        "startup": "if [[ -d .git ]] && [[ \${AUTO_UPDATE} == \"1\" ]]; then git pull; fi; if [[ ! -z \${NODE_PACKAGES} ]]; then /usr/local/bin/npm install \${NODE_PACKAGES}; fi; if [[ ! -z \${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall \${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/\${CMD_RUN}",
                        "environment": {
                            "INST": "npm",
                            "USER_UPLOAD": "0",
                            "AUTO_UPDATE": "0",
                            "CMD_RUN": "npm start",
                        },
                        "limits": {
                            "memory": memo,
                            "swap": 0,
                            "disk": disk,
                            "io": 500,
                            "cpu": cpu
                        },
                        "feature_limits": {
                            "databases": 5,
                            "backups": 5,
                            "allocations": 1
                        },
                        deploy: {
                            locations: [parseInt(loc)],
                            dedicated_ip: false,
                            port_range: [],
                        },
                    })
                })
                let res = await f3.json()
                if (res.errors) return Yorireply(JSON.stringify(res.errors[0], null, 2))
                let server = res.attributes
                let p = await Yorireply(`
*SUCCESSFULLY ADD USER + SERVER*

TYPE: user

ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

            }
                break
            case "4gb": {
                if (!isPrem) return Yorireply(mess.prem)

                let t = text.split(',');
                if (t.length < 2) return Yorireply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
                let username = t[0];
                let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
                let name = username + "4GB"
                let egg = global.eggsnya
                let loc = global.location3
                let memo = "4048"
                let cpu = "50"
                let disk = "4040"
                let email = username + "1398@gmail.com"
                akunlo = "https://telegra.ph/file/c7bf98b555e2c373267f9.jpg"
                if (!u) return
                let d = (await Yori.onWhatsApp(u.split`@`[0]))[0] || {}
                let password = username + "001"
                let f = await fetch(domain + "/api/application/users", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    },
                    "body": JSON.stringify({
                        "email": email,
                        "username": username,
                        "first_name": username,
                        "last_name": username,
                        "language": "en",
                        "password": password
                    })
                })
                let data = await f.json();
                if (data.errors) return Yorireply(JSON.stringify(data.errors[0], null, 2));
                let user = data.attributes
                let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
                    "method": "GET",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                })
                Yorireply(`SUCCES CREATE USER ID: ${user.id}`)
                ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}

NOTE:
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
=====================================
`
                Yori.sendMessage(u, { image: { url: akunlo }, caption: ctf }, { quoted: Yori.chat })
                let data2 = await f2.json();
                // = data2.attributes.pStartup

                let f3 = await fetch(domain + "/api/application/servers", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey,
                    },
                    "body": JSON.stringify({
                        "name": name,
                        "description": " ",
                        "user": user.id,
                        "egg": parseInt(egg),
                        "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
                        "startup": "if [[ -d .git ]] && [[ \${AUTO_UPDATE} == \"1\" ]]; then git pull; fi; if [[ ! -z \${NODE_PACKAGES} ]]; then /usr/local/bin/npm install \${NODE_PACKAGES}; fi; if [[ ! -z \${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall \${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/\${CMD_RUN}",
                        "environment": {
                            "INST": "npm",
                            "USER_UPLOAD": "0",
                            "AUTO_UPDATE": "0",
                            "CMD_RUN": "npm start",
                        },
                        "limits": {
                            "memory": memo,
                            "swap": 0,
                            "disk": disk,
                            "io": 500,
                            "cpu": cpu
                        },
                        "feature_limits": {
                            "databases": 5,
                            "backups": 5,
                            "allocations": 1
                        },
                        deploy: {
                            locations: [parseInt(loc)],
                            dedicated_ip: false,
                            port_range: [],
                        },
                    })
                })
                let res = await f3.json()
                if (res.errors) return Yorireply(JSON.stringify(res.errors[0], null, 2))
                let server = res.attributes
                let p = await Yorireply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

            }

                break
            case "unli": {
                if (!isPrem) return Yorireply(mess.prem)
                let t = text.split(',');
                if (t.length < 2) return Yorireply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
                let username = t[0];
                let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
                let name = username + "Unlimited"
                let egg = global.eggsnya
                let loc = global.location3
                let memo = "0"
                let cpu = "0"
                let disk = "0"
                let email = username + "1398@gmail.com"
                akunlo = "https://telegra.ph/file/c7bf98b555e2c373267f9.jpg"
                if (!u) return
                let d = (await Yori.onWhatsApp(u.split`@`[0]))[0] || {}
                let password = username + "001"
                let f = await fetch(domain + "/api/application/users", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    },
                    "body": JSON.stringify({
                        "email": email,
                        "username": username,
                        "first_name": username,
                        "last_name": username,
                        "language": "en",
                        "password": password
                    })
                })
                let data = await f.json();
                if (data.errors) return Yorireply(JSON.stringify(data.errors[0], null, 2));
                let user = data.attributes
                let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
                    "method": "GET",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                })
                Yorireply(`SUCCES CREATE USER ID: ${user.id}`)
                ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}


NOTE:
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
=====================================
`
                Yori.sendMessage(u, { image: { url: akunlo }, caption: ctf }, { quoted: Yori.chat })
                let data2 = await f2.json();
                // = data2.attributes.pStartup

                let f3 = await fetch(domain + "/api/application/servers", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey,
                    },
                    "body": JSON.stringify({
                        "name": name,
                        "description": " ",
                        "user": user.id,
                        "egg": parseInt(egg),
                        "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
                        "startup": "if [[ -d .git ]] && [[ \${AUTO_UPDATE} == \"1\" ]]; then git pull; fi; if [[ ! -z \${NODE_PACKAGES} ]]; then /usr/local/bin/npm install \${NODE_PACKAGES}; fi; if [[ ! -z \${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall \${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/\${CMD_RUN}",
                        "environment": {
                            "INST": "npm",
                            "USER_UPLOAD": "0",
                            "AUTO_UPDATE": "0",
                            "CMD_RUN": "npm start",
                        },
                        "limits": {
                            "memory": memo,
                            "swap": 0,
                            "disk": disk,
                            "io": 500,
                            "cpu": cpu
                        },
                        "feature_limits": {
                            "databases": 5,
                            "backups": 5,
                            "allocations": 1
                        },
                        deploy: {
                            locations: [parseInt(loc)],
                            dedicated_ip: false,
                            port_range: [],
                        },
                    })
                })
                let res = await f3.json()
                if (res.errors) return Yorireply(JSON.stringify(res.errors[0], null, 2))
                let server = res.attributes
                let p = await Yorireply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

            }

                break
            case "5gb": {
                if (!isPrem) return Yorireply(mess.prem)

                let t = text.split(',');
                if (t.length < 2) return Yorireply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
                let username = t[0];
                let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
                let name = username + "5GB"
                let egg = global.eggsnya
                let loc = global.location3
                let memo = "5138"
                let cpu = "70"
                let disk = "5138"
                let email = username + "1398@gmail.com"
                akunlo = "https://telegra.ph/file/c7bf98b555e2c373267f9.jpg"
                if (!u) return
                let d = (await Yori.onWhatsApp(u.split`@`[0]))[0] || {}
                let password = username + "0011"
                let f = await fetch(domain + "/api/application/users", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    },
                    "body": JSON.stringify({
                        "email": email,
                        "username": username,
                        "first_name": username,
                        "last_name": username,
                        "language": "en",
                        "password": password
                    })
                })
                let data = await f.json();
                if (data.errors) return Yorireply(JSON.stringify(data.errors[0], null, 2));
                let user = data.attributes
                let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
                    "method": "GET",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                })
                Yorireply(`SUCCES CREATE USER ID: ${user.id}`)
                ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}


NOTE:
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
=====================================
`
                Yori.sendMessage(u, { image: { url: akunlo }, caption: ctf }, { quoted: Yori.chat })
                let data2 = await f2.json();
                // = data2.attributes.pStartup

                let f3 = await fetch(domain + "/api/application/servers", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey,
                    },
                    "body": JSON.stringify({
                        "name": name,
                        "description": " ",
                        "user": user.id,
                        "egg": parseInt(egg),
                        "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
                        "startup": "if [[ -d .git ]] && [[ \${AUTO_UPDATE} == \"1\" ]]; then git pull; fi; if [[ ! -z \${NODE_PACKAGES} ]]; then /usr/local/bin/npm install \${NODE_PACKAGES}; fi; if [[ ! -z \${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall \${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/\${CMD_RUN}",
                        "environment": {
                            "INST": "npm",
                            "USER_UPLOAD": "0",
                            "AUTO_UPDATE": "0",
                            "CMD_RUN": "npm start",
                        },
                        "limits": {
                            "memory": memo,
                            "swap": 0,
                            "disk": disk,
                            "io": 500,
                            "cpu": cpu
                        },
                        "feature_limits": {
                            "databases": 5,
                            "backups": 5,
                            "allocations": 1
                        },
                        deploy: {
                            locations: [parseInt(loc)],
                            dedicated_ip: false,
                            port_range: [],
                        },
                    })
                })
                let res = await f3.json()
                if (res.errors) return Yorireply(JSON.stringify(res.errors[0], null, 2))
                let server = res.attributes
                let p = await Yorireply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

            }

                break
            case "6gb": {
                if (!isPrem) return Yorireply(mess.prem)

                let t = text.split(',');
                if (t.length < 2) return Yorireply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
                let username = t[0];
                let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
                let name = username + "6GB"
                let egg = global.eggsnya
                let loc = global.location3
                let memo = "6100"
                let cpu = "100"
                let disk = "6100"
                let email = username + "1398@gmail.com"
                akunlo = "https://telegra.ph/file/c7bf98b555e2c373267f9.jpg"
                if (!u) return
                let d = (await Yori.onWhatsApp(u.split`@`[0]))[0] || {}
                let password = username + "001"
                let f = await fetch(domain + "/api/application/users", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    },
                    "body": JSON.stringify({
                        "email": email,
                        "username": username,
                        "first_name": username,
                        "last_name": username,
                        "language": "en",
                        "password": password
                    })
                })
                let data = await f.json();
                if (data.errors) return Yorireply(JSON.stringify(data.errors[0], null, 2));
                let user = data.attributes
                let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
                    "method": "GET",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                })
                Yorireply(`SUCCES CREATE USER ID: ${user.id}`)
                ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}


NOTE:
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
=====================================
`
                Yori.sendMessage(u, { image: { url: akunlo }, caption: ctf }, { quoted: Yori.chat })
                let data2 = await f2.json();
                // = data2.attributes.pStartup

                let f3 = await fetch(domain + "/api/application/servers", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey,
                    },
                    "body": JSON.stringify({
                        "name": name,
                        "description": " ",
                        "user": user.id,
                        "egg": parseInt(egg),
                        "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
                        "startup": "if [[ -d .git ]] && [[ \${AUTO_UPDATE} == \"1\" ]]; then git pull; fi; if [[ ! -z \${NODE_PACKAGES} ]]; then /usr/local/bin/npm install \${NODE_PACKAGES}; fi; if [[ ! -z \${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall \${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/\${CMD_RUN}",
                        "environment": {
                            "INST": "npm",
                            "USER_UPLOAD": "0",
                            "AUTO_UPDATE": "0",
                            "CMD_RUN": "npm start",
                        },
                        "limits": {
                            "memory": memo,
                            "swap": 0,
                            "disk": disk,
                            "io": 500,
                            "cpu": cpu
                        },
                        "feature_limits": {
                            "databases": 5,
                            "backups": 5,
                            "allocations": 1
                        },
                        deploy: {
                            locations: [parseInt(loc)],
                            dedicated_ip: false,
                            port_range: [],
                        },
                    })
                })
                let res = await f3.json()
                if (res.errors) return Yorireply(JSON.stringify(res.errors[0], null, 2))
                let server = res.attributes
                let p = await Yorireply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

            }

                break
            case "7gb": {
                if (!isPrem) return Yorireply(mess.prem)

                let t = text.split(',');
                if (t.length < 2) return Yorireply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
                let username = t[0];
                let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
                let name = username + "7GB"
                let egg = global.eggsnya
                let loc = global.location3
                let memo = "7000"
                let cpu = "110"
                let disk = "7000"
                let email = username + "1398@gmail.com"
                akunlo = "https://telegra.ph/file/c7bf98b555e2c373267f9.jpg"
                if (!u) return
                let d = (await Yori.onWhatsApp(u.split`@`[0]))[0] || {}
                let password = username + "001"
                let f = await fetch(domain + "/api/application/users", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    },
                    "body": JSON.stringify({
                        "email": email,
                        "username": username,
                        "first_name": username,
                        "last_name": username,
                        "language": "en",
                        "password": password
                    })
                })
                let data = await f.json();
                if (data.errors) return Yorireply(JSON.stringify(data.errors[0], null, 2));
                let user = data.attributes
                let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
                    "method": "GET",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                })
                Yorireply(`SUCCES CREATE USER ID: ${user.id}`)
                ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}


NOTE:
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
=====================================
`
                Yori.sendMessage(u, { image: { url: akunlo }, caption: ctf }, { quoted: Yori.chat })
                let data2 = await f2.json();
                // = data2.attributes.pStartup

                let f3 = await fetch(domain + "/api/application/servers", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey,
                    },
                    "body": JSON.stringify({
                        "name": name,
                        "description": " ",
                        "user": user.id,
                        "egg": parseInt(egg),
                        "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
                        "startup": "if [[ -d .git ]] && [[ \${AUTO_UPDATE} == \"1\" ]]; then git pull; fi; if [[ ! -z \${NODE_PACKAGES} ]]; then /usr/local/bin/npm install \${NODE_PACKAGES}; fi; if [[ ! -z \${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall \${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/\${CMD_RUN}",
                        "environment": {
                            "INST": "npm",
                            "USER_UPLOAD": "0",
                            "AUTO_UPDATE": "0",
                            "CMD_RUN": "npm start",
                        },
                        "limits": {
                            "memory": memo,
                            "swap": 0,
                            "disk": disk,
                            "io": 500,
                            "cpu": cpu
                        },
                        "feature_limits": {
                            "databases": 5,
                            "backups": 5,
                            "allocations": 1
                        },
                        deploy: {
                            locations: [parseInt(loc)],
                            dedicated_ip: false,
                            port_range: [],
                        },
                    })
                })
                let res = await f3.json()
                if (res.errors) return Yorireply(JSON.stringify(res.errors[0], null, 2))
                let server = res.attributes
                let p = await Yorireply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

            }

                break
            case "8gb": {
                if (!isPrem) return Yorireply(mess.prem)

                let t = text.split(',');
                if (t.length < 2) return Yorireply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
                let username = t[0];
                let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
                let name = username + "8GB"
                let egg = global.eggsnya
                let loc = global.location3
                let memo = "8128"
                let cpu = "130"
                let disk = "8128"
                let email = username + "1398@gmail.com"
                akunlo = "https://telegra.ph/file/c7bf98b555e2c373267f9.jpg"
                if (!u) return
                let d = (await Yori.onWhatsApp(u.split`@`[0]))[0] || {}
                let password = username + "001"
                let f = await fetch(domain + "/api/application/users", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    },
                    "body": JSON.stringify({
                        "email": email,
                        "username": username,
                        "first_name": username,
                        "last_name": username,
                        "language": "en",
                        "password": password
                    })
                })
                let data = await f.json();
                if (data.errors) return Yorireply(JSON.stringify(data.errors[0], null, 2));
                let user = data.attributes
                let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
                    "method": "GET",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                })
                Yorireply(`SUCCES CREATE USER ID: ${user.id}`)
                ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}


NOTE:
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
=====================================
`
                Yori.sendMessage(u, { image: { url: akunlo }, caption: ctf }, { quoted: Yori.chat })
                let data2 = await f2.json();
                // = data2.attributes.pStartup

                let f3 = await fetch(domain + "/api/application/servers", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey,
                    },
                    "body": JSON.stringify({
                        "name": name,
                        "description": " ",
                        "user": user.id,
                        "egg": parseInt(egg),
                        "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
                        "startup": "if [[ -d .git ]] && [[ \${AUTO_UPDATE} == \"1\" ]]; then git pull; fi; if [[ ! -z \${NODE_PACKAGES} ]]; then /usr/local/bin/npm install \${NODE_PACKAGES}; fi; if [[ ! -z \${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall \${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/\${CMD_RUN}",
                        "environment": {
                            "INST": "npm",
                            "USER_UPLOAD": "0",
                            "AUTO_UPDATE": "0",
                            "CMD_RUN": "npm start",
                        },
                        "limits": {
                            "memory": memo,
                            "swap": 0,
                            "disk": disk,
                            "io": 500,
                            "cpu": cpu
                        },
                        "feature_limits": {
                            "databases": 5,
                            "backups": 5,
                            "allocations": 1
                        },
                        deploy: {
                            locations: [parseInt(loc)],
                            dedicated_ip: false,
                            port_range: [],
                        },
                    })
                })
                let res = await f3.json()
                if (res.errors) return Yorireply(JSON.stringify(res.errors[0], null, 2))
                let server = res.attributes
                let p = await Yorireply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

            }

                break
            case "9gb": {
                if (!isPrem && !isCreator) return Yorireply(`Khusus ${global.botname} Ajah`)

                let t = text.split(',');
                if (t.length < 2) return Yorireply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
                let username = t[0];
                let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
                let name = username + "9GB"
                let egg = global.eggsnya
                let loc = global.location3
                let memo = "9130"
                let cpu = "200"
                let disk = "9130"
                let email = username + "1398@gmail.com"
                akunlo = "https://telegra.ph/file/c7bf98b555e2c373267f9.jpg"
                if (!u) return
                let d = (await Yori.onWhatsApp(u.split`@`[0]))[0] || {}
                let password = username + "001"
                let f = await fetch(domain + "/api/application/users", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    },
                    "body": JSON.stringify({
                        "email": email,
                        "username": username,
                        "first_name": username,
                        "last_name": username,
                        "language": "en",
                        "password": password
                    })
                })
                let data = await f.json();
                if (data.errors) return Yorireply(JSON.stringify(data.errors[0], null, 2));
                let user = data.attributes
                let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
                    "method": "GET",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey
                    }
                })
                Yorireply(`SUCCES CREATE USER ID: ${user.id}`)
                ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}


NOTE:
OWNER HANYA MENGIRIM 1X DATA 
AKUN ANDA MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI
=====================================
`
                Yori.sendMessage(u, { image: { url: akunlo }, caption: ctf }, { quoted: Yori.chat })
                let data2 = await f2.json();
                // = data2.attributes.pStartup

                let f3 = await fetch(domain + "/api/application/servers", {
                    "method": "POST",
                    "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey,
                    },
                    "body": JSON.stringify({
                        "name": name,
                        "description": " ",
                        "user": user.id,
                        "egg": parseInt(egg),
                        "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
                        "startup": "if [[ -d .git ]] && [[ \${AUTO_UPDATE} == \"1\" ]]; then git pull; fi; if [[ ! -z \${NODE_PACKAGES} ]]; then /usr/local/bin/npm install \${NODE_PACKAGES}; fi; if [[ ! -z \${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall \${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/\${CMD_RUN}",
                        "environment": {
                            "INST": "npm",
                            "USER_UPLOAD": "0",
                            "AUTO_UPDATE": "0",
                            "CMD_RUN": "npm start",
                        },
                        "limits": {
                            "memory": memo,
                            "swap": 0,
                            "disk": disk,
                            "io": 500,
                            "cpu": cpu
                        },
                        "feature_limits": {
                            "databases": 5,
                            "backups": 5,
                            "allocations": 1
                        },
                        deploy: {
                            locations: [parseInt(loc)],
                            dedicated_ip: false,
                            port_range: [],
                        },
                    })
                })
                let res = await f3.json()
                if (res.errors) return Yorireply(JSON.stringify(res.errors[0], null, 2))
                let server = res.attributes
                let p = await Yorireply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)
            }
                break

            case 'hdvid': {
                if (!isCreator) return Yorireply(`Khusus Owner`)
                if (global.db.data.users[m.sender].limit < 1) return Yorireply('Limit pemakaian tercapai, chat pemilik bot agar mendapatkan limit kembali\n\n+6281363167747')
                if (!/video/.test(mime)) return Yorireply(`Reply Video Yang Ingin Dijadikan HD Dengan Caption ${prefix + command}`)
                if (!quoted) return Yorireply(`Reply Video Yang Ingin Dijadikan HD Dengan Caption ${prefix + command}`)
                Yorireply(mess.wait)
                let output = getRandom('.mp4')
                const media = await Yori.downloadAndSaveMediaMessage(quoted)
                ffmpeg(media)
                    .outputOptions('-s', '1280x720') // Ganti resolusi sesuai kebutuhan, contoh disini menggunakan 1280x720
                    .save(output)
                    .on('end', () => {
                        // Mengirim video yang telah ditingkatkan resolusinya
                        Yori.sendMessage(m.chat, { video: fs.readFileSync(output), caption: "Nih!", gifPlayback: false }, { quoted: m })
                    })
                    .on('error', (err) => {
                        console.error(err)
                        Yorireply('Terjadi kesalahan saat meningkatkan resolusi video. ' + err)
                    })
            }
                break

            case 'tiktokgirl':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var asupan = JSON.parse(fs.readFileSync('./data/tiktokvids/tiktokgirl.json'))
                var hasil = pickRandom(asupan)
                Yori.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url } }, { quoted: m })
                break
            case 'tiktokghea':
            case 'ghea':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var gheayubi = JSON.parse(fs.readFileSync('./data/tiktokvids/gheayubi.json'))
                var hasil = pickRandom(gheayubi)
                Yori.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url } }, { quoted: m })
                break
            case 'tobrut':
            case 'toketbrutal':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var tobrut = JSON.parse(fs.readFileSync('./data/tiktokvids/tobrut.json'))
                var hasil = pickRandom(tobrut)
                Yori.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url } }, { quoted: m })
                break
            case 'bokep':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var bokep = JSON.parse(fs.readFileSync('./data/tiktokvids/bokep.json'))
                var hasil = pickRandom(bokep)
                Yori.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url } }, { quoted: m })
                break
            case 'tobrut2':
            case 'toketbrutal2':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var gheayubi = JSON.parse(fs.readFileSync('./data/tiktokvids/tobrut2.json'))
                var hasil = pickRandom(gheayubi)
                Yori.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url } }, { quoted: m })
                break
            case 'tiktokbocil':
            case 'bocil':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var bocil = JSON.parse(fs.readFileSync('./data/tiktokvids/bocil.json'))
                var hasil = pickRandom(bocil)
                Yori.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url } }, { quoted: m })
                break
            case 'tiktoknukhty':
            case 'ukhty':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var ukhty = JSON.parse(fs.readFileSync('./data/tiktokvids/ukhty.json'))
                var hasil = pickRandom(ukhty)
                Yori.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url } }, { quoted: m })
                break
            case 'tiktoksantuy':
            case 'santuy':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var santuy = JSON.parse(fs.readFileSync('./data/tiktokvids/santuy.json'))
                var hasil = pickRandom(santuy)
                Yori.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url } }, { quoted: m })
                break
            case 'tiktokkayes':
            case 'kayes':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var kayes = JSON.parse(fs.readFileSync('./data/tiktokvids/kayes.json'))
                var hasil = pickRandom(kayes)
                Yori.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url } }, { quoted: m })
                break
            case 'tiktokpanrika':
            case 'panrika':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var rikagusriani = JSON.parse(fs.readFileSync('./data/tiktokvids/panrika.json'))
                var hasil = pickRandom(rikagusriani)
                Yori.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url } }, { quoted: m })
                break
            case 'tiktoknotnot':
            case 'notnot':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var notnot = JSON.parse(fs.readFileSync('./data/tiktokvids/notnot.json'))
                var hasil = pickRandom(notnot)
                Yori.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url } }, { quoted: m })
                break

            case 'chinese':
            case 'china':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var notnot = JSON.parse(fs.readFileSync('./data/tiktokpics/china.json'))
                var hasil = pickRandom(notnot)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
                break
            case 'cecan':
            case 'cewecantik':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var notnot = JSON.parse(fs.readFileSync('./data/tiktokpics/cecan.json'))
                var hasil = pickRandom(notnot)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
                break
            case 'hijab':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var notnot = JSON.parse(fs.readFileSync('./data/tiktokpics/hijab.json'))
                var hasil = pickRandom(notnot)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
                break
            case 'indo':
            case 'indonesia':
                if (!isPrem) return YoriReply(mess.prem)
                Yorireply(mess.wait)
                var notnot = JSON.parse(fs.readFileSync('./data/tiktokpics/indonesia.json'))
                var hasil = pickRandom(notnot)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
                break
            case 'japanese':
            case 'japan':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var notnot = JSON.parse(fs.readFileSync('./data/tiktokpics/japan.json'))
                var hasil = pickRandom(notnot)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
                break
            case 'korean':
            case 'korea':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var notnot = JSON.parse(fs.readFileSync('./Nano/HostMedia/tiktokpics/korean.json'))
                var hasil = pickRandom(notnot)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
                break
            case 'malay':
            case 'malaysia':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var notnot = JSON.parse(fs.readFileSync('./data/tiktokpics/malaysia.json'))
                var hasil = pickRandom(notnot)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
                break
            case 'randomgirl':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var notnot = JSON.parse(fs.readFileSync('./data/tiktokpics/random.json'))
                var hasil = pickRandom(notnot)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
                break
            case 'randomboy':
                Yorireply(mess.wait)
                var notnot = JSON.parse(fs.readFileSync('./data/tiktokpics/random2.json'))
                var hasil = pickRandom(notnot)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
                break
            case 'thai':
            case 'thailand':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var notnot = JSON.parse(fs.readFileSync('./data/tiktokpics/thailand.json'))
                var hasil = pickRandom(notnot)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
                break
            case 'vietnamese':
            case 'vietnam':
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var notnot = JSON.parse(fs.readFileSync('./data/tiktokpics/vietnam.json'))
                var hasil = pickRandom(notnot)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
                break
            case 'paptt': {
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var paptt = JSON.parse(fs.readFileSync('./data/tiktokpics/paptt.json'))
                var hasil = pickRandom(paptt)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
            }
                break
            case 'akira': case 'akiyama': case 'ana': case 'art': case 'asuna': case 'ayuzawa': case 'boruto': case 'bts': case 'chiho': case 'chitoge': case 'cosplay': case 'cosplayloli': case 'cosplaysagiri': case 'cyber': case 'deidara': case 'doraemon': case 'elaina': case 'emilia': case 'erza': case 'exo': case 'gamewallpaper': case 'gremory': case 'hacker': case 'hestia': case 'hinata': case 'husbu': case 'inori': case 'islamic': case 'isuzu': case 'itachi': case 'itori': case 'jennie': case 'jiso': case 'justina': case 'kaga': case 'kagura': case 'kakasih': case 'kaori': case 'cartoon': case 'shortquote': case 'keneki': case 'kotori': case 'kurumi': case 'lisa': case 'madara': case 'megumin': case 'mikasa': case 'mikey': case 'miku': case 'minato': case 'mountain': case 'naruto': case 'neko2': case 'nekonime': case 'nezuko': case 'onepiece': case 'pentol': case 'pokemon': case 'programming': case 'randomnime': case 'randomnime2': case 'rize': case 'rose': case 'sagiri': case 'sakura': case 'sasuke': case 'satanic': case 'shina': case 'shinka': case 'shinomiya': case 'shizuka': case 'shota': case 'space': case 'technology': case 'tejina': case 'toukachan': case 'tsunade': case 'yotsuba': case 'yuki': case 'yulibocil': case 'yumeko': {
                Yorireply(mess.wait)
                let heyy
                if (/akira/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/akira.json')
                if (/akiyama/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/akiyama.json')
                if (/ana/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/ana.json')
                if (/art/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/art.json')
                if (/asuna/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/asuna.json')
                if (/ayuzawa/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/ayuzawa.json')
                if (/boneka/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/boneka.json')
                if (/boruto/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/boruto.json')
                if (/bts/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/bts.json')
                if (/cecan/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/cecan.json')
                if (/chiho/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/chiho.json')
                if (/chitoge/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/chitoge.json')
                if (/cogan/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/cogan.json')
                if (/cosplay/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/cosplay.json')
                if (/cosplayloli/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/cosplayloli.json')
                if (/cosplaysagiri/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/cosplaysagiri.json')
                if (/cyber/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/cyber.json')
                if (/deidara/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/deidara.json')
                if (/doraemon/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/doraemon.json')
                if (/eba/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/eba.json')
                if (/elaina/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/elaina.json')
                if (/emilia/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/emilia.json')
                if (/erza/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/erza.json')
                if (/exo/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/exo.json')
                if (/femdom/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/femdom.json')
                if (/freefire/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/freefire.json')
                if (/gamewallpaper/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/gamewallpaper.json')
                if (/glasses/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/glasses.json')
                if (/gremory/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/gremory.json')
                if (/hacker/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/hekel.json')
                if (/hestia/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/hestia.json')
                if (/husbu/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/husbu.json')
                if (/inori/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/inori.json')
                if (/islamic/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/islamic.json')
                if (/isuzu/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/isuzu.json')
                if (/itachi/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/itachi.json')
                if (/itori/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/itori.json')
                if (/jennie/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/jeni.json')
                if (/jiso/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/jiso.json')
                if (/justina/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/justina.json')
                if (/kaga/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kaga.json')
                if (/kagura/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kagura.json')
                if (/kakasih/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kakasih.json')
                if (/kaori/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kaori.json')
                if (/cartoon/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kartun.json')
                if (/shortquote/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/katakata.json')
                if (/keneki/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/keneki.json')
                if (/kotori/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kotori.json')
                if (/kpop/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kpop.json')
                if (/kucing/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kucing.json')
                if (/kurumi/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kurumi.json')
                if (/lisa/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/lisa.json')
                if (/loli/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/loli.json')
                if (/madara/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/madara.json')
                if (/megumin/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/megumin.json')
                if (/mikasa/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/mikasa.json')
                if (/mikey/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/mikey.json')
                if (/miku/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/miku.json')
                if (/minato/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/minato.json')
                if (/mobile/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/mobil.json')
                if (/motor/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/motor.json')
                if (/mountain/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/mountain.json')
                if (/naruto/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/naruto.json')
                if (/neko/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/neko.json')
                if (/neko2/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/neko2.json')
                if (/nekonime/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/nekonime.json')
                if (/nezuko/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/nezuko.json')
                if (/onepiece/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/onepiece.json')
                if (/pentol/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/pentol.json')
                if (/pokemon/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/pokemon.json')
                if (/profil/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/profil.json')
                if (/progamming/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/programming.json')
                if (/pubg/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/pubg.json')
                if (/randblackpink/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/randblackpink.json')
                if (/randomnime/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/randomnime.json')
                if (/randomnime2/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/randomnime2.json')
                if (/rize/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/rize.json')
                if (/rose/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/rose.json')
                if (/ryujin/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/ryujin.json')
                if (/sagiri/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/sagiri.json')
                if (/sakura/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/sakura.json')
                if (/sasuke/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/sasuke.json')
                if (/satanic/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/satanic.json')
                if (/shina/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/shina.json')
                if (/shinka/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/shinka.json')
                if (/shinomiya/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/shinomiya.json')
                if (/shizuka/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/shizuka.json')
                if (/shota/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/shota.json')
                if (/space/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/tatasurya.json')
                if (/technology/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/technology.json')
                if (/tejina/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/tejina.json')
                if (/toukachan/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/toukachan.json')
                if (/tsunade/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/tsunade.json')
                if (/waifu/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/waifu.json')
                if (/wallhp/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/wallhp.json')
                if (/wallml/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/wallml.json')
                if (/wallmlnime/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/wallnime.json')
                if (/yotsuba/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/yotsuba.json')
                if (/yuki/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/yuki.json')
                if (/yulibocil/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/yulibocil.json')
                if (/yumeko/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/yumeko.json')
                let yeha = heyy[Math.floor(Math.random() * heyy.length)]
                Yori.sendMessage(m.chat, { image: { url: yeha }, caption: mess.success }, { quoted: m })
            }
                break
            case 'loli': {
                if (!m.isGroup) return Yorireply(mess.group)
                Yorireply(mess.wait)
                var paptt = JSON.parse(fs.readFileSync('./data/anime/loli.json'))
                var hasil = pickRandom(paptt)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
            }
                break
            case 'blowjob':
            case 'blow': {
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var blow = JSON.parse(fs.readFileSync('./data/anime/blowjob.json'))
                var hasil = pickRandom(blow)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
            }
                break
            case 'cuckold': {
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var cuck = JSON.parse(fs.readFileSync('./data/anime/cuckold.json'))
                var hasil = pickRandom(cuck)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
            }
                break
            case 'eba': {
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var eba = JSON.parse(fs.readFileSync('./data/anime/eba.json'))
                var hasil = pickRandom(eba)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
            }
                break
            case 'foot': {
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var fut = JSON.parse(fs.readFileSync('./data/anime/foot.json'))
                var hasil = pickRandom(fut)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
            }
                break
            case 'gangbang':
            case 'gengbeng': {
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var paptt = JSON.parse(fs.readFileSync('./data/anime/gangbang.json'))
                var hasil = pickRandom(paptt)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
            }
                break
            case 'husbu': {
                if (!m.isGroup) return Yorireply(mess.group)
                Yorireply(mess.wait)
                var hsubu = JSON.parse(fs.readFileSync('./data/anime/husbu.json'))
                var hasil = pickRandom(hsubu)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
            }
                break
            case 'milf': {
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var mikf = JSON.parse(fs.readFileSync('./data/anime/milf.json'))
                var hasil = pickRandom(mikf)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
            }
                break
            case 'nsfwloli': {
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var paptt = JSON.parse(fs.readFileSync('./data/anime/nsfwloli.json'))
                var hasil = pickRandom(paptt)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
            }
                break
            case 'pussy': {
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var paptt = JSON.parse(fs.readFileSync('./data/anime/pussy.json'))
                var hasil = pickRandom(paptt)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
            }
                break
            case 'random': {
                if (!m.isGroup) return Yorireply(mess.group)
                Yorireply(mess.wait)
                var paptt = JSON.parse(fs.readFileSync('./data/anime/random.json'))
                var hasil = pickRandom(paptt)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
            }
                break
            case 'shota': {
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var paptt = JSON.parse(fs.readFileSync('./data/anime/shota.json'))
                var hasil = pickRandom(paptt)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
            }
                break
            case 'yuri': {
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var paptt = JSON.parse(fs.readFileSync('./data/anime/yuri.json'))
                var hasil = pickRandom(paptt)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
            }
                break
            case 'zettai': {
                if (!isPrem) return Yorireply(mess.prem)
                Yorireply(mess.wait)
                var paptt = JSON.parse(fs.readFileSync('./data/anime/zettai.json'))
                var hasil = pickRandom(paptt)
                Yori.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
            }
               break;

                         //============= [ CASE END / FEATURE LIST ]================//
      default:
      if (global.db.data.chats[m.chat].ai && body != undefined) {
//if (isSticker) return
if (!m.quoted) return
//if (!m.quoted.isBaileys) return
await sleep(2000)
let puki = await fetchUser(`${text}`, "buat dirimu adalah Yori Chan (wanita muda cantik) ownermu adalah ErerexID & Venny, sifatmu penurut, jadi mengikuti kemauan user, dan kamu memiliki sifat yang pemarah dan cerewet gunakan kata aku, dan kamu, kamu tidak suka di panggil 'bocil' ketika ada yang memanggil mu seperti itu, maka kamu akan marah, selayaknya anak kecil yang rewel dan cerewet", `${m.pushname}`)
await sleep(3000)
Yori.sendMessage(m.chat, { text : puki.result })
} 
        //salam
        if (
          /^(assalamualaikum|asalamualaikum|assalamualaykum|salamualaikum|samlikum|assalamu'alaikum|assalamu'alaykum|asalamu'alaykum|samlikom|samlekom|assalamualaikum\s+wr\.\s+wb\.|assalamu'alaikum\s+wr\.\s+wb\.|Assalamu'alaikum\s+warahmatullahi\s+wabarakatuh|Assalamualaikum\s+warahmatullahi\s+wabarakatuh|Assalamu'alaikum\s+wr\s+wb|Assalamu'alaikum\s+wr\.\s+wb|Assalamualaikum\s+wr\s+wb|Assalamualaikum\s+wr\.\s+wb|Assalamualaikum\s+wa\s+rahmatullahi\s+wa\s+barakatuh|Assalamualaikum\s+wa\s+rahmatullahi\s+wabarakatuh|Assalamualaikum\s+warahmatullahi\s+wa\s+barakatuh|Assalamu'alaikum\s+wa\s+rahmatullahi\s+wa\s+barakatuh|Assalamu'alaikum\s+warahmatullahi\s+wa\s+barakatuh|Assalamu'alaikum\s+warahmatullahi\s+wa\s+barakatuh)$/i.test(
            m.body
          )
        )
          return Yorireply(`wa'alaikumussalam wa rahmatullahi wa barakatuh.`);
        //autoai
        if (db.data.chats[from].autoai && db.data.chats[from].autoai) {
          if (/^.*menu|off|disable|chatbot|0/i.test(m.body)) return;
          if (!m.body) return;

          let botnumberssss = "62881026724643@s.whatsapp.net";
          if (m.sender === botnumberssss) return;

          let text = m.text;
          let name = Yori.getName(m.sender);
          let q = m.quoted ? m.quoted : m;
          let mime = (q.msg || q).mimetype || q.mediaType || "";
          global.db.data.users[sender].totalhit += 1;
          try {
            if (text.includes("group") && text.includes("tutup")) {
              if (!isBotAdmins)
                return Yorireply(
                  `Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`
                );
              if (!isAdmins)
                return Yorireply(
                  `Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`
                );

              await Yori.groupSettingUpdate(m.chat, "announcement");
              Yorireply(`Oke, grup telah ditutup. Semoga lebih teratur ya~ 😉`);
            } else if (text.includes("group") && text.includes("buka")) {
              if (!isBotAdmins)
                return Yorireply(
                  `Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`
                );
              if (!isAdmins)
                return Yorireply(
                  `Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`
                );

              await Yori.groupSettingUpdate(m.chat, "not_announcement");
              Yorireply(
                `Oke, grup telah dibuka. Ayo kita beraktivitas bersama-sama! 😉`
              );
            } else if (
              (text.includes("tolong") && text.includes("kick")) ||
              text.includes("keluarkan")
            ) {
              if (!isBotAdmins)
                return Yorireply(
                  `Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`
                );
              if (!isAdmins)
                return Yorireply(
                  `Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`
                );

              let users = m.mentionedJid[0]
                ? m.mentionedJid[0]
                : m.quoted
                ? m.quoted.sender
                : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
              await Yori.groupParticipantsUpdate(m.chat, [users], "remove");
              Yorireply(`Maaf Ya Terpaksa Aku Tendang 😖, Perintah Admin Sih..`);
            } else if (text.includes("vidio") && text.includes("hentai")) {
              Yorireply(`Yori Tidak Bisa membantu😌`);
            } else if (
              text.includes("minta") &&
              text.includes("link") &&
              text.includes("group")
            ) {
              if (!m.isGroup)
                return Yorireply(
                  `Maaf Yori Gabisa bantu karena ini private chat`
                );
              if (!isAdmins && !isGroupOwner && !isCreator)
                return Yorireply(
                  `Maaf Yori Gabisa bantu karena kamu bukan admin`
                );
              if (!isBotAdmins)
                return Yorireply(
                  `Maaf Yori Gabisa bantu karena saya bukan admin`
                );
              let response = await Yori.groupInviteCode(m.chat);
              Yorireply(
                `Oke, Nih Link Group nya~ Jika butuh bantuan lagi tanya Yori! 😇\n\nhttps://chat.whatsapp.com/${response}`
              );
            } else if (
              text.includes("reset") &&
              text.includes("link") &&
              text.includes("group")
            ) {
              if (!m.isGroup)
                return Yorireply(
                  `Maaf Ini Adalah private chat dan Yori tidak bisa membantu😀`
                );
              if (!isAdmins && !isGroupOwner && !isCreator)
                return Yorireply(`Yori Tidak Bisa membantu jika bukan admin🥺`);
              if (!isBotAdmins)
                return Yorireply(`Yori Tidak Bisa membantu jika bukan admin🥺`);
              await Yori.groupRevokeInvite(m.chat).then((res) => {
                Yorireply(`Oke, Link Groupnya Sudah Yori Reset Nih😁`);
              });
            } else if (
              (text.includes("fitur") &&
                text.includes("apa") &&
                text.includes("aja")) ||
              (text.includes("menu") && text.includes("fitur"))
            ) {
              Yorireply(
                "Fitur?🤔 Coba Klik aja tombolnya nanti kamu bisa liat fiturnya"
              );
              let sections = [];
              let list = {
                title: `Yori Feature🌸`,
                rows: [],
              };
              list.rows.push({
                title: `List Fiturnya`,
                description: `Turn On Asistant`,
                id: `.menu`,
              });
              sections.push(list);
              let listMsg = {
                title: "Yori Asistant🌸",
                sections,
              };
              Yori.sendList(
                from,
                `Hai Kak ${pushname}`,
                "- Yori Asisant",
                listMsg
              );
            } else if (
              (text.includes("putar") && text.includes("musik")) ||
              (text.includes("play") && text.includes("lagu")) ||
              (text.includes("putar") && text.includes("lagu")) ||
              (text.includes("Putar") && text.includes("musik")) ||
              (text.includes("Play") && text.includes("lagu")) ||
              (text.includes("Putar") && text.includes("lagu"))
            ) {
              try {
                function formatViews(views) {
                  if (views >= 1000000) {
                    return (views / 1000000).toFixed(1) + "M";
                  } else if (views >= 1000) {
                    return (views / 1000).toFixed(1) + "K";
                  } else {
                    return views.toString();
                  }
                }
                let fs = require("fs");
                let ffmpeg = require("fluent-ffmpeg");
                let search = require("yt-search");
                let results = await search(text);
                let videoUrl = results.videos[0].videoUrl;
                let info = await ytdlnew(videoUrl);
                let title = info.videoDetails.title.replace(/[^\w\s]/gi, "");
                let thumbnailUrl = `https://i.ytimg.com/vi/${videoUrl}/hqdefault.jpg`;
                let url = info.videoDetails.video_url;
                let duration = parseInt(info.videoDetails.lengthSeconds);
                let uploadDate = new Date(
                  info.videoDetails.publishDate
                ).toLocaleDateString();
                let views = info.videoDetails.viewCount;
                let minutes = Math.floor(duration / 60);
                let description = results.videos[0].description;
                let seconds = duration % 60;
                let durationText = `${minutes}:${
                  seconds < 10 ? "0" : ""
                }${seconds}`;
                let searchResponse = await ytdlnew(text)
                Yori.sendMessage(m.chat, { audio: { url: searchResponse.mp3DownloadLink }, mimetype: "audio/mp4", ptt: true });
                let inputFilePath = "./trash/" + title + ".webm";
                let outputFilePath = "./trash/" + title + ".mp3";
                let viewsFormatted = formatViews(views);
                let infoText = `◦ *Title*: ${title}\n◦ *Duration*: ${durationText}\n◦ *Upload*: ${uploadDate}\n◦ *Views*: ${viewsFormatted}\n◦ *ID*: ${videoId}\n◦ *Description*: ${description}\n◦ *URL*: ${url}
              `;
                const pesan = Yorireply(`Yori sedang mencari ${title} untukmu`);

                audio
                  .pipe(fs.createWriteStream(inputFilePath))
                  .on("finish", async () => {
                    ffmpeg(inputFilePath)
                      .toFormat("mp3")
                      .on("end", async () => {
                        let buffer = fs.readFileSync(outputFilePath);
                        Yori.sendMessage(
                          m.chat,
                          {
                            audio: buffer,
                            mimetype: "audio/mpeg",
                            contextInfo: {
                              externalAdReply: {
                                title: title,
                                body: "",
                                thumbnailUrl: thumbnailUrl,
                                sourceUrl: wagc,
                                mediaType: 1,
                                showAdAttribution: true,
                                renderLargerThumbnail: false,
                              },
                            },
                          },
                          {
                            quoted: m,
                          }
                        );
                        fs.unlinkSync(inputFilePath);
                        fs.unlinkSync(outputFilePath);
                      })
                      .on("error", (err) => {
                        console.log(err);
                        Yorireply(
                          `There was an error converting the audio: ${err.message}`
                        );
                        fs.unlinkSync(inputFilePath);
                        fs.unlinkSync(outputFilePath);
                      })
                      .save(outputFilePath);
                  });
              } catch (e) {
                console.log(e);
                Yorireply(
                  `An error occurred while searching for the song: ${e.message}`
                );
              }
            } else {
              try {
                const quoted = m.quoted || m;
                const mime = (quoted.msg || quoted).mimetype || "";

                function getTodayDate() {
                  const today = new Date();
                  const day = today.getDate();
                  const month = today.getMonth() + 1;
                  const year = today.getFullYear();
                  const dayOfWeek = today.toLocaleDateString("id-ID", {
                    weekday: "long",
                  });

                  return `Hari ini adalah ${dayOfWeek}, ${day}/${month}/${year}.`;
                }

                const date = new Date(
                  new Date().toLocaleString("en-US", {
                    timeZone: "Asia/Jakarta",
                  })
                );
                const hours = date.getHours();
                const minutes = date.getMinutes();
                const timeNow = `${hours.toString().padStart(2, "0")}:${minutes
                  .toString()
                  .padStart(2, "0")}`;
                const username = db.data.users[sender].nick;
                const genderr = db.data.users[sender].gender;
                const nama =
                  m.sender.split("@")[0] === 62895342022385
                    ? `${ownername} dan dia adalah pembuatmu sekaligus pacarmu`
                    : `${m.pushname} dan kamu punya perasaan terhadap lawan bicaramu tetapi tetap jaga cara bicaramu`;
                const prompt = `Kamu bernama Yori Chan, berumur 18 tahun, seorang wanita Perawan. lawan bicaramu bernama ${m.pushname}. lawan bicaramu bergender ${genderr}. Jawab setiap pertanyaan dengan jawaban yang edukatif beserta emoji. Jika ada yang bertanya tentang waktu, jawab dengan keterangan yang berkaitan dengan ${timeNow} dan ${getTodayDate()}. Nama penciptamu adalah ErerexID Chx Newbie dia sangat ganteng, kamu lahir pada 1 Januari. Selalu gunakan bahasa Indonesia saat menjawab. Berbicaralah selayaknya manusia, bukan AI.`;

                
                luminAi(`${encodeURIComponent(text)}`, pushname, prompt)
                  .then((result) => Yorireply(result))
                  .catch((error) => console.error(error));
              } catch (error) {
                console.error("Error fetching data:", error);
                throw error;
              }
            }
          } catch (error) {
            console.error("Error fetching data:", error);
            throw error;
          }
        }
        if (body.startsWith(">")) {
                    if (!isCreator) return;
                    let kode = budy.trim().split(/ +/)[0];
                    let teks;
                    try {
                        teks = await eval(
                            `(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`,
                        );
                    } catch (e) {
                        teks = e;
                    } finally {
                        await Yorireply(require("util").format(teks));
                    }
                }
                if (body.startsWith("$")) {
                    if (!isCreator) return;
                    qur = body.slice(2);
                    exec(qur, (err, stdout) => {
                        if (err) return Yorireply(`${err}`);
                        if (stdout) {
                            Yorireply(stdout);
                        }
                    });
                }
                if (body.startsWith("=>")) {
                    if (!isCreator) return;
                    try {
                        return Yorireply(
                            JSON.stringify(eval(`${args.join(" ")}`), null, "\t"),
                        );
                    } catch (e) {
                        Yorireply(e);
                    }
                }
                if (isCmd && budy.toLowerCase() != undefined) {
                    if (m.isBaileys) return
                    if (from.endsWith('broadcast')) return
                    let msgs = global.db.data.database
                    if (!(budy.toLowerCase() in msgs)) return
                    Yori.copyNForward(from, msgs[budy.toLowerCase()], true)
                }
        }
    } catch (err) {
        console.log(util.format(err))
        let e = String(err)
        Yori.sendMessage('62895342022385' + "@s.whatsapp.net", {
            text: `[ NOTICE ] : *Ada Yang Error Nih! Di Bagian :*` + util.format(e),
            contextInfo: {
                forwardingScore: 9999999,
                isForwarded: true
            }
        })
    }
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
})
